/*
SQLyog Job Agent Version 9.10 Copyright(c) Webyog Softworks Pvt. Ltd. All Rights Reserved.


MySQL - 5.1.62-community : Database - piedpiper
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`piedpiper` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `piedpiper`;

/*Table structure for table `bpm_access` */

DROP TABLE IF EXISTS `bpm_access`;

CREATE TABLE `bpm_access` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `TARGETTYPE_` varchar(50) DEFAULT NULL COMMENT '设置权限设置的目标，可能的类型有：部门(DEPT)、角色(ROLE)、群组(GROUP)、岗位(POS)、用户(USER)\r\nTARGET_TYPE字段与TARGET_ID字段联合使用，当TARGET_TYPE存储不同的值时，TARGET_ID存储响应的类型的ID值。\r\n类型优先级如下：用户(USER) > 角色(ROLE) > 部门(DEPT) > 岗位(POS) > 群组(GROUP) > ',
  `TARGETID_` varchar(255) DEFAULT NULL COMMENT '根据TARGET_TYPE的不同的值存储不同的内容，具体内容如下：\r\nTARGET_TYPE的值， TARGET_ID存储的值\r\nROLE              ROLE_ID\r\nDEPT             DEPT_ID\r\n等等',
  `DEPLOYMENT_` varchar(50) DEFAULT NULL COMMENT '流程部署ID',
  `ACCESS_` varchar(50) DEFAULT NULL COMMENT '是否可以启动流程',
  `TYPE_` varchar(50) DEFAULT NULL COMMENT '权限类型，备用',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='流程启动权限表';

/*Data for the table `bpm_access` */

/*Table structure for table `bpm_button` */

DROP TABLE IF EXISTS `bpm_button`;

CREATE TABLE `bpm_button` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键id',
  `BUTTON_CODE_` varchar(100) DEFAULT NULL COMMENT '按钮代码',
  `BUTTON_DEFAULT_NAME_` varchar(100) DEFAULT NULL COMMENT '按钮默认名称',
  `BUTTON_NAME_` varchar(100) DEFAULT NULL COMMENT '按钮名称',
  `BUTTON_SPECIAL_STEP_NAME_` text COMMENT '按钮在特定节点中的名称',
  `BUTTON_DESCRIPTION_` text COMMENT '按钮描述',
  `BUTTON_ORDER_` varchar(50) DEFAULT NULL COMMENT '按钮顺序',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='流程按钮名称定义表';

/*Data for the table `bpm_button` */

/*Table structure for table `bpm_catalog` */

DROP TABLE IF EXISTS `bpm_catalog`;

CREATE TABLE `bpm_catalog` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键ID',
  `PARENT_ID_` varchar(50) NOT NULL COMMENT '业务目录父目录',
  `NAME_` text NOT NULL COMMENT '业务目录名称',
  `CODE_` varchar(100) DEFAULT NULL COMMENT '业务目录代码',
  `REMARK_` text COMMENT '备注',
  `ORDER_BY_` decimal(16,0) DEFAULT NULL COMMENT '排序',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='流程业务目录表';

/*Data for the table `bpm_catalog` */

insert  into `bpm_catalog` values ('-1','root','流程业务目录','catalog','流程业务目录根节点','0'),('-2','root','正文模板目录','wordTemplet','正文模板路径根节点','0');

/*Table structure for table `bpm_catalog_process_relation` */

DROP TABLE IF EXISTS `bpm_catalog_process_relation`;

CREATE TABLE `bpm_catalog_process_relation` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键ID',
  `BUSSINESS_CATALOG_DBID_` varchar(50) NOT NULL COMMENT '业务目录表DBID_',
  `BPM_PROCESS_KEY_` varchar(50) NOT NULL COMMENT '流程文件KEY',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='流程业务目录与流程关系表';

/*Data for the table `bpm_catalog_process_relation` */

/*Table structure for table `bpm_class` */

DROP TABLE IF EXISTS `bpm_class`;

CREATE TABLE `bpm_class` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键ID',
  `NAME_` varchar(100) NOT NULL COMMENT '类名',
  `PATH_` text NOT NULL COMMENT '类路径',
  `TYPE_` varchar(100) DEFAULT NULL COMMENT '类型',
  `REMARK_` text COMMENT '备注',
  `ORDER_BY_` decimal(16,0) DEFAULT NULL COMMENT '排序',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Java类表';

/*Data for the table `bpm_class` */

/*Table structure for table `bpm_class_method` */

DROP TABLE IF EXISTS `bpm_class_method`;

CREATE TABLE `bpm_class_method` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键ID',
  `BPM_CLASS_DBID_` varchar(50) NOT NULL COMMENT 'BPM_CLASS表主键',
  `METHOD_` text NOT NULL COMMENT '方法名',
  `RETURN_` varchar(100) NOT NULL COMMENT '返回值',
  `REMARK_` text COMMENT '备注',
  `ORDER_BY_` decimal(16,0) DEFAULT NULL COMMENT '排序',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Java类中含有的方法表';

/*Data for the table `bpm_class_method` */

/*Table structure for table `bpm_class_properties` */

DROP TABLE IF EXISTS `bpm_class_properties`;

CREATE TABLE `bpm_class_properties` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键ID',
  `THIRD_PARTY_DBID_` varchar(50) NOT NULL COMMENT 'BPM_CLASS或BPM_CLASS_METHOD表主键',
  `SORT_` varchar(100) NOT NULL COMMENT '属性种类(field或arg)',
  `NAME_` varchar(100) NOT NULL COMMENT '属性名',
  `TYPE_` varchar(100) NOT NULL COMMENT '属性类型',
  `INIT_EXPR_` text COMMENT '属性默认值',
  `REMARK_` text COMMENT '备注',
  `ORDER_BY_` decimal(16,0) NOT NULL COMMENT '排序',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Java类中含有的属性或方法中传递的参数表';

/*Data for the table `bpm_class_properties` */

/*Table structure for table `bpm_configuration` */

DROP TABLE IF EXISTS `bpm_configuration`;

CREATE TABLE `bpm_configuration` (
  `DBID_` varchar(32) NOT NULL COMMENT '主键',
  `NAME_` varchar(200) DEFAULT NULL COMMENT 'CLASS类名',
  `CLASS_` text COMMENT 'CLASS包路径',
  `TYPE_` varchar(10) DEFAULT NULL COMMENT '1-处理类型、2-路由条件、3-自定义选人',
  `REMARK_` text COMMENT '描述',
  `ORDER_BY_` decimal(16,0) DEFAULT NULL,
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='流程预、后处理函数等的配置';

/*Data for the table `bpm_configuration` */

/*Table structure for table `bpm_cross_net_instance` */

DROP TABLE IF EXISTS `bpm_cross_net_instance`;

CREATE TABLE `bpm_cross_net_instance` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `STATUS_` varchar(30) DEFAULT NULL COMMENT '实例导出状态',
  `ID_` varchar(50) DEFAULT NULL COMMENT '流程实例ID',
  `ATTRIBUTE_00` varchar(50) DEFAULT NULL COMMENT '保留属性00',
  `ATTRIBUTE_01` varchar(50) DEFAULT NULL COMMENT '保留属性01',
  `ISENDED_` varchar(30) DEFAULT NULL COMMENT '标记当前实例是否已经结束',
  `HAS_EXPORTED_` varchar(30) DEFAULT NULL COMMENT '对于已结束的流程实例仅导出一次',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_cross_net_instance` */

/*Table structure for table `bpm_deployment` */

DROP TABLE IF EXISTS `bpm_deployment`;

CREATE TABLE `bpm_deployment` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `NAME_` longtext COMMENT '流程名称，暂时不启用',
  `TIMESTAMP_` decimal(19,0) DEFAULT NULL COMMENT '部署时间',
  `STATE_` varchar(255) DEFAULT NULL COMMENT '状态；active激活、suspended暂停',
  `TYPE_` varchar(255) DEFAULT NULL COMMENT '流程类型，regular常规流程、temporary临时流程',
  `DESIGNER_` varchar(255) DEFAULT NULL COMMENT '流程设计人',
  `DEPLOYER_` varchar(255) DEFAULT NULL COMMENT '流程发布人',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='流程部署表';

/*Data for the table `bpm_deployment` */

/*Table structure for table `bpm_deployprop` */

DROP TABLE IF EXISTS `bpm_deployprop`;

CREATE TABLE `bpm_deployprop` (
  `DBID_` varchar(50) NOT NULL,
  `DEPLOYMENT_` varchar(50) DEFAULT NULL,
  `OBJNAME_` varchar(255) DEFAULT NULL,
  `KEY_` varchar(255) DEFAULT NULL,
  `STRINGVAL_` varchar(255) DEFAULT NULL,
  `LONGVAL_` decimal(19,0) DEFAULT NULL,
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_deployprop` */

/*Table structure for table `bpm_exception` */

DROP TABLE IF EXISTS `bpm_exception`;

CREATE TABLE `bpm_exception` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `INSTANCEID_` varchar(50) DEFAULT NULL COMMENT '流程实例ID',
  `EXECUTIONID_` varchar(255) DEFAULT NULL COMMENT '流程执行ID',
  `ACTIVITYID_` varchar(255) DEFAULT NULL COMMENT '当前活动节点ID',
  `ACTIVITYNAME_` varchar(255) DEFAULT NULL COMMENT '当前活动节点名称',
  `PDID_` varchar(255) DEFAULT NULL COMMENT '流程定义ID',
  `PDNAME_` varchar(255) DEFAULT NULL COMMENT '流程定义名称',
  `EXCEPTION_` longtext COMMENT '异常信息',
  `USERID_` varchar(50) DEFAULT NULL COMMENT '操作人ID',
  `USERNAME_` varchar(50) DEFAULT NULL COMMENT '操作人姓名',
  `DEPTID_` varchar(50) DEFAULT NULL COMMENT '操作人部门ID',
  `DEPTNAME_` varchar(255) DEFAULT NULL COMMENT '操作人部门名称',
  `STATE_` varchar(50) DEFAULT NULL COMMENT '状态（备用是否标记）',
  `TIME_` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='流程异常记录表';

/*Data for the table `bpm_exception` */

/*Table structure for table `bpm_execution` */

DROP TABLE IF EXISTS `bpm_execution`;

CREATE TABLE `bpm_execution` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据version',
  `ACTIVITYNAME_` varchar(255) DEFAULT NULL COMMENT '当前节点id',
  `PROCDEFID_` varchar(255) DEFAULT NULL COMMENT '流程部署的pdid',
  `HASVARS_` decimal(1,0) DEFAULT NULL COMMENT '是否使用流程变量；否=0、是=1',
  `NAME_` varchar(255) DEFAULT NULL COMMENT '目前只在foreach和fork中用到，记录只要的name',
  `KEY_` varchar(255) DEFAULT NULL COMMENT '启动流程时候手工指定的，暂时不启用',
  `ID_` varchar(255) DEFAULT NULL COMMENT 'bpm_deployprop 表中key 是 dbid的值',
  `STATE_` varchar(255) DEFAULT NULL COMMENT '状态',
  `SUSPHISTSTATE_` varchar(255) DEFAULT NULL COMMENT '暂停的状态；suspended',
  `PRIORITY_` decimal(10,0) DEFAULT NULL COMMENT '优先级，暂时没有用到',
  `HISACTINST_` varchar(50) DEFAULT NULL COMMENT 'bpm_hist_actinst表dbid_',
  `PARENT_` varchar(50) DEFAULT NULL COMMENT 'bpm_execution表dbid_记录父关系',
  `INSTANCE_` varchar(50) DEFAULT NULL COMMENT 'bpm_hist_procinst表dbid_',
  `SUPEREXEC_` varchar(50) DEFAULT NULL COMMENT '主流程dbid_',
  `SUBPROCINST_` varchar(50) DEFAULT NULL COMMENT '子流程dbid_',
  `PARENT_IDX_` decimal(10,0) DEFAULT NULL COMMENT '子execution的索引',
  `ACTIVITYALIAS_` varchar(255) DEFAULT NULL COMMENT '节点中文名称',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_execution` */

/*Table structure for table `bpm_ext_form_security` */

DROP TABLE IF EXISTS `bpm_ext_form_security`;

CREATE TABLE `bpm_ext_form_security` (
  `ID` varchar(50) NOT NULL COMMENT '系统编号 : 系统编号 : 系统编号 : 系统编号',
  `PD_ID` varchar(100) DEFAULT NULL COMMENT '流程模版ID : 流程模版ID : 流程模版ID : 流程模版ID',
  `PD_ACTIVITY_NAME` varchar(60) DEFAULT NULL COMMENT '流程节点名称 : 流程节点名称 : 流程节点名称 : 流程节点名称',
  `TAG` varchar(200) DEFAULT NULL COMMENT '控件的Tag属性的值 : 控件的SecurityTag属性的值',
  `TAG_NAME` varchar(200) DEFAULT NULL COMMENT '控件的名称',
  `ACCESSIBILITY` decimal(38,0) DEFAULT NULL COMMENT '可访问性，用来表示一个资源是否可以访问的属性，\r\n对于菜单来说，代表该菜单是否可以访问\r\n\r\n对于URL来说，代表是否可以访问该URL\r\n\r\n对于按钮来说，代表是否显隐\r\n对于表单列和表格列来说，代表是否显隐\r\n\r\n1-允许访问\r\n0-禁止访问',
  `OPERABILITY` decimal(38,0) DEFAULT NULL COMMENT '可操作性，用来表示一个资源是否可以操作的属性，\r\n对于菜单和URL来说，没有可操作性的属性\r\n对于按钮来说，可操作性是指按钮是否可以点击\r\n对于表单列和表格列来说，可操作性是指是否可以更改其中的数据\r\n\r\n1-允许操作\r\n0-禁止操作',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `FORM_CODE` varchar(50) DEFAULT NULL COMMENT '所属全局表单CODE',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='流程表单权限表 ';

/*Data for the table `bpm_ext_form_security` */

/*Table structure for table `bpm_ext_next_activity` */

DROP TABLE IF EXISTS `bpm_ext_next_activity`;

CREATE TABLE `bpm_ext_next_activity` (
  `ID` varchar(50) NOT NULL COMMENT '系统编号 : 系统编号 : 系统编号 : 系统编号',
  `ATTRIBUTE_ID` varchar(50) DEFAULT NULL COMMENT '任务属性ID',
  `ACTIVITY_NAME` varchar(50) DEFAULT NULL COMMENT '节点名称 : 节点名称',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='跳转节点定义';

/*Data for the table `bpm_ext_next_activity` */

/*Table structure for table `bpm_ext_process_attribute` */

DROP TABLE IF EXISTS `bpm_ext_process_attribute`;

CREATE TABLE `bpm_ext_process_attribute` (
  `ID` varchar(50) NOT NULL COMMENT '系统编号 : 系统编号 : 系统编号 : 系统编号',
  `PD_ID` varchar(100) DEFAULT NULL COMMENT '流程模版ID : 流程模版ID : 流程模版ID : 流程模版ID',
  `PROXY_PAGE` varchar(2) DEFAULT NULL COMMENT '是否由系统通用审批页面托管审批功能(Y:支持,N:不支持):如果允许，则设置的页面将被嵌入到系统通用审批页面中',
  `REMARK` text COMMENT '描述 ',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='BPM_EXT_PROCESS_ATTRIBUTE : 流程属性表 : 用来为存储流程的扩展信息';

/*Data for the table `bpm_ext_process_attribute` */

/*Table structure for table `bpm_ext_task_attribute` */

DROP TABLE IF EXISTS `bpm_ext_task_attribute`;

CREATE TABLE `bpm_ext_task_attribute` (
  `ID` varchar(50) NOT NULL COMMENT '系统编号 : 系统编号 : 系统编号 : 系统编号',
  `PD_ID` varchar(100) DEFAULT NULL COMMENT '流程模版ID : 流程模版ID : 流程模版ID : 流程模版ID',
  `PD_ACTIVITY_NAME` varchar(60) DEFAULT NULL COMMENT '流程节点名称 : 流程节点名称 : 流程节点名称 : 流程节点名称',
  `URL` varchar(200) DEFAULT NULL COMMENT '绑定的任务表单所在页面的URL : 绑定的任务表单所在页面的URL : 绑定的任务表单所在页面的URL : 绑定的任务表单所在页面的URL',
  `TYPE` varchar(50) DEFAULT NULL COMMENT '是全局表单还是节点表单，global，activity',
  `REMARK` text COMMENT 'URL参数',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `PROXY_PAGE` varchar(2) DEFAULT NULL COMMENT '是否由系统通用审批页面托管审批功能(Y:支持,N:不支持):如果允许，则设置的页面将被嵌入到系统通用审批页面中',
  `FORM_ID` varchar(50) DEFAULT NULL COMMENT 'bpm_form表的ID',
  `FORM_CODE` varchar(50) DEFAULT NULL COMMENT '所属全局表单CODE',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='任务属性表 : 用来为任务节点的任务的处理方式及节点对应表单等属性信息';

/*Data for the table `bpm_ext_task_attribute` */

/*Table structure for table `bpm_focused_task` */

DROP TABLE IF EXISTS `bpm_focused_task`;

CREATE TABLE `bpm_focused_task` (
  `TASK_DBID_` varchar(50) NOT NULL COMMENT '主键',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `EXECUTION_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表id_',
  `OUTCOME_` varchar(255) DEFAULT NULL COMMENT 'Transition的name属性值',
  `ASSIGNEE_` varchar(255) DEFAULT NULL COMMENT '分派的处理人',
  `PRIORITY_` decimal(10,0) DEFAULT NULL COMMENT '优先级',
  `STATE_` varchar(255) DEFAULT NULL COMMENT '状态',
  `CREATE_` datetime DEFAULT NULL COMMENT '创建时间',
  `END_` datetime DEFAULT NULL COMMENT '结束时间',
  `DURATION_` decimal(19,0) DEFAULT NULL COMMENT '持续时间',
  `NEXTIDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `SUPERTASK_` varchar(50) DEFAULT NULL COMMENT '暂时不启用',
  `TASK_ORDER_` varchar(255) DEFAULT NULL COMMENT '多人顺序处理 记录的顺序',
  `OPEN_` datetime DEFAULT NULL COMMENT '打开时间',
  `TAKE_STATE_` varchar(255) DEFAULT NULL COMMENT 'Task的状态',
  `PROCINST_` varchar(50) DEFAULT NULL COMMENT 'bpm_hist_procinst表id _',
  `DESCR_` longtext COMMENT 'Description属性值',
  `SUSPHISTSTATE_` varchar(255) DEFAULT NULL COMMENT '流程暂停状态',
  `TASK_TYPE_` varchar(255) DEFAULT NULL COMMENT '待办=0;待阅=1',
  `TASK_B_ID_` varchar(255) DEFAULT NULL COMMENT '业务数据id',
  `TASK_TITLE_` varchar(255) DEFAULT NULL COMMENT '待办标题',
  `TASK_SENDUSER_` varchar(255) DEFAULT NULL COMMENT '待办发送人',
  `TASK_SENDDEPT_` varchar(255) DEFAULT NULL COMMENT '待办发送部门',
  `FORM_` varchar(255) DEFAULT NULL COMMENT '待办url',
  `PROCESS_DEF_NAME_` varchar(255) DEFAULT NULL COMMENT '流程定义name',
  `TASK_FINISHED_` varchar(255) DEFAULT NULL COMMENT '标志完成 0 未办 1 已办',
  `TASK_STATE_` varchar(255) DEFAULT NULL COMMENT '待办状态 0无效 1 有效',
  `TASK_NAME_` varchar(255) DEFAULT NULL COMMENT '节点唯一标识名称',
  `HISACTINST_` varchar(50) DEFAULT NULL COMMENT 'bpm_hist_actinst表dbid_',
  `WORKHAND_TYPE_` varchar(255) DEFAULT NULL COMMENT '工作移交类型',
  `WORKHAND_USER_` varchar(255) DEFAULT NULL COMMENT '工作移交参与人',
  `APP_ID_` varchar(255) DEFAULT NULL COMMENT '应用id',
  `ASSIGNEE_DEPT_` varchar(255) DEFAULT NULL COMMENT '分派人部门',
  PRIMARY KEY (`TASK_DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_focused_task` */

/*Table structure for table `bpm_forms` */

DROP TABLE IF EXISTS `bpm_forms`;

CREATE TABLE `bpm_forms` (
  `ID` varchar(50) NOT NULL COMMENT '表ID',
  `FORM_CODE` varchar(50) NOT NULL COMMENT '表单代码',
  `FORM_NAME` varchar(200) NOT NULL COMMENT '表单名称',
  `FORM_URL` text NOT NULL COMMENT '表单URL地址，流程引擎根据这个地址打开相应的表单',
  `FORM_TYPE` varchar(10) NOT NULL COMMENT '表单类型，表单类型有：\r\nD7—— 表示基于Dorado 7开发模块\r\nD5—— 表示基于Dorado 5开发的模块\r\nURI——表示该表单是一个Web 的URI（比如JSP、Servlet地址、Spring MVC地址、Action地址等）\r\n\r\n不同的表单类型，流程引擎根据表单类型传递给不同的流程引擎参数',
  `APP_ID` varchar(50) NOT NULL COMMENT '应用ID，表示该表单属于哪个应用',
  `VALID_FLAG` varchar(2) NOT NULL COMMENT '有效标示。1-有效，0和空表示无效。默认1',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='表单定义表，保存在流程中运行的表单信息。';

/*Data for the table `bpm_forms` */

/*Table structure for table `bpm_froms_relation` */

DROP TABLE IF EXISTS `bpm_froms_relation`;

CREATE TABLE `bpm_froms_relation` (
  `ID` varchar(50) NOT NULL COMMENT '表ID',
  `DEPLOYMENT_ID` varchar(50) NOT NULL COMMENT '流程发布表的ID',
  `FORM_ID` varchar(50) NOT NULL COMMENT '表单表的ID',
  `VALID_FLAG` varchar(2) NOT NULL COMMENT '有效标示。1-有效，0和空表示无效。默认1',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='流程与表单的关系表，只有发布后的流程才能与表单挂接';

/*Data for the table `bpm_froms_relation` */

/*Table structure for table `bpm_hist_actinst` */

DROP TABLE IF EXISTS `bpm_hist_actinst`;

CREATE TABLE `bpm_hist_actinst` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id；bpm_hist_procinst表dbid_',
  `TYPE_` varchar(255) DEFAULT NULL COMMENT '节点类型',
  `EXECUTION_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表id_',
  `ACTIVITY_NAME_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表activity_name_',
  `START_` datetime DEFAULT NULL COMMENT '开始时间',
  `END_` datetime DEFAULT NULL COMMENT '结束时间',
  `DURATION_` decimal(19,0) DEFAULT NULL COMMENT '持续时间',
  `TRANSITION_` varchar(255) DEFAULT NULL COMMENT '转移(Transition)的name值',
  `NEXTIDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT '暂时不启用',
  `DEAL_TYPE_` varchar(255) DEFAULT NULL COMMENT '处理类型',
  `ALIAS_` varchar(255) DEFAULT NULL COMMENT '节点别名',
  `HIST_ACTI_PRE_` varchar(50) DEFAULT NULL COMMENT '上一节点dbid_',
  `SUPEREXEC_` varchar(50) DEFAULT NULL COMMENT '主流程dbid_',
  `ISINGROUP_` varchar(10) DEFAULT NULL COMMENT '该节点是否在group中',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_actinst` */

/*Table structure for table `bpm_hist_actinst_ext1` */

DROP TABLE IF EXISTS `bpm_hist_actinst_ext1`;

CREATE TABLE `bpm_hist_actinst_ext1` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id；bpm_hist_procinst表dbid_',
  `TYPE_` varchar(255) DEFAULT NULL COMMENT '节点类型',
  `EXECUTION_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表id_',
  `ACTIVITY_NAME_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表activity_name_',
  `START_` datetime DEFAULT NULL COMMENT '开始时间',
  `END_` datetime DEFAULT NULL COMMENT '结束时间',
  `DURATION_` decimal(19,0) DEFAULT NULL COMMENT '持续时间',
  `TRANSITION_` varchar(255) DEFAULT NULL COMMENT '转移(Transition)的name值',
  `NEXTIDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT '暂时不启用',
  `DEAL_TYPE_` varchar(255) DEFAULT NULL COMMENT '处理类型',
  `ALIAS_` varchar(255) DEFAULT NULL COMMENT '节点别名',
  `HIST_ACTI_PRE_` varchar(50) DEFAULT NULL COMMENT '上一节点dbid_',
  `SUPEREXEC_` varchar(50) DEFAULT NULL COMMENT '主流程dbid_',
  `ISINGROUP_` varchar(10) DEFAULT NULL COMMENT '该节点是否在group中',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_actinst_ext1` */

/*Table structure for table `bpm_hist_actinst_ext2` */

DROP TABLE IF EXISTS `bpm_hist_actinst_ext2`;

CREATE TABLE `bpm_hist_actinst_ext2` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id；bpm_hist_procinst表dbid_',
  `TYPE_` varchar(255) DEFAULT NULL COMMENT '节点类型',
  `EXECUTION_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表id_',
  `ACTIVITY_NAME_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表activity_name_',
  `START_` datetime DEFAULT NULL COMMENT '开始时间',
  `END_` datetime DEFAULT NULL COMMENT '结束时间',
  `DURATION_` decimal(19,0) DEFAULT NULL COMMENT '持续时间',
  `TRANSITION_` varchar(255) DEFAULT NULL COMMENT '转移(Transition)的name值',
  `NEXTIDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT '暂时不启用',
  `DEAL_TYPE_` varchar(255) DEFAULT NULL COMMENT '处理类型',
  `ALIAS_` varchar(255) DEFAULT NULL COMMENT '节点别名',
  `HIST_ACTI_PRE_` varchar(50) DEFAULT NULL COMMENT '上一节点dbid_',
  `SUPEREXEC_` varchar(50) DEFAULT NULL COMMENT '主流程dbid_',
  `ISINGROUP_` varchar(10) DEFAULT NULL COMMENT '该节点是否在group中',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_actinst_ext2` */

/*Table structure for table `bpm_hist_actinst_ext3` */

DROP TABLE IF EXISTS `bpm_hist_actinst_ext3`;

CREATE TABLE `bpm_hist_actinst_ext3` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id；bpm_hist_procinst表dbid_',
  `TYPE_` varchar(255) DEFAULT NULL COMMENT '节点类型',
  `EXECUTION_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表id_',
  `ACTIVITY_NAME_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表activity_name_',
  `START_` datetime DEFAULT NULL COMMENT '开始时间',
  `END_` datetime DEFAULT NULL COMMENT '结束时间',
  `DURATION_` decimal(19,0) DEFAULT NULL COMMENT '持续时间',
  `TRANSITION_` varchar(255) DEFAULT NULL COMMENT '转移(Transition)的name值',
  `NEXTIDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT '暂时不启用',
  `DEAL_TYPE_` varchar(255) DEFAULT NULL COMMENT '处理类型',
  `ALIAS_` varchar(255) DEFAULT NULL COMMENT '节点别名',
  `HIST_ACTI_PRE_` varchar(50) DEFAULT NULL COMMENT '上一节点dbid_',
  `SUPEREXEC_` varchar(50) DEFAULT NULL COMMENT '主流程dbid_',
  `ISINGROUP_` varchar(10) DEFAULT NULL COMMENT '该节点是否在group中',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_actinst_ext3` */

/*Table structure for table `bpm_hist_actinst_ext4` */

DROP TABLE IF EXISTS `bpm_hist_actinst_ext4`;

CREATE TABLE `bpm_hist_actinst_ext4` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id；bpm_hist_procinst表dbid_',
  `TYPE_` varchar(255) DEFAULT NULL COMMENT '节点类型',
  `EXECUTION_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表id_',
  `ACTIVITY_NAME_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表activity_name_',
  `START_` datetime DEFAULT NULL COMMENT '开始时间',
  `END_` datetime DEFAULT NULL COMMENT '结束时间',
  `DURATION_` decimal(19,0) DEFAULT NULL COMMENT '持续时间',
  `TRANSITION_` varchar(255) DEFAULT NULL COMMENT '转移(Transition)的name值',
  `NEXTIDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT '暂时不启用',
  `DEAL_TYPE_` varchar(255) DEFAULT NULL COMMENT '处理类型',
  `ALIAS_` varchar(255) DEFAULT NULL COMMENT '节点别名',
  `HIST_ACTI_PRE_` varchar(50) DEFAULT NULL COMMENT '上一节点dbid_',
  `SUPEREXEC_` varchar(50) DEFAULT NULL COMMENT '主流程dbid_',
  `ISINGROUP_` varchar(10) DEFAULT NULL COMMENT '该节点是否在group中',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_actinst_ext4` */

/*Table structure for table `bpm_hist_actinst_ext5` */

DROP TABLE IF EXISTS `bpm_hist_actinst_ext5`;

CREATE TABLE `bpm_hist_actinst_ext5` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id；bpm_hist_procinst表dbid_',
  `TYPE_` varchar(255) DEFAULT NULL COMMENT '节点类型',
  `EXECUTION_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表id_',
  `ACTIVITY_NAME_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表activity_name_',
  `START_` datetime DEFAULT NULL COMMENT '开始时间',
  `END_` datetime DEFAULT NULL COMMENT '结束时间',
  `DURATION_` decimal(19,0) DEFAULT NULL COMMENT '持续时间',
  `TRANSITION_` varchar(255) DEFAULT NULL COMMENT '转移(Transition)的name值',
  `NEXTIDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT '暂时不启用',
  `DEAL_TYPE_` varchar(255) DEFAULT NULL COMMENT '处理类型',
  `ALIAS_` varchar(255) DEFAULT NULL COMMENT '节点别名',
  `HIST_ACTI_PRE_` varchar(50) DEFAULT NULL COMMENT '上一节点dbid_',
  `SUPEREXEC_` varchar(50) DEFAULT NULL COMMENT '主流程dbid_',
  `ISINGROUP_` varchar(10) DEFAULT NULL COMMENT '该节点是否在group中',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_actinst_ext5` */

/*Table structure for table `bpm_hist_actinst_ext6` */

DROP TABLE IF EXISTS `bpm_hist_actinst_ext6`;

CREATE TABLE `bpm_hist_actinst_ext6` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id；bpm_hist_procinst表dbid_',
  `TYPE_` varchar(255) DEFAULT NULL COMMENT '节点类型',
  `EXECUTION_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表id_',
  `ACTIVITY_NAME_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表activity_name_',
  `START_` datetime DEFAULT NULL COMMENT '开始时间',
  `END_` datetime DEFAULT NULL COMMENT '结束时间',
  `DURATION_` decimal(19,0) DEFAULT NULL COMMENT '持续时间',
  `TRANSITION_` varchar(255) DEFAULT NULL COMMENT '转移(Transition)的name值',
  `NEXTIDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT '暂时不启用',
  `DEAL_TYPE_` varchar(255) DEFAULT NULL COMMENT '处理类型',
  `ALIAS_` varchar(255) DEFAULT NULL COMMENT '节点别名',
  `HIST_ACTI_PRE_` varchar(50) DEFAULT NULL COMMENT '上一节点dbid_',
  `SUPEREXEC_` varchar(50) DEFAULT NULL COMMENT '主流程dbid_',
  `ISINGROUP_` varchar(10) DEFAULT NULL COMMENT '该节点是否在group中',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_actinst_ext6` */

/*Table structure for table `bpm_hist_actinst_ext7` */

DROP TABLE IF EXISTS `bpm_hist_actinst_ext7`;

CREATE TABLE `bpm_hist_actinst_ext7` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id；bpm_hist_procinst表dbid_',
  `TYPE_` varchar(255) DEFAULT NULL COMMENT '节点类型',
  `EXECUTION_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表id_',
  `ACTIVITY_NAME_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表activity_name_',
  `START_` datetime DEFAULT NULL COMMENT '开始时间',
  `END_` datetime DEFAULT NULL COMMENT '结束时间',
  `DURATION_` decimal(19,0) DEFAULT NULL COMMENT '持续时间',
  `TRANSITION_` varchar(255) DEFAULT NULL COMMENT '转移(Transition)的name值',
  `NEXTIDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT '暂时不启用',
  `DEAL_TYPE_` varchar(255) DEFAULT NULL COMMENT '处理类型',
  `ALIAS_` varchar(255) DEFAULT NULL COMMENT '节点别名',
  `HIST_ACTI_PRE_` varchar(50) DEFAULT NULL COMMENT '上一节点dbid_',
  `SUPEREXEC_` varchar(50) DEFAULT NULL COMMENT '主流程dbid_',
  `ISINGROUP_` varchar(10) DEFAULT NULL COMMENT '该节点是否在group中',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_actinst_ext7` */

/*Table structure for table `bpm_hist_actinst_ext8` */

DROP TABLE IF EXISTS `bpm_hist_actinst_ext8`;

CREATE TABLE `bpm_hist_actinst_ext8` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id；bpm_hist_procinst表dbid_',
  `TYPE_` varchar(255) DEFAULT NULL COMMENT '节点类型',
  `EXECUTION_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表id_',
  `ACTIVITY_NAME_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表activity_name_',
  `START_` datetime DEFAULT NULL COMMENT '开始时间',
  `END_` datetime DEFAULT NULL COMMENT '结束时间',
  `DURATION_` decimal(19,0) DEFAULT NULL COMMENT '持续时间',
  `TRANSITION_` varchar(255) DEFAULT NULL COMMENT '转移(Transition)的name值',
  `NEXTIDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT '暂时不启用',
  `DEAL_TYPE_` varchar(255) DEFAULT NULL COMMENT '处理类型',
  `ALIAS_` varchar(255) DEFAULT NULL COMMENT '节点别名',
  `HIST_ACTI_PRE_` varchar(50) DEFAULT NULL COMMENT '上一节点dbid_',
  `SUPEREXEC_` varchar(50) DEFAULT NULL COMMENT '主流程dbid_',
  `ISINGROUP_` varchar(10) DEFAULT NULL COMMENT '该节点是否在group中',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_actinst_ext8` */

/*Table structure for table `bpm_hist_actinst_prev` */

DROP TABLE IF EXISTS `bpm_hist_actinst_prev`;

CREATE TABLE `bpm_hist_actinst_prev` (
  `DBID_` varchar(50) NOT NULL,
  `PREVIOUSID_` varchar(50) NOT NULL,
  `EXECUTION_` varchar(255) DEFAULT NULL,
  `HPROCI_` varchar(50) DEFAULT NULL,
  `TYPE_` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_actinst_prev` */

/*Table structure for table `bpm_hist_actinst_prev_ext1` */

DROP TABLE IF EXISTS `bpm_hist_actinst_prev_ext1`;

CREATE TABLE `bpm_hist_actinst_prev_ext1` (
  `DBID_` varchar(50) NOT NULL,
  `PREVIOUSID_` varchar(50) NOT NULL,
  `EXECUTION_` varchar(255) DEFAULT NULL,
  `HPROCI_` varchar(50) DEFAULT NULL,
  `TYPE_` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_actinst_prev_ext1` */

/*Table structure for table `bpm_hist_actinst_prev_ext2` */

DROP TABLE IF EXISTS `bpm_hist_actinst_prev_ext2`;

CREATE TABLE `bpm_hist_actinst_prev_ext2` (
  `DBID_` varchar(50) NOT NULL,
  `PREVIOUSID_` varchar(50) NOT NULL,
  `EXECUTION_` varchar(255) DEFAULT NULL,
  `HPROCI_` varchar(50) DEFAULT NULL,
  `TYPE_` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_actinst_prev_ext2` */

/*Table structure for table `bpm_hist_actinst_prev_ext3` */

DROP TABLE IF EXISTS `bpm_hist_actinst_prev_ext3`;

CREATE TABLE `bpm_hist_actinst_prev_ext3` (
  `DBID_` varchar(50) NOT NULL,
  `PREVIOUSID_` varchar(50) NOT NULL,
  `EXECUTION_` varchar(255) DEFAULT NULL,
  `HPROCI_` varchar(50) DEFAULT NULL,
  `TYPE_` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_actinst_prev_ext3` */

/*Table structure for table `bpm_hist_actinst_prev_ext4` */

DROP TABLE IF EXISTS `bpm_hist_actinst_prev_ext4`;

CREATE TABLE `bpm_hist_actinst_prev_ext4` (
  `DBID_` varchar(50) NOT NULL,
  `PREVIOUSID_` varchar(50) NOT NULL,
  `EXECUTION_` varchar(255) DEFAULT NULL,
  `HPROCI_` varchar(50) DEFAULT NULL,
  `TYPE_` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_actinst_prev_ext4` */

/*Table structure for table `bpm_hist_actinst_prev_ext5` */

DROP TABLE IF EXISTS `bpm_hist_actinst_prev_ext5`;

CREATE TABLE `bpm_hist_actinst_prev_ext5` (
  `DBID_` varchar(50) NOT NULL,
  `PREVIOUSID_` varchar(50) NOT NULL,
  `EXECUTION_` varchar(255) DEFAULT NULL,
  `HPROCI_` varchar(50) DEFAULT NULL,
  `TYPE_` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_actinst_prev_ext5` */

/*Table structure for table `bpm_hist_actinst_prev_ext6` */

DROP TABLE IF EXISTS `bpm_hist_actinst_prev_ext6`;

CREATE TABLE `bpm_hist_actinst_prev_ext6` (
  `DBID_` varchar(50) NOT NULL,
  `PREVIOUSID_` varchar(50) NOT NULL,
  `EXECUTION_` varchar(255) DEFAULT NULL,
  `HPROCI_` varchar(50) DEFAULT NULL,
  `TYPE_` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_actinst_prev_ext6` */

/*Table structure for table `bpm_hist_actinst_prev_ext7` */

DROP TABLE IF EXISTS `bpm_hist_actinst_prev_ext7`;

CREATE TABLE `bpm_hist_actinst_prev_ext7` (
  `DBID_` varchar(50) NOT NULL,
  `PREVIOUSID_` varchar(50) NOT NULL,
  `EXECUTION_` varchar(255) DEFAULT NULL,
  `HPROCI_` varchar(50) DEFAULT NULL,
  `TYPE_` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_actinst_prev_ext7` */

/*Table structure for table `bpm_hist_actinst_prev_ext8` */

DROP TABLE IF EXISTS `bpm_hist_actinst_prev_ext8`;

CREATE TABLE `bpm_hist_actinst_prev_ext8` (
  `DBID_` varchar(50) NOT NULL,
  `PREVIOUSID_` varchar(50) NOT NULL,
  `EXECUTION_` varchar(255) DEFAULT NULL,
  `HPROCI_` varchar(50) DEFAULT NULL,
  `TYPE_` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_actinst_prev_ext8` */

/*Table structure for table `bpm_hist_detail` */

DROP TABLE IF EXISTS `bpm_hist_detail`;

CREATE TABLE `bpm_hist_detail` (
  `DBID_` varchar(50) NOT NULL,
  `CLASS_` varchar(255) NOT NULL,
  `DBVERSION_` decimal(10,0) NOT NULL,
  `USERID_` varchar(255) DEFAULT NULL,
  `TIME_` datetime DEFAULT NULL,
  `HPROCI_` varchar(50) DEFAULT NULL,
  `HPROCIIDX_` decimal(10,0) DEFAULT NULL,
  `HACTI_` varchar(50) DEFAULT NULL,
  `HACTIIDX_` decimal(10,0) DEFAULT NULL,
  `HTASK_` varchar(50) DEFAULT NULL,
  `HTASKIDX_` decimal(10,0) DEFAULT NULL,
  `HVAR_` varchar(50) DEFAULT NULL,
  `HVARIDX_` decimal(10,0) DEFAULT NULL,
  `MESSAGE_` longtext,
  `OLD_STR_` varchar(255) DEFAULT NULL,
  `NEW_STR_` varchar(255) DEFAULT NULL,
  `OLD_INT_` decimal(10,0) DEFAULT NULL,
  `NEW_INT_` decimal(10,0) DEFAULT NULL,
  `OLD_TIME_` datetime DEFAULT NULL,
  `NEW_TIME_` datetime DEFAULT NULL,
  `PARENT_` varchar(50) DEFAULT NULL,
  `PARENT_IDX_` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_detail` */

/*Table structure for table `bpm_hist_procinst` */

DROP TABLE IF EXISTS `bpm_hist_procinst`;

CREATE TABLE `bpm_hist_procinst` (
  `DBID_` varchar(50) NOT NULL,
  `DBVERSION_` decimal(10,0) NOT NULL,
  `ID_` varchar(255) DEFAULT NULL,
  `PROCDEFID_` varchar(255) DEFAULT NULL,
  `KEY_` varchar(255) DEFAULT NULL,
  `START_` datetime DEFAULT NULL,
  `END_` datetime DEFAULT NULL,
  `DURATION_` decimal(19,0) DEFAULT NULL,
  `STATE_` varchar(255) DEFAULT NULL,
  `ENDACTIVITY_` varchar(255) DEFAULT NULL,
  `NEXTIDX_` decimal(10,0) DEFAULT NULL,
  `FORMID_` varchar(50) DEFAULT NULL,
  `TITLE_` varchar(255) DEFAULT NULL,
  `USERID_` varchar(255) DEFAULT NULL,
  `DEPTID_` varchar(255) DEFAULT NULL,
  `BUSINESSSTATE_` varchar(255) DEFAULT NULL,
  `FORM_CODE_` varchar(50) DEFAULT NULL COMMENT '所属全局表单CODE',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_procinst` */

/*Table structure for table `bpm_hist_task` */

DROP TABLE IF EXISTS `bpm_hist_task`;

CREATE TABLE `bpm_hist_task` (
  `DBID_` varchar(50) NOT NULL,
  `DBVERSION_` decimal(10,0) NOT NULL,
  `EXECUTION_` varchar(255) DEFAULT NULL,
  `OUTCOME_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_` varchar(255) DEFAULT NULL,
  `PRIORITY_` decimal(10,0) DEFAULT NULL,
  `STATE_` varchar(255) DEFAULT NULL,
  `CREATE_` datetime DEFAULT NULL,
  `END_` datetime DEFAULT NULL,
  `DURATION_` decimal(19,0) DEFAULT NULL,
  `NEXTIDX_` decimal(10,0) DEFAULT NULL,
  `SUPERTASK_` varchar(50) DEFAULT NULL,
  `TASK_ORDER_` varchar(255) DEFAULT NULL,
  `OPEN_` datetime DEFAULT NULL,
  `TAKE_STATE_` varchar(255) DEFAULT NULL,
  `PROCINST_` varchar(50) DEFAULT NULL,
  `DESCR_` longtext,
  `SUSPHISTSTATE_` varchar(255) DEFAULT NULL,
  `TASK_TYPE_` varchar(255) DEFAULT NULL,
  `TASK_B_ID_` varchar(255) DEFAULT NULL,
  `TASK_TITLE_` varchar(255) DEFAULT NULL,
  `TASK_SENDUSER_` varchar(255) DEFAULT NULL,
  `TASK_SENDDEPT_` varchar(255) DEFAULT NULL,
  `FORM_` varchar(255) DEFAULT NULL,
  `PROCESS_DEF_NAME_` varchar(255) DEFAULT NULL,
  `TASK_FINISHED_` varchar(255) DEFAULT NULL,
  `TASK_STATE_` varchar(255) DEFAULT NULL,
  `TASK_NAME_` varchar(255) DEFAULT NULL,
  `HISACTINST_` varchar(50) DEFAULT NULL,
  `WORKHAND_TYPE_` varchar(255) DEFAULT NULL,
  `WORKHAND_USER_` varchar(255) DEFAULT NULL,
  `APP_ID_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_DEPT_` varchar(255) DEFAULT NULL,
  `IS_READTODO_` varchar(2) DEFAULT NULL COMMENT '标识业务传阅节点',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_task` */

/*Table structure for table `bpm_hist_task_ext1` */

DROP TABLE IF EXISTS `bpm_hist_task_ext1`;

CREATE TABLE `bpm_hist_task_ext1` (
  `DBID_` varchar(50) NOT NULL,
  `DBVERSION_` decimal(10,0) NOT NULL,
  `EXECUTION_` varchar(255) DEFAULT NULL,
  `OUTCOME_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_` varchar(255) DEFAULT NULL,
  `PRIORITY_` decimal(10,0) DEFAULT NULL,
  `STATE_` varchar(255) DEFAULT NULL,
  `CREATE_` datetime DEFAULT NULL,
  `END_` datetime DEFAULT NULL,
  `DURATION_` decimal(19,0) DEFAULT NULL,
  `NEXTIDX_` decimal(10,0) DEFAULT NULL,
  `SUPERTASK_` varchar(50) DEFAULT NULL,
  `TASK_ORDER_` varchar(255) DEFAULT NULL,
  `OPEN_` datetime DEFAULT NULL,
  `TAKE_STATE_` varchar(255) DEFAULT NULL,
  `PROCINST_` varchar(50) DEFAULT NULL,
  `DESCR_` longtext,
  `SUSPHISTSTATE_` varchar(255) DEFAULT NULL,
  `TASK_TYPE_` varchar(255) DEFAULT NULL,
  `TASK_B_ID_` varchar(255) DEFAULT NULL,
  `TASK_TITLE_` varchar(255) DEFAULT NULL,
  `TASK_SENDUSER_` varchar(255) DEFAULT NULL,
  `TASK_SENDDEPT_` varchar(255) DEFAULT NULL,
  `FORM_` varchar(255) DEFAULT NULL,
  `PROCESS_DEF_NAME_` varchar(255) DEFAULT NULL,
  `TASK_FINISHED_` varchar(255) DEFAULT NULL,
  `TASK_STATE_` varchar(255) DEFAULT NULL,
  `TASK_NAME_` varchar(255) DEFAULT NULL,
  `HISACTINST_` varchar(50) DEFAULT NULL,
  `WORKHAND_TYPE_` varchar(255) DEFAULT NULL,
  `WORKHAND_USER_` varchar(255) DEFAULT NULL,
  `APP_ID_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_DEPT_` varchar(255) DEFAULT NULL,
  `IS_READTODO_` varchar(2) DEFAULT NULL COMMENT '标识业务传阅节点',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_task_ext1` */

/*Table structure for table `bpm_hist_task_ext2` */

DROP TABLE IF EXISTS `bpm_hist_task_ext2`;

CREATE TABLE `bpm_hist_task_ext2` (
  `DBID_` varchar(50) NOT NULL,
  `DBVERSION_` decimal(10,0) NOT NULL,
  `EXECUTION_` varchar(255) DEFAULT NULL,
  `OUTCOME_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_` varchar(255) DEFAULT NULL,
  `PRIORITY_` decimal(10,0) DEFAULT NULL,
  `STATE_` varchar(255) DEFAULT NULL,
  `CREATE_` datetime DEFAULT NULL,
  `END_` datetime DEFAULT NULL,
  `DURATION_` decimal(19,0) DEFAULT NULL,
  `NEXTIDX_` decimal(10,0) DEFAULT NULL,
  `SUPERTASK_` varchar(50) DEFAULT NULL,
  `TASK_ORDER_` varchar(255) DEFAULT NULL,
  `OPEN_` datetime DEFAULT NULL,
  `TAKE_STATE_` varchar(255) DEFAULT NULL,
  `PROCINST_` varchar(50) DEFAULT NULL,
  `DESCR_` longtext,
  `SUSPHISTSTATE_` varchar(255) DEFAULT NULL,
  `TASK_TYPE_` varchar(255) DEFAULT NULL,
  `TASK_B_ID_` varchar(255) DEFAULT NULL,
  `TASK_TITLE_` varchar(255) DEFAULT NULL,
  `TASK_SENDUSER_` varchar(255) DEFAULT NULL,
  `TASK_SENDDEPT_` varchar(255) DEFAULT NULL,
  `FORM_` varchar(255) DEFAULT NULL,
  `PROCESS_DEF_NAME_` varchar(255) DEFAULT NULL,
  `TASK_FINISHED_` varchar(255) DEFAULT NULL,
  `TASK_STATE_` varchar(255) DEFAULT NULL,
  `TASK_NAME_` varchar(255) DEFAULT NULL,
  `HISACTINST_` varchar(50) DEFAULT NULL,
  `WORKHAND_TYPE_` varchar(255) DEFAULT NULL,
  `WORKHAND_USER_` varchar(255) DEFAULT NULL,
  `APP_ID_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_DEPT_` varchar(255) DEFAULT NULL,
  `IS_READTODO_` varchar(2) DEFAULT NULL COMMENT '标识业务传阅节点',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_task_ext2` */

/*Table structure for table `bpm_hist_task_ext3` */

DROP TABLE IF EXISTS `bpm_hist_task_ext3`;

CREATE TABLE `bpm_hist_task_ext3` (
  `DBID_` varchar(50) NOT NULL,
  `DBVERSION_` decimal(10,0) NOT NULL,
  `EXECUTION_` varchar(255) DEFAULT NULL,
  `OUTCOME_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_` varchar(255) DEFAULT NULL,
  `PRIORITY_` decimal(10,0) DEFAULT NULL,
  `STATE_` varchar(255) DEFAULT NULL,
  `CREATE_` datetime DEFAULT NULL,
  `END_` datetime DEFAULT NULL,
  `DURATION_` decimal(19,0) DEFAULT NULL,
  `NEXTIDX_` decimal(10,0) DEFAULT NULL,
  `SUPERTASK_` varchar(50) DEFAULT NULL,
  `TASK_ORDER_` varchar(255) DEFAULT NULL,
  `OPEN_` datetime DEFAULT NULL,
  `TAKE_STATE_` varchar(255) DEFAULT NULL,
  `PROCINST_` varchar(50) DEFAULT NULL,
  `DESCR_` longtext,
  `SUSPHISTSTATE_` varchar(255) DEFAULT NULL,
  `TASK_TYPE_` varchar(255) DEFAULT NULL,
  `TASK_B_ID_` varchar(255) DEFAULT NULL,
  `TASK_TITLE_` varchar(255) DEFAULT NULL,
  `TASK_SENDUSER_` varchar(255) DEFAULT NULL,
  `TASK_SENDDEPT_` varchar(255) DEFAULT NULL,
  `FORM_` varchar(255) DEFAULT NULL,
  `PROCESS_DEF_NAME_` varchar(255) DEFAULT NULL,
  `TASK_FINISHED_` varchar(255) DEFAULT NULL,
  `TASK_STATE_` varchar(255) DEFAULT NULL,
  `TASK_NAME_` varchar(255) DEFAULT NULL,
  `HISACTINST_` varchar(50) DEFAULT NULL,
  `WORKHAND_TYPE_` varchar(255) DEFAULT NULL,
  `WORKHAND_USER_` varchar(255) DEFAULT NULL,
  `APP_ID_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_DEPT_` varchar(255) DEFAULT NULL,
  `IS_READTODO_` varchar(2) DEFAULT NULL COMMENT '标识业务传阅节点',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_task_ext3` */

/*Table structure for table `bpm_hist_task_ext4` */

DROP TABLE IF EXISTS `bpm_hist_task_ext4`;

CREATE TABLE `bpm_hist_task_ext4` (
  `DBID_` varchar(50) NOT NULL,
  `DBVERSION_` decimal(10,0) NOT NULL,
  `EXECUTION_` varchar(255) DEFAULT NULL,
  `OUTCOME_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_` varchar(255) DEFAULT NULL,
  `PRIORITY_` decimal(10,0) DEFAULT NULL,
  `STATE_` varchar(255) DEFAULT NULL,
  `CREATE_` datetime DEFAULT NULL,
  `END_` datetime DEFAULT NULL,
  `DURATION_` decimal(19,0) DEFAULT NULL,
  `NEXTIDX_` decimal(10,0) DEFAULT NULL,
  `SUPERTASK_` varchar(50) DEFAULT NULL,
  `TASK_ORDER_` varchar(255) DEFAULT NULL,
  `OPEN_` datetime DEFAULT NULL,
  `TAKE_STATE_` varchar(255) DEFAULT NULL,
  `PROCINST_` varchar(50) DEFAULT NULL,
  `DESCR_` longtext,
  `SUSPHISTSTATE_` varchar(255) DEFAULT NULL,
  `TASK_TYPE_` varchar(255) DEFAULT NULL,
  `TASK_B_ID_` varchar(255) DEFAULT NULL,
  `TASK_TITLE_` varchar(255) DEFAULT NULL,
  `TASK_SENDUSER_` varchar(255) DEFAULT NULL,
  `TASK_SENDDEPT_` varchar(255) DEFAULT NULL,
  `FORM_` varchar(255) DEFAULT NULL,
  `PROCESS_DEF_NAME_` varchar(255) DEFAULT NULL,
  `TASK_FINISHED_` varchar(255) DEFAULT NULL,
  `TASK_STATE_` varchar(255) DEFAULT NULL,
  `TASK_NAME_` varchar(255) DEFAULT NULL,
  `HISACTINST_` varchar(50) DEFAULT NULL,
  `WORKHAND_TYPE_` varchar(255) DEFAULT NULL,
  `WORKHAND_USER_` varchar(255) DEFAULT NULL,
  `APP_ID_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_DEPT_` varchar(255) DEFAULT NULL,
  `IS_READTODO_` varchar(2) DEFAULT NULL COMMENT '标识业务传阅节点',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_task_ext4` */

/*Table structure for table `bpm_hist_task_ext5` */

DROP TABLE IF EXISTS `bpm_hist_task_ext5`;

CREATE TABLE `bpm_hist_task_ext5` (
  `DBID_` varchar(50) NOT NULL,
  `DBVERSION_` decimal(10,0) NOT NULL,
  `EXECUTION_` varchar(255) DEFAULT NULL,
  `OUTCOME_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_` varchar(255) DEFAULT NULL,
  `PRIORITY_` decimal(10,0) DEFAULT NULL,
  `STATE_` varchar(255) DEFAULT NULL,
  `CREATE_` datetime DEFAULT NULL,
  `END_` datetime DEFAULT NULL,
  `DURATION_` decimal(19,0) DEFAULT NULL,
  `NEXTIDX_` decimal(10,0) DEFAULT NULL,
  `SUPERTASK_` varchar(50) DEFAULT NULL,
  `TASK_ORDER_` varchar(255) DEFAULT NULL,
  `OPEN_` datetime DEFAULT NULL,
  `TAKE_STATE_` varchar(255) DEFAULT NULL,
  `PROCINST_` varchar(50) DEFAULT NULL,
  `DESCR_` longtext,
  `SUSPHISTSTATE_` varchar(255) DEFAULT NULL,
  `TASK_TYPE_` varchar(255) DEFAULT NULL,
  `TASK_B_ID_` varchar(255) DEFAULT NULL,
  `TASK_TITLE_` varchar(255) DEFAULT NULL,
  `TASK_SENDUSER_` varchar(255) DEFAULT NULL,
  `TASK_SENDDEPT_` varchar(255) DEFAULT NULL,
  `FORM_` varchar(255) DEFAULT NULL,
  `PROCESS_DEF_NAME_` varchar(255) DEFAULT NULL,
  `TASK_FINISHED_` varchar(255) DEFAULT NULL,
  `TASK_STATE_` varchar(255) DEFAULT NULL,
  `TASK_NAME_` varchar(255) DEFAULT NULL,
  `HISACTINST_` varchar(50) DEFAULT NULL,
  `WORKHAND_TYPE_` varchar(255) DEFAULT NULL,
  `WORKHAND_USER_` varchar(255) DEFAULT NULL,
  `APP_ID_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_DEPT_` varchar(255) DEFAULT NULL,
  `IS_READTODO_` varchar(2) DEFAULT NULL COMMENT '标识业务传阅节点',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_task_ext5` */

/*Table structure for table `bpm_hist_task_ext6` */

DROP TABLE IF EXISTS `bpm_hist_task_ext6`;

CREATE TABLE `bpm_hist_task_ext6` (
  `DBID_` varchar(50) NOT NULL,
  `DBVERSION_` decimal(10,0) NOT NULL,
  `EXECUTION_` varchar(255) DEFAULT NULL,
  `OUTCOME_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_` varchar(255) DEFAULT NULL,
  `PRIORITY_` decimal(10,0) DEFAULT NULL,
  `STATE_` varchar(255) DEFAULT NULL,
  `CREATE_` datetime DEFAULT NULL,
  `END_` datetime DEFAULT NULL,
  `DURATION_` decimal(19,0) DEFAULT NULL,
  `NEXTIDX_` decimal(10,0) DEFAULT NULL,
  `SUPERTASK_` varchar(50) DEFAULT NULL,
  `TASK_ORDER_` varchar(255) DEFAULT NULL,
  `OPEN_` datetime DEFAULT NULL,
  `TAKE_STATE_` varchar(255) DEFAULT NULL,
  `PROCINST_` varchar(50) DEFAULT NULL,
  `DESCR_` longtext,
  `SUSPHISTSTATE_` varchar(255) DEFAULT NULL,
  `TASK_TYPE_` varchar(255) DEFAULT NULL,
  `TASK_B_ID_` varchar(255) DEFAULT NULL,
  `TASK_TITLE_` varchar(255) DEFAULT NULL,
  `TASK_SENDUSER_` varchar(255) DEFAULT NULL,
  `TASK_SENDDEPT_` varchar(255) DEFAULT NULL,
  `FORM_` varchar(255) DEFAULT NULL,
  `PROCESS_DEF_NAME_` varchar(255) DEFAULT NULL,
  `TASK_FINISHED_` varchar(255) DEFAULT NULL,
  `TASK_STATE_` varchar(255) DEFAULT NULL,
  `TASK_NAME_` varchar(255) DEFAULT NULL,
  `HISACTINST_` varchar(50) DEFAULT NULL,
  `WORKHAND_TYPE_` varchar(255) DEFAULT NULL,
  `WORKHAND_USER_` varchar(255) DEFAULT NULL,
  `APP_ID_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_DEPT_` varchar(255) DEFAULT NULL,
  `IS_READTODO_` varchar(2) DEFAULT NULL COMMENT '标识业务传阅节点',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_task_ext6` */

/*Table structure for table `bpm_hist_task_ext7` */

DROP TABLE IF EXISTS `bpm_hist_task_ext7`;

CREATE TABLE `bpm_hist_task_ext7` (
  `DBID_` varchar(50) NOT NULL,
  `DBVERSION_` decimal(10,0) NOT NULL,
  `EXECUTION_` varchar(255) DEFAULT NULL,
  `OUTCOME_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_` varchar(255) DEFAULT NULL,
  `PRIORITY_` decimal(10,0) DEFAULT NULL,
  `STATE_` varchar(255) DEFAULT NULL,
  `CREATE_` datetime DEFAULT NULL,
  `END_` datetime DEFAULT NULL,
  `DURATION_` decimal(19,0) DEFAULT NULL,
  `NEXTIDX_` decimal(10,0) DEFAULT NULL,
  `SUPERTASK_` varchar(50) DEFAULT NULL,
  `TASK_ORDER_` varchar(255) DEFAULT NULL,
  `OPEN_` datetime DEFAULT NULL,
  `TAKE_STATE_` varchar(255) DEFAULT NULL,
  `PROCINST_` varchar(50) DEFAULT NULL,
  `DESCR_` longtext,
  `SUSPHISTSTATE_` varchar(255) DEFAULT NULL,
  `TASK_TYPE_` varchar(255) DEFAULT NULL,
  `TASK_B_ID_` varchar(255) DEFAULT NULL,
  `TASK_TITLE_` varchar(255) DEFAULT NULL,
  `TASK_SENDUSER_` varchar(255) DEFAULT NULL,
  `TASK_SENDDEPT_` varchar(255) DEFAULT NULL,
  `FORM_` varchar(255) DEFAULT NULL,
  `PROCESS_DEF_NAME_` varchar(255) DEFAULT NULL,
  `TASK_FINISHED_` varchar(255) DEFAULT NULL,
  `TASK_STATE_` varchar(255) DEFAULT NULL,
  `TASK_NAME_` varchar(255) DEFAULT NULL,
  `HISACTINST_` varchar(50) DEFAULT NULL,
  `WORKHAND_TYPE_` varchar(255) DEFAULT NULL,
  `WORKHAND_USER_` varchar(255) DEFAULT NULL,
  `APP_ID_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_DEPT_` varchar(255) DEFAULT NULL,
  `IS_READTODO_` varchar(2) DEFAULT NULL COMMENT '标识业务传阅节点',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_task_ext7` */

/*Table structure for table `bpm_hist_task_ext8` */

DROP TABLE IF EXISTS `bpm_hist_task_ext8`;

CREATE TABLE `bpm_hist_task_ext8` (
  `DBID_` varchar(50) NOT NULL,
  `DBVERSION_` decimal(10,0) NOT NULL,
  `EXECUTION_` varchar(255) DEFAULT NULL,
  `OUTCOME_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_` varchar(255) DEFAULT NULL,
  `PRIORITY_` decimal(10,0) DEFAULT NULL,
  `STATE_` varchar(255) DEFAULT NULL,
  `CREATE_` datetime DEFAULT NULL,
  `END_` datetime DEFAULT NULL,
  `DURATION_` decimal(19,0) DEFAULT NULL,
  `NEXTIDX_` decimal(10,0) DEFAULT NULL,
  `SUPERTASK_` varchar(50) DEFAULT NULL,
  `TASK_ORDER_` varchar(255) DEFAULT NULL,
  `OPEN_` datetime DEFAULT NULL,
  `TAKE_STATE_` varchar(255) DEFAULT NULL,
  `PROCINST_` varchar(50) DEFAULT NULL,
  `DESCR_` longtext,
  `SUSPHISTSTATE_` varchar(255) DEFAULT NULL,
  `TASK_TYPE_` varchar(255) DEFAULT NULL,
  `TASK_B_ID_` varchar(255) DEFAULT NULL,
  `TASK_TITLE_` varchar(255) DEFAULT NULL,
  `TASK_SENDUSER_` varchar(255) DEFAULT NULL,
  `TASK_SENDDEPT_` varchar(255) DEFAULT NULL,
  `FORM_` varchar(255) DEFAULT NULL,
  `PROCESS_DEF_NAME_` varchar(255) DEFAULT NULL,
  `TASK_FINISHED_` varchar(255) DEFAULT NULL,
  `TASK_STATE_` varchar(255) DEFAULT NULL,
  `TASK_NAME_` varchar(255) DEFAULT NULL,
  `HISACTINST_` varchar(50) DEFAULT NULL,
  `WORKHAND_TYPE_` varchar(255) DEFAULT NULL,
  `WORKHAND_USER_` varchar(255) DEFAULT NULL,
  `APP_ID_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_DEPT_` varchar(255) DEFAULT NULL,
  `IS_READTODO_` varchar(2) DEFAULT NULL COMMENT '标识业务传阅节点',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_task_ext8` */

/*Table structure for table `bpm_hist_var` */

DROP TABLE IF EXISTS `bpm_hist_var`;

CREATE TABLE `bpm_hist_var` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `PROCINSTID_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表id_',
  `EXECUTIONID_` varchar(255) DEFAULT NULL COMMENT '暂时不启用',
  `VARNAME_` varchar(255) DEFAULT NULL COMMENT 'bpm_variable表key_',
  `VALUE_` text COMMENT 'bpm_variable表value_',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT 'bpm_task表dbid_',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_var` */

/*Table structure for table `bpm_hist_var_ext1` */

DROP TABLE IF EXISTS `bpm_hist_var_ext1`;

CREATE TABLE `bpm_hist_var_ext1` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `PROCINSTID_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表id_',
  `EXECUTIONID_` varchar(255) DEFAULT NULL COMMENT '暂时不启用',
  `VARNAME_` varchar(255) DEFAULT NULL COMMENT 'bpm_variable表key_',
  `VALUE_` text COMMENT 'bpm_variable表value_',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT 'bpm_task表dbid_',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_var_ext1` */

/*Table structure for table `bpm_hist_var_ext2` */

DROP TABLE IF EXISTS `bpm_hist_var_ext2`;

CREATE TABLE `bpm_hist_var_ext2` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `PROCINSTID_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表id_',
  `EXECUTIONID_` varchar(255) DEFAULT NULL COMMENT '暂时不启用',
  `VARNAME_` varchar(255) DEFAULT NULL COMMENT 'bpm_variable表key_',
  `VALUE_` text COMMENT 'bpm_variable表value_',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT 'bpm_task表dbid_',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_var_ext2` */

/*Table structure for table `bpm_hist_var_ext3` */

DROP TABLE IF EXISTS `bpm_hist_var_ext3`;

CREATE TABLE `bpm_hist_var_ext3` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `PROCINSTID_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表id_',
  `EXECUTIONID_` varchar(255) DEFAULT NULL COMMENT '暂时不启用',
  `VARNAME_` varchar(255) DEFAULT NULL COMMENT 'bpm_variable表key_',
  `VALUE_` text COMMENT 'bpm_variable表value_',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT 'bpm_task表dbid_',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_var_ext3` */

/*Table structure for table `bpm_hist_var_ext4` */

DROP TABLE IF EXISTS `bpm_hist_var_ext4`;

CREATE TABLE `bpm_hist_var_ext4` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `PROCINSTID_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表id_',
  `EXECUTIONID_` varchar(255) DEFAULT NULL COMMENT '暂时不启用',
  `VARNAME_` varchar(255) DEFAULT NULL COMMENT 'bpm_variable表key_',
  `VALUE_` text COMMENT 'bpm_variable表value_',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT 'bpm_task表dbid_',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_var_ext4` */

/*Table structure for table `bpm_hist_var_ext5` */

DROP TABLE IF EXISTS `bpm_hist_var_ext5`;

CREATE TABLE `bpm_hist_var_ext5` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `PROCINSTID_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表id_',
  `EXECUTIONID_` varchar(255) DEFAULT NULL COMMENT '暂时不启用',
  `VARNAME_` varchar(255) DEFAULT NULL COMMENT 'bpm_variable表key_',
  `VALUE_` text COMMENT 'bpm_variable表value_',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT 'bpm_task表dbid_',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_var_ext5` */

/*Table structure for table `bpm_hist_var_ext6` */

DROP TABLE IF EXISTS `bpm_hist_var_ext6`;

CREATE TABLE `bpm_hist_var_ext6` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `PROCINSTID_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表id_',
  `EXECUTIONID_` varchar(255) DEFAULT NULL COMMENT '暂时不启用',
  `VARNAME_` varchar(255) DEFAULT NULL COMMENT 'bpm_variable表key_',
  `VALUE_` text COMMENT 'bpm_variable表value_',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT 'bpm_task表dbid_',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_var_ext6` */

/*Table structure for table `bpm_hist_var_ext7` */

DROP TABLE IF EXISTS `bpm_hist_var_ext7`;

CREATE TABLE `bpm_hist_var_ext7` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `PROCINSTID_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表id_',
  `EXECUTIONID_` varchar(255) DEFAULT NULL COMMENT '暂时不启用',
  `VARNAME_` varchar(255) DEFAULT NULL COMMENT 'bpm_variable表key_',
  `VALUE_` text COMMENT 'bpm_variable表value_',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT 'bpm_task表dbid_',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_var_ext7` */

/*Table structure for table `bpm_hist_var_ext8` */

DROP TABLE IF EXISTS `bpm_hist_var_ext8`;

CREATE TABLE `bpm_hist_var_ext8` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `PROCINSTID_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表id_',
  `EXECUTIONID_` varchar(255) DEFAULT NULL COMMENT '暂时不启用',
  `VARNAME_` varchar(255) DEFAULT NULL COMMENT 'bpm_variable表key_',
  `VALUE_` text COMMENT 'bpm_variable表value_',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT 'bpm_task表dbid_',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_hist_var_ext8` */

/*Table structure for table `bpm_idea_style` */

DROP TABLE IF EXISTS `bpm_idea_style`;

CREATE TABLE `bpm_idea_style` (
  `ID` varchar(50) NOT NULL COMMENT '表ID',
  `TITLE` varchar(50) NOT NULL COMMENT '标题',
  `CODE` varchar(50) NOT NULL COMMENT '代码',
  `ORDERBY` varchar(50) NOT NULL COMMENT '顺序',
  `TYPE` varchar(10) NOT NULL COMMENT '类型',
  `POSITION` text COMMENT '职位',
  `PROCESSDEFINITIONID` varchar(50) NOT NULL COMMENT '流程ID',
  `ACTIVITYALIAS` text NOT NULL COMMENT '显示的节点别名',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ACTIVITYNAME` text COMMENT '显示的节点名称',
  `STYLENAME` varchar(255) DEFAULT NULL COMMENT '样式名称',
  `QUOTEID` text COMMENT '引用ID',
  `SHOWSIGN` varchar(10) DEFAULT NULL COMMENT '是否显示电子签名',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_idea_style` */

/*Table structure for table `bpm_job` */

DROP TABLE IF EXISTS `bpm_job`;

CREATE TABLE `bpm_job` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `DUEDATE_` datetime DEFAULT NULL COMMENT 'Timer节点的duedate的属性值',
  `STATE_` varchar(255) DEFAULT NULL COMMENT '状态；Waiting、acquired、 error 、suspended',
  `ISEXCLUSIVE_` decimal(1,0) DEFAULT NULL COMMENT '是否高级功能 如：异步调用是高级功能、timer不是高级功能',
  `LOCKOWNER_` varchar(255) DEFAULT NULL COMMENT '执行者',
  `LOCKEXPTIME_` datetime DEFAULT NULL COMMENT '执行时间',
  `EXCEPTION_` longtext COMMENT '异常',
  `RETRIES_` decimal(10,0) DEFAULT NULL COMMENT '重复次数',
  `PROCESSINSTANCE_` varchar(50) DEFAULT NULL COMMENT '流程实例',
  `EXECUTION_` varchar(50) DEFAULT NULL COMMENT 'bpm_execution表id_',
  `CFG_` varchar(50) DEFAULT NULL COMMENT 'bpm_lob表dbid_',
  `SIGNAL_` varchar(255) DEFAULT NULL COMMENT 'timer中的signal属性值',
  `EVENT_` varchar(255) DEFAULT NULL COMMENT 'timer中的event属性值',
  `REPEAT_` varchar(255) DEFAULT NULL COMMENT 'timer中的repeat属性值',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_job` */

/*Table structure for table `bpm_lob` */

DROP TABLE IF EXISTS `bpm_lob`;

CREATE TABLE `bpm_lob` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `BLOB_VALUE_` longblob COMMENT '发布的流程定义文件',
  `DEPLOYMENT_` varchar(50) DEFAULT NULL COMMENT 'bpm_deployment表dbid_',
  `FIGURE_VALUE_` longblob COMMENT '发布的流程图文件',
  `NAME_` varchar(255) DEFAULT NULL COMMENT '流程定义文件中的key属性值',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_lob` */

/*Table structure for table `bpm_lob_ext1` */

DROP TABLE IF EXISTS `bpm_lob_ext1`;

CREATE TABLE `bpm_lob_ext1` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `BLOB_VALUE_` longblob COMMENT '发布的流程定义文件',
  `DEPLOYMENT_` varchar(50) DEFAULT NULL COMMENT 'bpm_deployment表dbid_',
  `FIGURE_VALUE_` longblob COMMENT '发布的流程图文件',
  `NAME_` varchar(255) DEFAULT NULL COMMENT '流程定义文件中的key属性值',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_lob_ext1` */

/*Table structure for table `bpm_lob_ext2` */

DROP TABLE IF EXISTS `bpm_lob_ext2`;

CREATE TABLE `bpm_lob_ext2` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `BLOB_VALUE_` longblob COMMENT '发布的流程定义文件',
  `DEPLOYMENT_` varchar(50) DEFAULT NULL COMMENT 'bpm_deployment表dbid_',
  `FIGURE_VALUE_` longblob COMMENT '发布的流程图文件',
  `NAME_` varchar(255) DEFAULT NULL COMMENT '流程定义文件中的key属性值',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_lob_ext2` */

/*Table structure for table `bpm_lob_ext3` */

DROP TABLE IF EXISTS `bpm_lob_ext3`;

CREATE TABLE `bpm_lob_ext3` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `BLOB_VALUE_` longblob COMMENT '发布的流程定义文件',
  `DEPLOYMENT_` varchar(50) DEFAULT NULL COMMENT 'bpm_deployment表dbid_',
  `FIGURE_VALUE_` longblob COMMENT '发布的流程图文件',
  `NAME_` varchar(255) DEFAULT NULL COMMENT '流程定义文件中的key属性值',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_lob_ext3` */

/*Table structure for table `bpm_lob_ext4` */

DROP TABLE IF EXISTS `bpm_lob_ext4`;

CREATE TABLE `bpm_lob_ext4` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `BLOB_VALUE_` longblob COMMENT '发布的流程定义文件',
  `DEPLOYMENT_` varchar(50) DEFAULT NULL COMMENT 'bpm_deployment表dbid_',
  `FIGURE_VALUE_` longblob COMMENT '发布的流程图文件',
  `NAME_` varchar(255) DEFAULT NULL COMMENT '流程定义文件中的key属性值',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_lob_ext4` */

/*Table structure for table `bpm_lob_ext5` */

DROP TABLE IF EXISTS `bpm_lob_ext5`;

CREATE TABLE `bpm_lob_ext5` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `BLOB_VALUE_` longblob COMMENT '发布的流程定义文件',
  `DEPLOYMENT_` varchar(50) DEFAULT NULL COMMENT 'bpm_deployment表dbid_',
  `FIGURE_VALUE_` longblob COMMENT '发布的流程图文件',
  `NAME_` varchar(255) DEFAULT NULL COMMENT '流程定义文件中的key属性值',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_lob_ext5` */

/*Table structure for table `bpm_lob_ext6` */

DROP TABLE IF EXISTS `bpm_lob_ext6`;

CREATE TABLE `bpm_lob_ext6` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `BLOB_VALUE_` longblob COMMENT '发布的流程定义文件',
  `DEPLOYMENT_` varchar(50) DEFAULT NULL COMMENT 'bpm_deployment表dbid_',
  `FIGURE_VALUE_` longblob COMMENT '发布的流程图文件',
  `NAME_` varchar(255) DEFAULT NULL COMMENT '流程定义文件中的key属性值',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_lob_ext6` */

/*Table structure for table `bpm_lob_ext7` */

DROP TABLE IF EXISTS `bpm_lob_ext7`;

CREATE TABLE `bpm_lob_ext7` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `BLOB_VALUE_` longblob COMMENT '发布的流程定义文件',
  `DEPLOYMENT_` varchar(50) DEFAULT NULL COMMENT 'bpm_deployment表dbid_',
  `FIGURE_VALUE_` longblob COMMENT '发布的流程图文件',
  `NAME_` varchar(255) DEFAULT NULL COMMENT '流程定义文件中的key属性值',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_lob_ext7` */

/*Table structure for table `bpm_lob_ext8` */

DROP TABLE IF EXISTS `bpm_lob_ext8`;

CREATE TABLE `bpm_lob_ext8` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `BLOB_VALUE_` longblob COMMENT '发布的流程定义文件',
  `DEPLOYMENT_` varchar(50) DEFAULT NULL COMMENT 'bpm_deployment表dbid_',
  `FIGURE_VALUE_` longblob COMMENT '发布的流程图文件',
  `NAME_` varchar(255) DEFAULT NULL COMMENT '流程定义文件中的key属性值',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_lob_ext8` */

/*Table structure for table `bpm_operate_desc` */

DROP TABLE IF EXISTS `bpm_operate_desc`;

CREATE TABLE `bpm_operate_desc` (
  `DBID_` varchar(50) NOT NULL,
  `KEYID_` varchar(50) DEFAULT NULL,
  `OPE_DESC` varchar(150) DEFAULT NULL,
  `ATTRIBUTE01` varchar(50) DEFAULT NULL,
  `ATTRIBUTE02` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_operate_desc` */

/*Table structure for table `bpm_participation` */

DROP TABLE IF EXISTS `bpm_participation`;

CREATE TABLE `bpm_participation` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `GROUPID_` varchar(255) DEFAULT NULL COMMENT '暂时不启用',
  `USERID_` varchar(255) DEFAULT NULL COMMENT '处理人',
  `TYPE_` varchar(255) DEFAULT NULL COMMENT '处理人类型',
  `TASK_` varchar(50) DEFAULT NULL COMMENT '任务dbid_',
  `SWIMLANE_` varchar(50) DEFAULT NULL COMMENT '暂时不启用',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_participation` */

/*Table structure for table `bpm_process_def` */

DROP TABLE IF EXISTS `bpm_process_def`;

CREATE TABLE `bpm_process_def` (
  `DBID_` varchar(32) NOT NULL COMMENT '模型主键',
  `KEY_` varchar(100) NOT NULL COMMENT '模型唯一标识',
  `NAME_` varchar(100) NOT NULL COMMENT '模型名称',
  `XML_` longblob NOT NULL COMMENT '模型文件',
  `PNG_` longblob NOT NULL COMMENT '模型图片',
  `DESC_` text COMMENT '模型描述',
  `STATE_` varchar(10) NOT NULL COMMENT '模型状态',
  `APP_` varchar(100) NOT NULL COMMENT '模型所属应用',
  `DEPLOYMENT_` varchar(100) DEFAULT NULL COMMENT '模型发布后的流程定义ID',
  `DESIGNER_` varchar(100) DEFAULT NULL COMMENT '模型设计人',
  `DEPLOYER_` varchar(100) DEFAULT NULL COMMENT '模型发布人',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='流程模型定义表，用于保存未发布前的流程定义模型';

/*Data for the table `bpm_process_def` */

/*Table structure for table `bpm_processdef_rel` */

DROP TABLE IF EXISTS `bpm_processdef_rel`;

CREATE TABLE `bpm_processdef_rel` (
  `DBID_` varchar(32) NOT NULL COMMENT '关系主键',
  `PROCESSDEF_KEY_` varchar(32) NOT NULL COMMENT '模型key',
  `SUBPROCESSDEF_KEY_` varchar(32) NOT NULL COMMENT '子模型key',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='流程模型定义关系表，用于保存流程定义模型主子关系';

/*Data for the table `bpm_processdef_rel` */

/*Table structure for table `bpm_property` */

DROP TABLE IF EXISTS `bpm_property`;

CREATE TABLE `bpm_property` (
  `KEY_` varchar(255) NOT NULL COMMENT 'next.dbid',
  `VERSION_` decimal(10,0) NOT NULL COMMENT '版本',
  `VALUE_` varchar(255) DEFAULT NULL COMMENT '产生的dbid_',
  PRIMARY KEY (`KEY_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_property` */

/*Table structure for table `bpm_select_person` */

DROP TABLE IF EXISTS `bpm_select_person`;

CREATE TABLE `bpm_select_person` (
  `ID` varchar(32) NOT NULL COMMENT '主键',
  `ENTRY_ID` varchar(32) NOT NULL COMMENT '流程实例ID',
  `STEP_ID` varchar(32) NOT NULL COMMENT '流程步骤ID',
  `OPERATION_USER_ID` varchar(32) NOT NULL COMMENT '流程选人修改人',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '最近修改的IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `SELECT_USER_ID` longtext COMMENT '步骤操作人',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='自定义选人配置表';

/*Data for the table `bpm_select_person` */

/*Table structure for table `bpm_swimlane` */

DROP TABLE IF EXISTS `bpm_swimlane`;

CREATE TABLE `bpm_swimlane` (
  `DBID_` varchar(50) NOT NULL,
  `DBVERSION_` decimal(10,0) NOT NULL,
  `NAME_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_` varchar(255) DEFAULT NULL,
  `EXECUTION_` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_swimlane` */

/*Table structure for table `bpm_task` */

DROP TABLE IF EXISTS `bpm_task`;

CREATE TABLE `bpm_task` (
  `DBID_` varchar(50) NOT NULL,
  `CLASS_` char(1) NOT NULL,
  `DBVERSION_` decimal(10,0) NOT NULL,
  `NAME_` varchar(255) DEFAULT NULL,
  `STATE_` varchar(255) DEFAULT NULL,
  `SUSPHISTSTATE_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_` varchar(255) DEFAULT NULL,
  `PRIORITY_` decimal(10,0) DEFAULT NULL,
  `CREATE_` datetime DEFAULT NULL,
  `DUEDATE_` datetime DEFAULT NULL,
  `PROGRESS_` decimal(10,0) DEFAULT NULL,
  `SIGNALLING_` decimal(1,0) DEFAULT NULL,
  `EXECUTION_ID_` varchar(255) DEFAULT NULL,
  `ACTIVITY_NAME_` varchar(255) DEFAULT NULL,
  `HASVARS_` decimal(1,0) DEFAULT NULL,
  `SUPERTASK_` varchar(50) DEFAULT NULL,
  `EXECUTION_` varchar(50) DEFAULT NULL,
  `PROCINST_` varchar(50) DEFAULT NULL,
  `SWIMLANE_` varchar(50) DEFAULT NULL,
  `TASKDEFNAME_` varchar(255) DEFAULT NULL,
  `TASK_ORDER_` varchar(255) DEFAULT NULL,
  `TASK_STATE_` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_task` */

/*Table structure for table `bpm_task_ext1` */

DROP TABLE IF EXISTS `bpm_task_ext1`;

CREATE TABLE `bpm_task_ext1` (
  `DBID_` varchar(50) NOT NULL,
  `CLASS_` char(1) NOT NULL,
  `DBVERSION_` decimal(10,0) NOT NULL,
  `NAME_` varchar(255) DEFAULT NULL,
  `STATE_` varchar(255) DEFAULT NULL,
  `SUSPHISTSTATE_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_` varchar(255) DEFAULT NULL,
  `PRIORITY_` decimal(10,0) DEFAULT NULL,
  `CREATE_` datetime DEFAULT NULL,
  `DUEDATE_` datetime DEFAULT NULL,
  `PROGRESS_` decimal(10,0) DEFAULT NULL,
  `SIGNALLING_` decimal(1,0) DEFAULT NULL,
  `EXECUTION_ID_` varchar(255) DEFAULT NULL,
  `ACTIVITY_NAME_` varchar(255) DEFAULT NULL,
  `HASVARS_` decimal(1,0) DEFAULT NULL,
  `SUPERTASK_` varchar(50) DEFAULT NULL,
  `EXECUTION_` varchar(50) DEFAULT NULL,
  `PROCINST_` varchar(50) DEFAULT NULL,
  `SWIMLANE_` varchar(50) DEFAULT NULL,
  `TASKDEFNAME_` varchar(255) DEFAULT NULL,
  `TASK_ORDER_` varchar(255) DEFAULT NULL,
  `TASK_STATE_` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_task_ext1` */

/*Table structure for table `bpm_task_ext2` */

DROP TABLE IF EXISTS `bpm_task_ext2`;

CREATE TABLE `bpm_task_ext2` (
  `DBID_` varchar(50) NOT NULL,
  `CLASS_` char(1) NOT NULL,
  `DBVERSION_` decimal(10,0) NOT NULL,
  `NAME_` varchar(255) DEFAULT NULL,
  `STATE_` varchar(255) DEFAULT NULL,
  `SUSPHISTSTATE_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_` varchar(255) DEFAULT NULL,
  `PRIORITY_` decimal(10,0) DEFAULT NULL,
  `CREATE_` datetime DEFAULT NULL,
  `DUEDATE_` datetime DEFAULT NULL,
  `PROGRESS_` decimal(10,0) DEFAULT NULL,
  `SIGNALLING_` decimal(1,0) DEFAULT NULL,
  `EXECUTION_ID_` varchar(255) DEFAULT NULL,
  `ACTIVITY_NAME_` varchar(255) DEFAULT NULL,
  `HASVARS_` decimal(1,0) DEFAULT NULL,
  `SUPERTASK_` varchar(50) DEFAULT NULL,
  `EXECUTION_` varchar(50) DEFAULT NULL,
  `PROCINST_` varchar(50) DEFAULT NULL,
  `SWIMLANE_` varchar(50) DEFAULT NULL,
  `TASKDEFNAME_` varchar(255) DEFAULT NULL,
  `TASK_ORDER_` varchar(255) DEFAULT NULL,
  `TASK_STATE_` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_task_ext2` */

/*Table structure for table `bpm_task_ext3` */

DROP TABLE IF EXISTS `bpm_task_ext3`;

CREATE TABLE `bpm_task_ext3` (
  `DBID_` varchar(50) NOT NULL,
  `CLASS_` char(1) NOT NULL,
  `DBVERSION_` decimal(10,0) NOT NULL,
  `NAME_` varchar(255) DEFAULT NULL,
  `STATE_` varchar(255) DEFAULT NULL,
  `SUSPHISTSTATE_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_` varchar(255) DEFAULT NULL,
  `PRIORITY_` decimal(10,0) DEFAULT NULL,
  `CREATE_` datetime DEFAULT NULL,
  `DUEDATE_` datetime DEFAULT NULL,
  `PROGRESS_` decimal(10,0) DEFAULT NULL,
  `SIGNALLING_` decimal(1,0) DEFAULT NULL,
  `EXECUTION_ID_` varchar(255) DEFAULT NULL,
  `ACTIVITY_NAME_` varchar(255) DEFAULT NULL,
  `HASVARS_` decimal(1,0) DEFAULT NULL,
  `SUPERTASK_` varchar(50) DEFAULT NULL,
  `EXECUTION_` varchar(50) DEFAULT NULL,
  `PROCINST_` varchar(50) DEFAULT NULL,
  `SWIMLANE_` varchar(50) DEFAULT NULL,
  `TASKDEFNAME_` varchar(255) DEFAULT NULL,
  `TASK_ORDER_` varchar(255) DEFAULT NULL,
  `TASK_STATE_` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_task_ext3` */

/*Table structure for table `bpm_task_ext4` */

DROP TABLE IF EXISTS `bpm_task_ext4`;

CREATE TABLE `bpm_task_ext4` (
  `DBID_` varchar(50) NOT NULL,
  `CLASS_` char(1) NOT NULL,
  `DBVERSION_` decimal(10,0) NOT NULL,
  `NAME_` varchar(255) DEFAULT NULL,
  `STATE_` varchar(255) DEFAULT NULL,
  `SUSPHISTSTATE_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_` varchar(255) DEFAULT NULL,
  `PRIORITY_` decimal(10,0) DEFAULT NULL,
  `CREATE_` datetime DEFAULT NULL,
  `DUEDATE_` datetime DEFAULT NULL,
  `PROGRESS_` decimal(10,0) DEFAULT NULL,
  `SIGNALLING_` decimal(1,0) DEFAULT NULL,
  `EXECUTION_ID_` varchar(255) DEFAULT NULL,
  `ACTIVITY_NAME_` varchar(255) DEFAULT NULL,
  `HASVARS_` decimal(1,0) DEFAULT NULL,
  `SUPERTASK_` varchar(50) DEFAULT NULL,
  `EXECUTION_` varchar(50) DEFAULT NULL,
  `PROCINST_` varchar(50) DEFAULT NULL,
  `SWIMLANE_` varchar(50) DEFAULT NULL,
  `TASKDEFNAME_` varchar(255) DEFAULT NULL,
  `TASK_ORDER_` varchar(255) DEFAULT NULL,
  `TASK_STATE_` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_task_ext4` */

/*Table structure for table `bpm_task_ext5` */

DROP TABLE IF EXISTS `bpm_task_ext5`;

CREATE TABLE `bpm_task_ext5` (
  `DBID_` varchar(50) NOT NULL,
  `CLASS_` char(1) NOT NULL,
  `DBVERSION_` decimal(10,0) NOT NULL,
  `NAME_` varchar(255) DEFAULT NULL,
  `STATE_` varchar(255) DEFAULT NULL,
  `SUSPHISTSTATE_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_` varchar(255) DEFAULT NULL,
  `PRIORITY_` decimal(10,0) DEFAULT NULL,
  `CREATE_` datetime DEFAULT NULL,
  `DUEDATE_` datetime DEFAULT NULL,
  `PROGRESS_` decimal(10,0) DEFAULT NULL,
  `SIGNALLING_` decimal(1,0) DEFAULT NULL,
  `EXECUTION_ID_` varchar(255) DEFAULT NULL,
  `ACTIVITY_NAME_` varchar(255) DEFAULT NULL,
  `HASVARS_` decimal(1,0) DEFAULT NULL,
  `SUPERTASK_` varchar(50) DEFAULT NULL,
  `EXECUTION_` varchar(50) DEFAULT NULL,
  `PROCINST_` varchar(50) DEFAULT NULL,
  `SWIMLANE_` varchar(50) DEFAULT NULL,
  `TASKDEFNAME_` varchar(255) DEFAULT NULL,
  `TASK_ORDER_` varchar(255) DEFAULT NULL,
  `TASK_STATE_` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_task_ext5` */

/*Table structure for table `bpm_task_ext6` */

DROP TABLE IF EXISTS `bpm_task_ext6`;

CREATE TABLE `bpm_task_ext6` (
  `DBID_` varchar(50) NOT NULL,
  `CLASS_` char(1) NOT NULL,
  `DBVERSION_` decimal(10,0) NOT NULL,
  `NAME_` varchar(255) DEFAULT NULL,
  `STATE_` varchar(255) DEFAULT NULL,
  `SUSPHISTSTATE_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_` varchar(255) DEFAULT NULL,
  `PRIORITY_` decimal(10,0) DEFAULT NULL,
  `CREATE_` datetime DEFAULT NULL,
  `DUEDATE_` datetime DEFAULT NULL,
  `PROGRESS_` decimal(10,0) DEFAULT NULL,
  `SIGNALLING_` decimal(1,0) DEFAULT NULL,
  `EXECUTION_ID_` varchar(255) DEFAULT NULL,
  `ACTIVITY_NAME_` varchar(255) DEFAULT NULL,
  `HASVARS_` decimal(1,0) DEFAULT NULL,
  `SUPERTASK_` varchar(50) DEFAULT NULL,
  `EXECUTION_` varchar(50) DEFAULT NULL,
  `PROCINST_` varchar(50) DEFAULT NULL,
  `SWIMLANE_` varchar(50) DEFAULT NULL,
  `TASKDEFNAME_` varchar(255) DEFAULT NULL,
  `TASK_ORDER_` varchar(255) DEFAULT NULL,
  `TASK_STATE_` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_task_ext6` */

/*Table structure for table `bpm_task_ext7` */

DROP TABLE IF EXISTS `bpm_task_ext7`;

CREATE TABLE `bpm_task_ext7` (
  `DBID_` varchar(50) NOT NULL,
  `CLASS_` char(1) NOT NULL,
  `DBVERSION_` decimal(10,0) NOT NULL,
  `NAME_` varchar(255) DEFAULT NULL,
  `STATE_` varchar(255) DEFAULT NULL,
  `SUSPHISTSTATE_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_` varchar(255) DEFAULT NULL,
  `PRIORITY_` decimal(10,0) DEFAULT NULL,
  `CREATE_` datetime DEFAULT NULL,
  `DUEDATE_` datetime DEFAULT NULL,
  `PROGRESS_` decimal(10,0) DEFAULT NULL,
  `SIGNALLING_` decimal(1,0) DEFAULT NULL,
  `EXECUTION_ID_` varchar(255) DEFAULT NULL,
  `ACTIVITY_NAME_` varchar(255) DEFAULT NULL,
  `HASVARS_` decimal(1,0) DEFAULT NULL,
  `SUPERTASK_` varchar(50) DEFAULT NULL,
  `EXECUTION_` varchar(50) DEFAULT NULL,
  `PROCINST_` varchar(50) DEFAULT NULL,
  `SWIMLANE_` varchar(50) DEFAULT NULL,
  `TASKDEFNAME_` varchar(255) DEFAULT NULL,
  `TASK_ORDER_` varchar(255) DEFAULT NULL,
  `TASK_STATE_` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_task_ext7` */

/*Table structure for table `bpm_task_ext8` */

DROP TABLE IF EXISTS `bpm_task_ext8`;

CREATE TABLE `bpm_task_ext8` (
  `DBID_` varchar(50) NOT NULL,
  `CLASS_` char(1) NOT NULL,
  `DBVERSION_` decimal(10,0) NOT NULL,
  `NAME_` varchar(255) DEFAULT NULL,
  `STATE_` varchar(255) DEFAULT NULL,
  `SUSPHISTSTATE_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_` varchar(255) DEFAULT NULL,
  `PRIORITY_` decimal(10,0) DEFAULT NULL,
  `CREATE_` datetime DEFAULT NULL,
  `DUEDATE_` datetime DEFAULT NULL,
  `PROGRESS_` decimal(10,0) DEFAULT NULL,
  `SIGNALLING_` decimal(1,0) DEFAULT NULL,
  `EXECUTION_ID_` varchar(255) DEFAULT NULL,
  `ACTIVITY_NAME_` varchar(255) DEFAULT NULL,
  `HASVARS_` decimal(1,0) DEFAULT NULL,
  `SUPERTASK_` varchar(50) DEFAULT NULL,
  `EXECUTION_` varchar(50) DEFAULT NULL,
  `PROCINST_` varchar(50) DEFAULT NULL,
  `SWIMLANE_` varchar(50) DEFAULT NULL,
  `TASKDEFNAME_` varchar(255) DEFAULT NULL,
  `TASK_ORDER_` varchar(255) DEFAULT NULL,
  `TASK_STATE_` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_task_ext8` */

/*Table structure for table `bpm_track` */

DROP TABLE IF EXISTS `bpm_track`;

CREATE TABLE `bpm_track` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id',
  `HACTI_` varchar(50) DEFAULT NULL COMMENT '流程历史节点dbid_',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT '流程任务dbid_',
  `HTASKIDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `MESSAGE_` longtext COMMENT '意见',
  `PARENT_` varchar(50) DEFAULT NULL COMMENT '暂时不启用',
  `PARENT_IDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `CURRENT_ACTI_LABEL_` varchar(255) DEFAULT NULL COMMENT '当前节点别名',
  `CURRENT_ACTI_NAME_` varchar(255) DEFAULT NULL COMMENT '当前节点id',
  `PRE_ACTI_LABEL_` varchar(255) DEFAULT NULL COMMENT '前一节点别名',
  `PRE_ACTI_NAME_` varchar(255) DEFAULT NULL COMMENT '前一节点id',
  `ASSIGNEE_ID_` varchar(255) DEFAULT NULL COMMENT '处理人id',
  `ASSIGNEE_NAME_` varchar(255) DEFAULT NULL COMMENT '处理人name',
  `ASSIGNEE_DID_` varchar(255) DEFAULT NULL COMMENT '处理人部门id',
  `ASSIGNEE_DNAME_` varchar(255) DEFAULT NULL COMMENT '处理人部门name',
  `INTO_` datetime DEFAULT NULL COMMENT '进入时间',
  `OPEN_` datetime DEFAULT NULL COMMENT '打开时间',
  `END_` datetime DEFAULT NULL COMMENT '完成时间',
  `IDEA_TYPE_` varchar(255) DEFAULT NULL COMMENT '意见类型',
  `COMPEL_MANNER_` varchar(255) DEFAULT NULL COMMENT '强制表态',
  `DISPLAY_STYLE_` varchar(255) DEFAULT NULL COMMENT '意见显示方式',
  `SEND_TYPE_` varchar(255) DEFAULT NULL COMMENT '发送类型',
  `SEND_UID_` varchar(255) DEFAULT NULL COMMENT '发送人id',
  `SEND_UNAME_` varchar(255) DEFAULT NULL COMMENT '发送人name',
  `SEND_DID_` varchar(255) DEFAULT NULL COMMENT '发送人部门id',
  `SEND_DNAME_` varchar(255) DEFAULT NULL COMMENT '发送人部门name',
  `OP_TYPE_` varchar(255) DEFAULT NULL COMMENT '办理类型',
  `OP_UID_` varchar(255) DEFAULT NULL COMMENT '办理人id',
  `OP_UNAME_` varchar(255) DEFAULT NULL COMMENT '办理人name',
  `OP_DID_` varchar(255) DEFAULT NULL COMMENT '办理人部门id',
  `OP_DNAME_` varchar(255) DEFAULT NULL COMMENT '办理人部门name',
  `COMMENT_` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_track` */

/*Table structure for table `bpm_track_ext1` */

DROP TABLE IF EXISTS `bpm_track_ext1`;

CREATE TABLE `bpm_track_ext1` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id',
  `HACTI_` varchar(50) DEFAULT NULL COMMENT '流程历史节点dbid_',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT '流程任务dbid_',
  `HTASKIDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `MESSAGE_` longtext COMMENT '意见',
  `PARENT_` varchar(50) DEFAULT NULL COMMENT '暂时不启用',
  `PARENT_IDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `CURRENT_ACTI_LABEL_` varchar(255) DEFAULT NULL COMMENT '当前节点别名',
  `CURRENT_ACTI_NAME_` varchar(255) DEFAULT NULL COMMENT '当前节点id',
  `PRE_ACTI_LABEL_` varchar(255) DEFAULT NULL COMMENT '前一节点别名',
  `PRE_ACTI_NAME_` varchar(255) DEFAULT NULL COMMENT '前一节点id',
  `ASSIGNEE_ID_` varchar(255) DEFAULT NULL COMMENT '处理人id',
  `ASSIGNEE_NAME_` varchar(255) DEFAULT NULL COMMENT '处理人name',
  `ASSIGNEE_DID_` varchar(255) DEFAULT NULL COMMENT '处理人部门id',
  `ASSIGNEE_DNAME_` varchar(255) DEFAULT NULL COMMENT '处理人部门name',
  `INTO_` datetime DEFAULT NULL COMMENT '进入时间',
  `OPEN_` datetime DEFAULT NULL COMMENT '打开时间',
  `END_` datetime DEFAULT NULL COMMENT '完成时间',
  `IDEA_TYPE_` varchar(255) DEFAULT NULL COMMENT '意见类型',
  `COMPEL_MANNER_` varchar(255) DEFAULT NULL COMMENT '强制表态',
  `DISPLAY_STYLE_` varchar(255) DEFAULT NULL COMMENT '意见显示方式',
  `SEND_TYPE_` varchar(255) DEFAULT NULL COMMENT '发送类型',
  `SEND_UID_` varchar(255) DEFAULT NULL COMMENT '发送人id',
  `SEND_UNAME_` varchar(255) DEFAULT NULL COMMENT '发送人name',
  `SEND_DID_` varchar(255) DEFAULT NULL COMMENT '发送人部门id',
  `SEND_DNAME_` varchar(255) DEFAULT NULL COMMENT '发送人部门name',
  `OP_TYPE_` varchar(255) DEFAULT NULL COMMENT '办理类型',
  `OP_UID_` varchar(255) DEFAULT NULL COMMENT '办理人id',
  `OP_UNAME_` varchar(255) DEFAULT NULL COMMENT '办理人name',
  `OP_DID_` varchar(255) DEFAULT NULL COMMENT '办理人部门id',
  `OP_DNAME_` varchar(255) DEFAULT NULL COMMENT '办理人部门name',
  `COMMENT_` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_track_ext1` */

/*Table structure for table `bpm_track_ext2` */

DROP TABLE IF EXISTS `bpm_track_ext2`;

CREATE TABLE `bpm_track_ext2` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id',
  `HACTI_` varchar(50) DEFAULT NULL COMMENT '流程历史节点dbid_',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT '流程任务dbid_',
  `HTASKIDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `MESSAGE_` longtext COMMENT '意见',
  `PARENT_` varchar(50) DEFAULT NULL COMMENT '暂时不启用',
  `PARENT_IDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `CURRENT_ACTI_LABEL_` varchar(255) DEFAULT NULL COMMENT '当前节点别名',
  `CURRENT_ACTI_NAME_` varchar(255) DEFAULT NULL COMMENT '当前节点id',
  `PRE_ACTI_LABEL_` varchar(255) DEFAULT NULL COMMENT '前一节点别名',
  `PRE_ACTI_NAME_` varchar(255) DEFAULT NULL COMMENT '前一节点id',
  `ASSIGNEE_ID_` varchar(255) DEFAULT NULL COMMENT '处理人id',
  `ASSIGNEE_NAME_` varchar(255) DEFAULT NULL COMMENT '处理人name',
  `ASSIGNEE_DID_` varchar(255) DEFAULT NULL COMMENT '处理人部门id',
  `ASSIGNEE_DNAME_` varchar(255) DEFAULT NULL COMMENT '处理人部门name',
  `INTO_` datetime DEFAULT NULL COMMENT '进入时间',
  `OPEN_` datetime DEFAULT NULL COMMENT '打开时间',
  `END_` datetime DEFAULT NULL COMMENT '完成时间',
  `IDEA_TYPE_` varchar(255) DEFAULT NULL COMMENT '意见类型',
  `COMPEL_MANNER_` varchar(255) DEFAULT NULL COMMENT '强制表态',
  `DISPLAY_STYLE_` varchar(255) DEFAULT NULL COMMENT '意见显示方式',
  `SEND_TYPE_` varchar(255) DEFAULT NULL COMMENT '发送类型',
  `SEND_UID_` varchar(255) DEFAULT NULL COMMENT '发送人id',
  `SEND_UNAME_` varchar(255) DEFAULT NULL COMMENT '发送人name',
  `SEND_DID_` varchar(255) DEFAULT NULL COMMENT '发送人部门id',
  `SEND_DNAME_` varchar(255) DEFAULT NULL COMMENT '发送人部门name',
  `OP_TYPE_` varchar(255) DEFAULT NULL COMMENT '办理类型',
  `OP_UID_` varchar(255) DEFAULT NULL COMMENT '办理人id',
  `OP_UNAME_` varchar(255) DEFAULT NULL COMMENT '办理人name',
  `OP_DID_` varchar(255) DEFAULT NULL COMMENT '办理人部门id',
  `OP_DNAME_` varchar(255) DEFAULT NULL COMMENT '办理人部门name',
  `COMMENT_` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_track_ext2` */

/*Table structure for table `bpm_track_ext3` */

DROP TABLE IF EXISTS `bpm_track_ext3`;

CREATE TABLE `bpm_track_ext3` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id',
  `HACTI_` varchar(50) DEFAULT NULL COMMENT '流程历史节点dbid_',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT '流程任务dbid_',
  `HTASKIDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `MESSAGE_` longtext COMMENT '意见',
  `PARENT_` varchar(50) DEFAULT NULL COMMENT '暂时不启用',
  `PARENT_IDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `CURRENT_ACTI_LABEL_` varchar(255) DEFAULT NULL COMMENT '当前节点别名',
  `CURRENT_ACTI_NAME_` varchar(255) DEFAULT NULL COMMENT '当前节点id',
  `PRE_ACTI_LABEL_` varchar(255) DEFAULT NULL COMMENT '前一节点别名',
  `PRE_ACTI_NAME_` varchar(255) DEFAULT NULL COMMENT '前一节点id',
  `ASSIGNEE_ID_` varchar(255) DEFAULT NULL COMMENT '处理人id',
  `ASSIGNEE_NAME_` varchar(255) DEFAULT NULL COMMENT '处理人name',
  `ASSIGNEE_DID_` varchar(255) DEFAULT NULL COMMENT '处理人部门id',
  `ASSIGNEE_DNAME_` varchar(255) DEFAULT NULL COMMENT '处理人部门name',
  `INTO_` datetime DEFAULT NULL COMMENT '进入时间',
  `OPEN_` datetime DEFAULT NULL COMMENT '打开时间',
  `END_` datetime DEFAULT NULL COMMENT '完成时间',
  `IDEA_TYPE_` varchar(255) DEFAULT NULL COMMENT '意见类型',
  `COMPEL_MANNER_` varchar(255) DEFAULT NULL COMMENT '强制表态',
  `DISPLAY_STYLE_` varchar(255) DEFAULT NULL COMMENT '意见显示方式',
  `SEND_TYPE_` varchar(255) DEFAULT NULL COMMENT '发送类型',
  `SEND_UID_` varchar(255) DEFAULT NULL COMMENT '发送人id',
  `SEND_UNAME_` varchar(255) DEFAULT NULL COMMENT '发送人name',
  `SEND_DID_` varchar(255) DEFAULT NULL COMMENT '发送人部门id',
  `SEND_DNAME_` varchar(255) DEFAULT NULL COMMENT '发送人部门name',
  `OP_TYPE_` varchar(255) DEFAULT NULL COMMENT '办理类型',
  `OP_UID_` varchar(255) DEFAULT NULL COMMENT '办理人id',
  `OP_UNAME_` varchar(255) DEFAULT NULL COMMENT '办理人name',
  `OP_DID_` varchar(255) DEFAULT NULL COMMENT '办理人部门id',
  `OP_DNAME_` varchar(255) DEFAULT NULL COMMENT '办理人部门name',
  `COMMENT_` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_track_ext3` */

/*Table structure for table `bpm_track_ext4` */

DROP TABLE IF EXISTS `bpm_track_ext4`;

CREATE TABLE `bpm_track_ext4` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id',
  `HACTI_` varchar(50) DEFAULT NULL COMMENT '流程历史节点dbid_',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT '流程任务dbid_',
  `HTASKIDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `MESSAGE_` longtext COMMENT '意见',
  `PARENT_` varchar(50) DEFAULT NULL COMMENT '暂时不启用',
  `PARENT_IDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `CURRENT_ACTI_LABEL_` varchar(255) DEFAULT NULL COMMENT '当前节点别名',
  `CURRENT_ACTI_NAME_` varchar(255) DEFAULT NULL COMMENT '当前节点id',
  `PRE_ACTI_LABEL_` varchar(255) DEFAULT NULL COMMENT '前一节点别名',
  `PRE_ACTI_NAME_` varchar(255) DEFAULT NULL COMMENT '前一节点id',
  `ASSIGNEE_ID_` varchar(255) DEFAULT NULL COMMENT '处理人id',
  `ASSIGNEE_NAME_` varchar(255) DEFAULT NULL COMMENT '处理人name',
  `ASSIGNEE_DID_` varchar(255) DEFAULT NULL COMMENT '处理人部门id',
  `ASSIGNEE_DNAME_` varchar(255) DEFAULT NULL COMMENT '处理人部门name',
  `INTO_` datetime DEFAULT NULL COMMENT '进入时间',
  `OPEN_` datetime DEFAULT NULL COMMENT '打开时间',
  `END_` datetime DEFAULT NULL COMMENT '完成时间',
  `IDEA_TYPE_` varchar(255) DEFAULT NULL COMMENT '意见类型',
  `COMPEL_MANNER_` varchar(255) DEFAULT NULL COMMENT '强制表态',
  `DISPLAY_STYLE_` varchar(255) DEFAULT NULL COMMENT '意见显示方式',
  `SEND_TYPE_` varchar(255) DEFAULT NULL COMMENT '发送类型',
  `SEND_UID_` varchar(255) DEFAULT NULL COMMENT '发送人id',
  `SEND_UNAME_` varchar(255) DEFAULT NULL COMMENT '发送人name',
  `SEND_DID_` varchar(255) DEFAULT NULL COMMENT '发送人部门id',
  `SEND_DNAME_` varchar(255) DEFAULT NULL COMMENT '发送人部门name',
  `OP_TYPE_` varchar(255) DEFAULT NULL COMMENT '办理类型',
  `OP_UID_` varchar(255) DEFAULT NULL COMMENT '办理人id',
  `OP_UNAME_` varchar(255) DEFAULT NULL COMMENT '办理人name',
  `OP_DID_` varchar(255) DEFAULT NULL COMMENT '办理人部门id',
  `OP_DNAME_` varchar(255) DEFAULT NULL COMMENT '办理人部门name',
  `COMMENT_` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_track_ext4` */

/*Table structure for table `bpm_track_ext5` */

DROP TABLE IF EXISTS `bpm_track_ext5`;

CREATE TABLE `bpm_track_ext5` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id',
  `HACTI_` varchar(50) DEFAULT NULL COMMENT '流程历史节点dbid_',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT '流程任务dbid_',
  `HTASKIDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `MESSAGE_` longtext COMMENT '意见',
  `PARENT_` varchar(50) DEFAULT NULL COMMENT '暂时不启用',
  `PARENT_IDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `CURRENT_ACTI_LABEL_` varchar(255) DEFAULT NULL COMMENT '当前节点别名',
  `CURRENT_ACTI_NAME_` varchar(255) DEFAULT NULL COMMENT '当前节点id',
  `PRE_ACTI_LABEL_` varchar(255) DEFAULT NULL COMMENT '前一节点别名',
  `PRE_ACTI_NAME_` varchar(255) DEFAULT NULL COMMENT '前一节点id',
  `ASSIGNEE_ID_` varchar(255) DEFAULT NULL COMMENT '处理人id',
  `ASSIGNEE_NAME_` varchar(255) DEFAULT NULL COMMENT '处理人name',
  `ASSIGNEE_DID_` varchar(255) DEFAULT NULL COMMENT '处理人部门id',
  `ASSIGNEE_DNAME_` varchar(255) DEFAULT NULL COMMENT '处理人部门name',
  `INTO_` datetime DEFAULT NULL COMMENT '进入时间',
  `OPEN_` datetime DEFAULT NULL COMMENT '打开时间',
  `END_` datetime DEFAULT NULL COMMENT '完成时间',
  `IDEA_TYPE_` varchar(255) DEFAULT NULL COMMENT '意见类型',
  `COMPEL_MANNER_` varchar(255) DEFAULT NULL COMMENT '强制表态',
  `DISPLAY_STYLE_` varchar(255) DEFAULT NULL COMMENT '意见显示方式',
  `SEND_TYPE_` varchar(255) DEFAULT NULL COMMENT '发送类型',
  `SEND_UID_` varchar(255) DEFAULT NULL COMMENT '发送人id',
  `SEND_UNAME_` varchar(255) DEFAULT NULL COMMENT '发送人name',
  `SEND_DID_` varchar(255) DEFAULT NULL COMMENT '发送人部门id',
  `SEND_DNAME_` varchar(255) DEFAULT NULL COMMENT '发送人部门name',
  `OP_TYPE_` varchar(255) DEFAULT NULL COMMENT '办理类型',
  `OP_UID_` varchar(255) DEFAULT NULL COMMENT '办理人id',
  `OP_UNAME_` varchar(255) DEFAULT NULL COMMENT '办理人name',
  `OP_DID_` varchar(255) DEFAULT NULL COMMENT '办理人部门id',
  `OP_DNAME_` varchar(255) DEFAULT NULL COMMENT '办理人部门name',
  `COMMENT_` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_track_ext5` */

/*Table structure for table `bpm_track_ext6` */

DROP TABLE IF EXISTS `bpm_track_ext6`;

CREATE TABLE `bpm_track_ext6` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id',
  `HACTI_` varchar(50) DEFAULT NULL COMMENT '流程历史节点dbid_',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT '流程任务dbid_',
  `HTASKIDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `MESSAGE_` longtext COMMENT '意见',
  `PARENT_` varchar(50) DEFAULT NULL COMMENT '暂时不启用',
  `PARENT_IDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `CURRENT_ACTI_LABEL_` varchar(255) DEFAULT NULL COMMENT '当前节点别名',
  `CURRENT_ACTI_NAME_` varchar(255) DEFAULT NULL COMMENT '当前节点id',
  `PRE_ACTI_LABEL_` varchar(255) DEFAULT NULL COMMENT '前一节点别名',
  `PRE_ACTI_NAME_` varchar(255) DEFAULT NULL COMMENT '前一节点id',
  `ASSIGNEE_ID_` varchar(255) DEFAULT NULL COMMENT '处理人id',
  `ASSIGNEE_NAME_` varchar(255) DEFAULT NULL COMMENT '处理人name',
  `ASSIGNEE_DID_` varchar(255) DEFAULT NULL COMMENT '处理人部门id',
  `ASSIGNEE_DNAME_` varchar(255) DEFAULT NULL COMMENT '处理人部门name',
  `INTO_` datetime DEFAULT NULL COMMENT '进入时间',
  `OPEN_` datetime DEFAULT NULL COMMENT '打开时间',
  `END_` datetime DEFAULT NULL COMMENT '完成时间',
  `IDEA_TYPE_` varchar(255) DEFAULT NULL COMMENT '意见类型',
  `COMPEL_MANNER_` varchar(255) DEFAULT NULL COMMENT '强制表态',
  `DISPLAY_STYLE_` varchar(255) DEFAULT NULL COMMENT '意见显示方式',
  `SEND_TYPE_` varchar(255) DEFAULT NULL COMMENT '发送类型',
  `SEND_UID_` varchar(255) DEFAULT NULL COMMENT '发送人id',
  `SEND_UNAME_` varchar(255) DEFAULT NULL COMMENT '发送人name',
  `SEND_DID_` varchar(255) DEFAULT NULL COMMENT '发送人部门id',
  `SEND_DNAME_` varchar(255) DEFAULT NULL COMMENT '发送人部门name',
  `OP_TYPE_` varchar(255) DEFAULT NULL COMMENT '办理类型',
  `OP_UID_` varchar(255) DEFAULT NULL COMMENT '办理人id',
  `OP_UNAME_` varchar(255) DEFAULT NULL COMMENT '办理人name',
  `OP_DID_` varchar(255) DEFAULT NULL COMMENT '办理人部门id',
  `OP_DNAME_` varchar(255) DEFAULT NULL COMMENT '办理人部门name',
  `COMMENT_` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_track_ext6` */

/*Table structure for table `bpm_track_ext7` */

DROP TABLE IF EXISTS `bpm_track_ext7`;

CREATE TABLE `bpm_track_ext7` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id',
  `HACTI_` varchar(50) DEFAULT NULL COMMENT '流程历史节点dbid_',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT '流程任务dbid_',
  `HTASKIDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `MESSAGE_` longtext COMMENT '意见',
  `PARENT_` varchar(50) DEFAULT NULL COMMENT '暂时不启用',
  `PARENT_IDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `CURRENT_ACTI_LABEL_` varchar(255) DEFAULT NULL COMMENT '当前节点别名',
  `CURRENT_ACTI_NAME_` varchar(255) DEFAULT NULL COMMENT '当前节点id',
  `PRE_ACTI_LABEL_` varchar(255) DEFAULT NULL COMMENT '前一节点别名',
  `PRE_ACTI_NAME_` varchar(255) DEFAULT NULL COMMENT '前一节点id',
  `ASSIGNEE_ID_` varchar(255) DEFAULT NULL COMMENT '处理人id',
  `ASSIGNEE_NAME_` varchar(255) DEFAULT NULL COMMENT '处理人name',
  `ASSIGNEE_DID_` varchar(255) DEFAULT NULL COMMENT '处理人部门id',
  `ASSIGNEE_DNAME_` varchar(255) DEFAULT NULL COMMENT '处理人部门name',
  `INTO_` datetime DEFAULT NULL COMMENT '进入时间',
  `OPEN_` datetime DEFAULT NULL COMMENT '打开时间',
  `END_` datetime DEFAULT NULL COMMENT '完成时间',
  `IDEA_TYPE_` varchar(255) DEFAULT NULL COMMENT '意见类型',
  `COMPEL_MANNER_` varchar(255) DEFAULT NULL COMMENT '强制表态',
  `DISPLAY_STYLE_` varchar(255) DEFAULT NULL COMMENT '意见显示方式',
  `SEND_TYPE_` varchar(255) DEFAULT NULL COMMENT '发送类型',
  `SEND_UID_` varchar(255) DEFAULT NULL COMMENT '发送人id',
  `SEND_UNAME_` varchar(255) DEFAULT NULL COMMENT '发送人name',
  `SEND_DID_` varchar(255) DEFAULT NULL COMMENT '发送人部门id',
  `SEND_DNAME_` varchar(255) DEFAULT NULL COMMENT '发送人部门name',
  `OP_TYPE_` varchar(255) DEFAULT NULL COMMENT '办理类型',
  `OP_UID_` varchar(255) DEFAULT NULL COMMENT '办理人id',
  `OP_UNAME_` varchar(255) DEFAULT NULL COMMENT '办理人name',
  `OP_DID_` varchar(255) DEFAULT NULL COMMENT '办理人部门id',
  `OP_DNAME_` varchar(255) DEFAULT NULL COMMENT '办理人部门name',
  `COMMENT_` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_track_ext7` */

/*Table structure for table `bpm_track_ext8` */

DROP TABLE IF EXISTS `bpm_track_ext8`;

CREATE TABLE `bpm_track_ext8` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id',
  `HACTI_` varchar(50) DEFAULT NULL COMMENT '流程历史节点dbid_',
  `HTASK_` varchar(50) DEFAULT NULL COMMENT '流程任务dbid_',
  `HTASKIDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `MESSAGE_` longtext COMMENT '意见',
  `PARENT_` varchar(50) DEFAULT NULL COMMENT '暂时不启用',
  `PARENT_IDX_` decimal(10,0) DEFAULT NULL COMMENT '暂时不启用',
  `CURRENT_ACTI_LABEL_` varchar(255) DEFAULT NULL COMMENT '当前节点别名',
  `CURRENT_ACTI_NAME_` varchar(255) DEFAULT NULL COMMENT '当前节点id',
  `PRE_ACTI_LABEL_` varchar(255) DEFAULT NULL COMMENT '前一节点别名',
  `PRE_ACTI_NAME_` varchar(255) DEFAULT NULL COMMENT '前一节点id',
  `ASSIGNEE_ID_` varchar(255) DEFAULT NULL COMMENT '处理人id',
  `ASSIGNEE_NAME_` varchar(255) DEFAULT NULL COMMENT '处理人name',
  `ASSIGNEE_DID_` varchar(255) DEFAULT NULL COMMENT '处理人部门id',
  `ASSIGNEE_DNAME_` varchar(255) DEFAULT NULL COMMENT '处理人部门name',
  `INTO_` datetime DEFAULT NULL COMMENT '进入时间',
  `OPEN_` datetime DEFAULT NULL COMMENT '打开时间',
  `END_` datetime DEFAULT NULL COMMENT '完成时间',
  `IDEA_TYPE_` varchar(255) DEFAULT NULL COMMENT '意见类型',
  `COMPEL_MANNER_` varchar(255) DEFAULT NULL COMMENT '强制表态',
  `DISPLAY_STYLE_` varchar(255) DEFAULT NULL COMMENT '意见显示方式',
  `SEND_TYPE_` varchar(255) DEFAULT NULL COMMENT '发送类型',
  `SEND_UID_` varchar(255) DEFAULT NULL COMMENT '发送人id',
  `SEND_UNAME_` varchar(255) DEFAULT NULL COMMENT '发送人name',
  `SEND_DID_` varchar(255) DEFAULT NULL COMMENT '发送人部门id',
  `SEND_DNAME_` varchar(255) DEFAULT NULL COMMENT '发送人部门name',
  `OP_TYPE_` varchar(255) DEFAULT NULL COMMENT '办理类型',
  `OP_UID_` varchar(255) DEFAULT NULL COMMENT '办理人id',
  `OP_UNAME_` varchar(255) DEFAULT NULL COMMENT '办理人name',
  `OP_DID_` varchar(255) DEFAULT NULL COMMENT '办理人部门id',
  `OP_DNAME_` varchar(255) DEFAULT NULL COMMENT '办理人部门name',
  `COMMENT_` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_track_ext8` */

/*Table structure for table `bpm_variable` */

DROP TABLE IF EXISTS `bpm_variable`;

CREATE TABLE `bpm_variable` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `KEY_` varchar(255) DEFAULT NULL COMMENT '流程变量的key',
  `CONVERTER_` varchar(255) DEFAULT NULL COMMENT '标识lob类型',
  `HIST_` decimal(1,0) DEFAULT NULL COMMENT '是否保存的历史变量',
  `EXECUTION_` varchar(50) DEFAULT NULL COMMENT '流程实例',
  `TASK_` varchar(50) DEFAULT NULL COMMENT '流程任务',
  `LOB_` varchar(50) DEFAULT NULL COMMENT 'LOG表关联',
  `DATE_VALUE_` datetime DEFAULT NULL COMMENT '时间类型对应的数值',
  `DOUBLE_VALUE_` double DEFAULT NULL COMMENT 'double类型对应的数值',
  `CLASSNAME_` varchar(255) DEFAULT NULL COMMENT 'class类型对应的数值',
  `LONG_VALUE_` decimal(19,0) DEFAULT NULL COMMENT 'long类型对应的数值',
  `STRING_VALUE_` text COMMENT 'string类型对应的数值',
  `TEXT_VALUE_` longtext COMMENT 'text类型对应的数值',
  `EXESYS_` varchar(50) DEFAULT NULL COMMENT '系统变量',
  `HACTI_` varchar(50) DEFAULT NULL COMMENT '流程历史节点',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_variable` */

/*Table structure for table `bpm_variable_ext1` */

DROP TABLE IF EXISTS `bpm_variable_ext1`;

CREATE TABLE `bpm_variable_ext1` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `KEY_` varchar(255) DEFAULT NULL COMMENT '流程变量的key',
  `CONVERTER_` varchar(255) DEFAULT NULL COMMENT '标识lob类型',
  `HIST_` decimal(1,0) DEFAULT NULL COMMENT '是否保存的历史变量',
  `EXECUTION_` varchar(50) DEFAULT NULL COMMENT '流程实例',
  `TASK_` varchar(50) DEFAULT NULL COMMENT '流程任务',
  `LOB_` varchar(50) DEFAULT NULL COMMENT 'LOG表关联',
  `DATE_VALUE_` datetime DEFAULT NULL COMMENT '时间类型对应的数值',
  `DOUBLE_VALUE_` double DEFAULT NULL COMMENT 'double类型对应的数值',
  `CLASSNAME_` varchar(255) DEFAULT NULL COMMENT 'class类型对应的数值',
  `LONG_VALUE_` decimal(19,0) DEFAULT NULL COMMENT 'long类型对应的数值',
  `STRING_VALUE_` text COMMENT 'string类型对应的数值',
  `TEXT_VALUE_` longtext COMMENT 'text类型对应的数值',
  `EXESYS_` varchar(50) DEFAULT NULL COMMENT '系统变量',
  `HACTI_` varchar(50) DEFAULT NULL COMMENT '流程历史节点',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_variable_ext1` */

/*Table structure for table `bpm_variable_ext2` */

DROP TABLE IF EXISTS `bpm_variable_ext2`;

CREATE TABLE `bpm_variable_ext2` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `KEY_` varchar(255) DEFAULT NULL COMMENT '流程变量的key',
  `CONVERTER_` varchar(255) DEFAULT NULL COMMENT '标识lob类型',
  `HIST_` decimal(1,0) DEFAULT NULL COMMENT '是否保存的历史变量',
  `EXECUTION_` varchar(50) DEFAULT NULL COMMENT '流程实例',
  `TASK_` varchar(50) DEFAULT NULL COMMENT '流程任务',
  `LOB_` varchar(50) DEFAULT NULL COMMENT 'LOG表关联',
  `DATE_VALUE_` datetime DEFAULT NULL COMMENT '时间类型对应的数值',
  `DOUBLE_VALUE_` double DEFAULT NULL COMMENT 'double类型对应的数值',
  `CLASSNAME_` varchar(255) DEFAULT NULL COMMENT 'class类型对应的数值',
  `LONG_VALUE_` decimal(19,0) DEFAULT NULL COMMENT 'long类型对应的数值',
  `STRING_VALUE_` text COMMENT 'string类型对应的数值',
  `TEXT_VALUE_` longtext COMMENT 'text类型对应的数值',
  `EXESYS_` varchar(50) DEFAULT NULL COMMENT '系统变量',
  `HACTI_` varchar(50) DEFAULT NULL COMMENT '流程历史节点',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_variable_ext2` */

/*Table structure for table `bpm_variable_ext3` */

DROP TABLE IF EXISTS `bpm_variable_ext3`;

CREATE TABLE `bpm_variable_ext3` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `KEY_` varchar(255) DEFAULT NULL COMMENT '流程变量的key',
  `CONVERTER_` varchar(255) DEFAULT NULL COMMENT '标识lob类型',
  `HIST_` decimal(1,0) DEFAULT NULL COMMENT '是否保存的历史变量',
  `EXECUTION_` varchar(50) DEFAULT NULL COMMENT '流程实例',
  `TASK_` varchar(50) DEFAULT NULL COMMENT '流程任务',
  `LOB_` varchar(50) DEFAULT NULL COMMENT 'LOG表关联',
  `DATE_VALUE_` datetime DEFAULT NULL COMMENT '时间类型对应的数值',
  `DOUBLE_VALUE_` double DEFAULT NULL COMMENT 'double类型对应的数值',
  `CLASSNAME_` varchar(255) DEFAULT NULL COMMENT 'class类型对应的数值',
  `LONG_VALUE_` decimal(19,0) DEFAULT NULL COMMENT 'long类型对应的数值',
  `STRING_VALUE_` text COMMENT 'string类型对应的数值',
  `TEXT_VALUE_` longtext COMMENT 'text类型对应的数值',
  `EXESYS_` varchar(50) DEFAULT NULL COMMENT '系统变量',
  `HACTI_` varchar(50) DEFAULT NULL COMMENT '流程历史节点',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_variable_ext3` */

/*Table structure for table `bpm_variable_ext4` */

DROP TABLE IF EXISTS `bpm_variable_ext4`;

CREATE TABLE `bpm_variable_ext4` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `KEY_` varchar(255) DEFAULT NULL COMMENT '流程变量的key',
  `CONVERTER_` varchar(255) DEFAULT NULL COMMENT '标识lob类型',
  `HIST_` decimal(1,0) DEFAULT NULL COMMENT '是否保存的历史变量',
  `EXECUTION_` varchar(50) DEFAULT NULL COMMENT '流程实例',
  `TASK_` varchar(50) DEFAULT NULL COMMENT '流程任务',
  `LOB_` varchar(50) DEFAULT NULL COMMENT 'LOG表关联',
  `DATE_VALUE_` datetime DEFAULT NULL COMMENT '时间类型对应的数值',
  `DOUBLE_VALUE_` double DEFAULT NULL COMMENT 'double类型对应的数值',
  `CLASSNAME_` varchar(255) DEFAULT NULL COMMENT 'class类型对应的数值',
  `LONG_VALUE_` decimal(19,0) DEFAULT NULL COMMENT 'long类型对应的数值',
  `STRING_VALUE_` text COMMENT 'string类型对应的数值',
  `TEXT_VALUE_` longtext COMMENT 'text类型对应的数值',
  `EXESYS_` varchar(50) DEFAULT NULL COMMENT '系统变量',
  `HACTI_` varchar(50) DEFAULT NULL COMMENT '流程历史节点',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_variable_ext4` */

/*Table structure for table `bpm_variable_ext5` */

DROP TABLE IF EXISTS `bpm_variable_ext5`;

CREATE TABLE `bpm_variable_ext5` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `KEY_` varchar(255) DEFAULT NULL COMMENT '流程变量的key',
  `CONVERTER_` varchar(255) DEFAULT NULL COMMENT '标识lob类型',
  `HIST_` decimal(1,0) DEFAULT NULL COMMENT '是否保存的历史变量',
  `EXECUTION_` varchar(50) DEFAULT NULL COMMENT '流程实例',
  `TASK_` varchar(50) DEFAULT NULL COMMENT '流程任务',
  `LOB_` varchar(50) DEFAULT NULL COMMENT 'LOG表关联',
  `DATE_VALUE_` datetime DEFAULT NULL COMMENT '时间类型对应的数值',
  `DOUBLE_VALUE_` double DEFAULT NULL COMMENT 'double类型对应的数值',
  `CLASSNAME_` varchar(255) DEFAULT NULL COMMENT 'class类型对应的数值',
  `LONG_VALUE_` decimal(19,0) DEFAULT NULL COMMENT 'long类型对应的数值',
  `STRING_VALUE_` text COMMENT 'string类型对应的数值',
  `TEXT_VALUE_` longtext COMMENT 'text类型对应的数值',
  `EXESYS_` varchar(50) DEFAULT NULL COMMENT '系统变量',
  `HACTI_` varchar(50) DEFAULT NULL COMMENT '流程历史节点',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_variable_ext5` */

/*Table structure for table `bpm_variable_ext6` */

DROP TABLE IF EXISTS `bpm_variable_ext6`;

CREATE TABLE `bpm_variable_ext6` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `KEY_` varchar(255) DEFAULT NULL COMMENT '流程变量的key',
  `CONVERTER_` varchar(255) DEFAULT NULL COMMENT '标识lob类型',
  `HIST_` decimal(1,0) DEFAULT NULL COMMENT '是否保存的历史变量',
  `EXECUTION_` varchar(50) DEFAULT NULL COMMENT '流程实例',
  `TASK_` varchar(50) DEFAULT NULL COMMENT '流程任务',
  `LOB_` varchar(50) DEFAULT NULL COMMENT 'LOG表关联',
  `DATE_VALUE_` datetime DEFAULT NULL COMMENT '时间类型对应的数值',
  `DOUBLE_VALUE_` double DEFAULT NULL COMMENT 'double类型对应的数值',
  `CLASSNAME_` varchar(255) DEFAULT NULL COMMENT 'class类型对应的数值',
  `LONG_VALUE_` decimal(19,0) DEFAULT NULL COMMENT 'long类型对应的数值',
  `STRING_VALUE_` text COMMENT 'string类型对应的数值',
  `TEXT_VALUE_` longtext COMMENT 'text类型对应的数值',
  `EXESYS_` varchar(50) DEFAULT NULL COMMENT '系统变量',
  `HACTI_` varchar(50) DEFAULT NULL COMMENT '流程历史节点',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_variable_ext6` */

/*Table structure for table `bpm_variable_ext7` */

DROP TABLE IF EXISTS `bpm_variable_ext7`;

CREATE TABLE `bpm_variable_ext7` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `KEY_` varchar(255) DEFAULT NULL COMMENT '流程变量的key',
  `CONVERTER_` varchar(255) DEFAULT NULL COMMENT '标识lob类型',
  `HIST_` decimal(1,0) DEFAULT NULL COMMENT '是否保存的历史变量',
  `EXECUTION_` varchar(50) DEFAULT NULL COMMENT '流程实例',
  `TASK_` varchar(50) DEFAULT NULL COMMENT '流程任务',
  `LOB_` varchar(50) DEFAULT NULL COMMENT 'LOG表关联',
  `DATE_VALUE_` datetime DEFAULT NULL COMMENT '时间类型对应的数值',
  `DOUBLE_VALUE_` double DEFAULT NULL COMMENT 'double类型对应的数值',
  `CLASSNAME_` varchar(255) DEFAULT NULL COMMENT 'class类型对应的数值',
  `LONG_VALUE_` decimal(19,0) DEFAULT NULL COMMENT 'long类型对应的数值',
  `STRING_VALUE_` text COMMENT 'string类型对应的数值',
  `TEXT_VALUE_` longtext COMMENT 'text类型对应的数值',
  `EXESYS_` varchar(50) DEFAULT NULL COMMENT '系统变量',
  `HACTI_` varchar(50) DEFAULT NULL COMMENT '流程历史节点',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_variable_ext7` */

/*Table structure for table `bpm_variable_ext8` */

DROP TABLE IF EXISTS `bpm_variable_ext8`;

CREATE TABLE `bpm_variable_ext8` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `CLASS_` varchar(255) NOT NULL COMMENT '数据记录类型',
  `DBVERSION_` decimal(10,0) NOT NULL COMMENT '数据记录版本',
  `KEY_` varchar(255) DEFAULT NULL COMMENT '流程变量的key',
  `CONVERTER_` varchar(255) DEFAULT NULL COMMENT '标识lob类型',
  `HIST_` decimal(1,0) DEFAULT NULL COMMENT '是否保存的历史变量',
  `EXECUTION_` varchar(50) DEFAULT NULL COMMENT '流程实例',
  `TASK_` varchar(50) DEFAULT NULL COMMENT '流程任务',
  `LOB_` varchar(50) DEFAULT NULL COMMENT 'LOG表关联',
  `DATE_VALUE_` datetime DEFAULT NULL COMMENT '时间类型对应的数值',
  `DOUBLE_VALUE_` double DEFAULT NULL COMMENT 'double类型对应的数值',
  `CLASSNAME_` varchar(255) DEFAULT NULL COMMENT 'class类型对应的数值',
  `LONG_VALUE_` decimal(19,0) DEFAULT NULL COMMENT 'long类型对应的数值',
  `STRING_VALUE_` text COMMENT 'string类型对应的数值',
  `TEXT_VALUE_` longtext COMMENT 'text类型对应的数值',
  `EXESYS_` varchar(50) DEFAULT NULL COMMENT '系统变量',
  `HACTI_` varchar(50) DEFAULT NULL COMMENT '流程历史节点',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_variable_ext8` */

/*Table structure for table `bpm_waring` */

DROP TABLE IF EXISTS `bpm_waring`;

CREATE TABLE `bpm_waring` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键ID',
  `WARING_TYPE_` varchar(100) NOT NULL COMMENT '预警类型',
  `VALUE_` varchar(100) NOT NULL COMMENT '预警阀值',
  `SEND_TYPE01_` varchar(50) DEFAULT NULL COMMENT '是否发送给自己',
  `SEND_TYPE02_` varchar(50) DEFAULT NULL COMMENT '是否发送给他人',
  `OTHER_MAILS_` text COMMENT '其他邮件地址',
  `JOB_RULE_` varchar(100) DEFAULT NULL COMMENT '定时任务规则',
  `JOB_CLASS_` text COMMENT '定时任务处理类',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='流程预警';

/*Data for the table `bpm_waring` */

/*Table structure for table `bpm_work_hand_task` */

DROP TABLE IF EXISTS `bpm_work_hand_task`;

CREATE TABLE `bpm_work_hand_task` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `HPROCI_` varchar(50) DEFAULT NULL COMMENT '流程实例id',
  `EXECUTION_` varchar(255) DEFAULT NULL COMMENT 'bpm_execution表id',
  `HIST_TASK_DBID_` varchar(50) DEFAULT NULL COMMENT '历史任务dbid',
  `TRACK_DBID_` varchar(50) DEFAULT NULL COMMENT '流程跟踪dbid',
  `WORK_OWNER_ID_` varchar(50) DEFAULT NULL COMMENT '工作移交人',
  `RECEPT_USER_ID_` varchar(50) DEFAULT NULL COMMENT '工作移交接收人',
  `HAND_TASK_DATE_` datetime DEFAULT NULL COMMENT '移交时间',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_work_hand_task` */

/*Table structure for table `bpm_work_hand_task_pass` */

DROP TABLE IF EXISTS `bpm_work_hand_task_pass`;

CREATE TABLE `bpm_work_hand_task_pass` (
  `DBID_` varchar(50) NOT NULL COMMENT '主键',
  `WORK_HAND_TASK_` varchar(50) DEFAULT NULL COMMENT '移交主表dbid',
  `HIST_TASK_DBID_` varchar(50) DEFAULT NULL COMMENT '历史任务dbid',
  `WORK_OWNER_ID_` varchar(50) DEFAULT NULL COMMENT '工作移交人',
  `RECEPT_USER_ID_` varchar(50) DEFAULT NULL COMMENT '工作接收人',
  `ORDER_BY_` decimal(19,0) DEFAULT NULL COMMENT '排序字段',
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bpm_work_hand_task_pass` */

/*Table structure for table `eform_custom_button` */

DROP TABLE IF EXISTS `eform_custom_button`;

CREATE TABLE `eform_custom_button` (
  `ID` varchar(50) NOT NULL,
  `BUTTON_NAME` varchar(50) DEFAULT NULL,
  `BUTTON_URL` text,
  `TABLE_ID` varchar(50) DEFAULT NULL,
  `IS_PAGE` varchar(50) DEFAULT NULL,
  `BUTTON_ICON` varchar(50) DEFAULT NULL,
  `LAST_UPDATE_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` varchar(50) DEFAULT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `CREATED_BY` varchar(50) DEFAULT NULL,
  `LAST_UPDATE_IP` varchar(50) DEFAULT NULL,
  `VERSION` decimal(16,0) DEFAULT NULL,
  `BUTTON_ORDER` decimal(16,0) DEFAULT NULL,
  `PRE_JS` text,
  `EVENT_CLASS` varchar(200) DEFAULT NULL,
  `POST_JS` text,
  `IS_DEFAULT` varchar(10) DEFAULT NULL,
  `BUTTON_CODE` varchar(50) DEFAULT NULL,
  `REMARK` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `eform_custom_button` */

/*Table structure for table `eform_tab_col_code` */

DROP TABLE IF EXISTS `eform_tab_col_code`;

CREATE TABLE `eform_tab_col_code` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `TABLE_ID` varchar(50) NOT NULL COMMENT '表ID',
  `COLUMN_ID` varchar(50) NOT NULL COMMENT '列ID',
  `CODE_ORDER` decimal(65,30) NOT NULL COMMENT '顺序',
  `LOOKUP_NAME` varchar(128) NOT NULL COMMENT '显示值',
  `LOOKUP_CODE` varchar(128) NOT NULL COMMENT '真实值；手动输入，默认与显示值一样',
  `CODE_IS_VALID` varchar(2) NOT NULL COMMENT '是否有效；Y-有效，N-无效',
  `REMARK` varchar(255) DEFAULT NULL COMMENT '说明',
  `ORG_ID` varchar(50) NOT NULL COMMENT '组织ID',
  `DEPT_ID` varchar(50) NOT NULL COMMENT '部门ID',
  `SYS_ID` varchar(50) DEFAULT NULL COMMENT '系统标识ID',
  `SECRET_LEVEL` varchar(50) DEFAULT NULL COMMENT '密级',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '多应用ID',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '预留字段1',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '预留字段2',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '预留字段3',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '预留字段4',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '预留字段5',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '预留字段6',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '预留字段7',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '预留字段8',
  `ATTRIBUTE_09` datetime DEFAULT NULL COMMENT '预留字段9',
  `ATTRIBUTE_10` datetime DEFAULT NULL COMMENT '预留字段10',
  `ATTRIBUTE_11` decimal(65,30) DEFAULT NULL COMMENT '预留字段11',
  `ATTRIBUTE_12` decimal(65,30) DEFAULT NULL COMMENT '预留字段12',
  `ATTRIBUTE_13` decimal(65,30) DEFAULT NULL COMMENT '预留字段13',
  `ATTRIBUTE_14` decimal(65,30) DEFAULT NULL COMMENT '预留字段14',
  `ATTRIBUTE_15` decimal(65,30) DEFAULT NULL COMMENT '预留字段15',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='代码维护';

/*Data for the table `eform_tab_col_code` */

/*Table structure for table `eform_tab_col_config_group` */

DROP TABLE IF EXISTS `eform_tab_col_config_group`;

CREATE TABLE `eform_tab_col_config_group` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `SOURCE_COLUMN_ID` varchar(50) NOT NULL COMMENT '源字段ID',
  `TARGET_COLUMN_ID` varchar(50) NOT NULL COMMENT '组合字段ID',
  `TARGET_INPUT` text COMMENT '组合输入值',
  `ORG_ID` varchar(50) NOT NULL COMMENT '组织ID',
  `DEPT_ID` varchar(50) NOT NULL COMMENT '部门ID',
  `SYS_ID` varchar(50) DEFAULT NULL COMMENT '系统标识ID',
  `SECRET_LEVEL` varchar(50) DEFAULT NULL COMMENT '密级',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '多应用ID',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '预留字段1',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '预留字段2',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '预留字段3',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '预留字段4',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '预留字段5',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '预留字段6',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '预留字段7',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '预留字段8',
  `ATTRIBUTE_09` datetime DEFAULT NULL COMMENT '预留字段9',
  `ATTRIBUTE_10` datetime DEFAULT NULL COMMENT '预留字段10',
  `ATTRIBUTE_11` decimal(65,30) DEFAULT NULL COMMENT '预留字段11',
  `ATTRIBUTE_12` decimal(65,30) DEFAULT NULL COMMENT '预留字段12',
  `ATTRIBUTE_13` decimal(65,30) DEFAULT NULL COMMENT '预留字段13',
  `ATTRIBUTE_14` decimal(65,30) DEFAULT NULL COMMENT '预留字段14',
  `ATTRIBUTE_15` decimal(65,30) DEFAULT NULL COMMENT '预留字段15',
  `GROUP_ORDER` varchar(2) NOT NULL COMMENT '组合字段顺序',
  `TARGET_TABLE_ID` varchar(50) DEFAULT NULL COMMENT '目标表ID',
  `SOURCE_TABLE_ID` varchar(50) DEFAULT NULL COMMENT '源字段ID',
  `TARGET_COLUMN_OPERATION` varchar(2) DEFAULT NULL COMMENT '运算方式\r\n1：第一个；2：最后一个；3：最大的；4：最小的；5：求和',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='组合项配置信息';

/*Data for the table `eform_tab_col_config_group` */

/*Table structure for table `eform_tab_col_index` */

DROP TABLE IF EXISTS `eform_tab_col_index`;

CREATE TABLE `eform_tab_col_index` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `TABLE_ID` varchar(50) NOT NULL COMMENT '表ID',
  `COLUMN_ID` text NOT NULL COMMENT '列ID',
  `INDEX_NAME` varchar(128) NOT NULL COMMENT '名称',
  `INDEX_TYPE` varchar(2) DEFAULT NULL COMMENT '索引类型（1 普通索引 2 唯一索引）',
  `REMARK` varchar(255) DEFAULT NULL COMMENT '说明',
  `ORG_ID` varchar(50) DEFAULT NULL COMMENT '组织ID',
  `DEPT_ID` varchar(50) DEFAULT NULL COMMENT '部门ID',
  `SYS_ID` varchar(50) DEFAULT NULL COMMENT '系统标识ID',
  `SECRET_LEVEL` varchar(50) DEFAULT NULL COMMENT '密级',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '多应用ID',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '最后更新IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '预留字段1',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '预留字段2',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '预留字段3',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '预留字段4',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '预留字段5',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '预留字段6',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '预留字段7',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '预留字段8',
  `ATTRIBUTE_09` datetime DEFAULT NULL COMMENT '预留字段9',
  `ATTRIBUTE_10` datetime DEFAULT NULL COMMENT '预留字段10',
  `ATTRIBUTE_11` decimal(65,30) DEFAULT NULL COMMENT '预留字段11',
  `ATTRIBUTE_12` decimal(65,30) DEFAULT NULL COMMENT '预留字段12',
  `ATTRIBUTE_13` decimal(65,30) DEFAULT NULL COMMENT '预留字段13',
  `ATTRIBUTE_14` decimal(65,30) DEFAULT NULL COMMENT '预留字段14',
  `ATTRIBUTE_15` decimal(65,30) DEFAULT NULL COMMENT '预留字段15',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='唯一索引';

/*Data for the table `eform_tab_col_index` */

/*Table structure for table `eform_tab_col_search` */

DROP TABLE IF EXISTS `eform_tab_col_search`;

CREATE TABLE `eform_tab_col_search` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `TABLE_ID` varchar(50) NOT NULL COMMENT '表ID',
  `COLUMN_ID` varchar(50) NOT NULL COMMENT '列ID',
  `SEARCH_ORDER` decimal(65,30) NOT NULL COMMENT '顺序',
  `REMARK` varchar(255) DEFAULT NULL COMMENT '说明',
  `ORG_ID` varchar(50) NOT NULL COMMENT '组织ID',
  `DEPT_ID` varchar(50) NOT NULL COMMENT '部门ID',
  `SYS_ID` varchar(50) DEFAULT NULL COMMENT '系统标识ID',
  `SECRET_LEVEL` varchar(50) DEFAULT NULL COMMENT '密级',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '多应用ID',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '预留字段1',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '预留字段2',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '预留字段3',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '预留字段4',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '预留字段5',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '预留字段6',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '预留字段7',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '预留字段8',
  `ATTRIBUTE_09` datetime DEFAULT NULL COMMENT '预留字段9',
  `ATTRIBUTE_10` datetime DEFAULT NULL COMMENT '预留字段10',
  `ATTRIBUTE_11` decimal(65,30) DEFAULT NULL COMMENT '预留字段11',
  `ATTRIBUTE_12` decimal(65,30) DEFAULT NULL COMMENT '预留字段12',
  `ATTRIBUTE_13` decimal(65,30) DEFAULT NULL COMMENT '预留字段13',
  `ATTRIBUTE_14` decimal(65,30) DEFAULT NULL COMMENT '预留字段14',
  `ATTRIBUTE_15` decimal(65,30) DEFAULT NULL COMMENT '预留字段15',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='分类检索';

/*Data for the table `eform_tab_col_search` */

/*Table structure for table `eform_tab_col_sort` */

DROP TABLE IF EXISTS `eform_tab_col_sort`;

CREATE TABLE `eform_tab_col_sort` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `TABLE_ID` varchar(50) NOT NULL COMMENT '表ID',
  `COLUMN_ID` varchar(50) NOT NULL COMMENT '列ID',
  `SORT_ORDER` decimal(65,30) NOT NULL COMMENT '顺序',
  `SORT_CODE` varchar(2) NOT NULL COMMENT '排序标识；A-升序，D-降序；默认为升序A',
  `REMARK` varchar(255) DEFAULT NULL COMMENT '说明',
  `ORG_ID` varchar(50) NOT NULL COMMENT '组织ID',
  `DEPT_ID` varchar(50) NOT NULL COMMENT '部门ID',
  `SYS_ID` varchar(50) DEFAULT NULL COMMENT '系统标识ID',
  `SECRET_LEVEL` varchar(50) DEFAULT NULL COMMENT '密级',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '多应用ID',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '预留字段1',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '预留字段2',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '预留字段3',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '预留字段4',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '预留字段5',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '预留字段6',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '预留字段7',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '预留字段8',
  `ATTRIBUTE_09` datetime DEFAULT NULL COMMENT '预留字段9',
  `ATTRIBUTE_10` datetime DEFAULT NULL COMMENT '预留字段10',
  `ATTRIBUTE_11` decimal(65,30) DEFAULT NULL COMMENT '预留字段11',
  `ATTRIBUTE_12` decimal(65,30) DEFAULT NULL COMMENT '预留字段12',
  `ATTRIBUTE_13` decimal(65,30) DEFAULT NULL COMMENT '预留字段13',
  `ATTRIBUTE_14` decimal(65,30) DEFAULT NULL COMMENT '预留字段14',
  `ATTRIBUTE_15` decimal(65,30) DEFAULT NULL COMMENT '预留字段15',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='排序设置';

/*Data for the table `eform_tab_col_sort` */

/*Table structure for table `eform_tab_col_sys_code` */

DROP TABLE IF EXISTS `eform_tab_col_sys_code`;

CREATE TABLE `eform_tab_col_sys_code` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `TABLE_ID` varchar(50) NOT NULL COMMENT '表ID',
  `COLUMN_ID` varchar(50) NOT NULL COMMENT '列ID',
  `SYS_LOOKUP_ID` varchar(50) NOT NULL COMMENT '平台通用代码ID',
  `REMARK` varchar(255) DEFAULT NULL COMMENT '说明',
  `ORG_ID` varchar(50) DEFAULT NULL COMMENT '组织ID',
  `DEPT_ID` varchar(50) DEFAULT NULL COMMENT '部门ID',
  `SYS_ID` varchar(50) DEFAULT NULL COMMENT '系统标识ID',
  `SECRET_LEVEL` varchar(50) DEFAULT NULL COMMENT '密级',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '多应用ID',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '预留字段1',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '预留字段2',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '预留字段3',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '预留字段4',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '预留字段5',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '预留字段6',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '预留字段7',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '预留字段8',
  `ATTRIBUTE_09` datetime DEFAULT NULL COMMENT '预留字段9',
  `ATTRIBUTE_10` datetime DEFAULT NULL COMMENT '预留字段10',
  `ATTRIBUTE_11` decimal(65,30) DEFAULT NULL COMMENT '预留字段11',
  `ATTRIBUTE_12` decimal(65,30) DEFAULT NULL COMMENT '预留字段12',
  `ATTRIBUTE_13` decimal(65,30) DEFAULT NULL COMMENT '预留字段13',
  `ATTRIBUTE_14` decimal(65,30) DEFAULT NULL COMMENT '预留字段14',
  `ATTRIBUTE_15` decimal(65,30) DEFAULT NULL COMMENT '预留字段15',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='代码维护-平台通用';

/*Data for the table `eform_tab_col_sys_code` */

/*Table structure for table `eform_tab_columns` */

DROP TABLE IF EXISTS `eform_tab_columns`;

CREATE TABLE `eform_tab_columns` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `TABLE_ID` varchar(50) DEFAULT NULL COMMENT '表ID',
  `COL_NAME` varchar(32) DEFAULT NULL COMMENT '字段英文名',
  `COL_LABEL` varchar(128) DEFAULT NULL COMMENT '字段中文名',
  `COL_TYPE` varchar(50) DEFAULT NULL COMMENT '字段类型；下拉选择：字符串，整型，日期时间型',
  `COL_LENGTH` decimal(5,0) DEFAULT NULL COMMENT '字段长度；默认字符串长度为20，数值为3',
  `COL_DECIMAL` decimal(2,0) DEFAULT NULL COMMENT '小数位数',
  `COL_IS_SYS` varchar(2) DEFAULT NULL COMMENT '是否系统字段；Y-是，N-否；默认否',
  `COL_ORDER` decimal(65,30) DEFAULT NULL COMMENT '显示顺序；自动按序生成',
  `COL_IS_MUST` varchar(2) DEFAULT NULL COMMENT '是否必著；Y-是，N-否；默认否',
  `COL_IS_VISIBLE` varchar(2) DEFAULT NULL COMMENT '是否显示；Y-是，N-否；默认是',
  `COL_IS_SEARCH` varchar(2) DEFAULT NULL COMMENT '是否查询字段；Y-是，N-否；默认否',
  `COL_IS_EDIT` varchar(2) DEFAULT NULL COMMENT '编辑标识；Y-是，N-否；默认是',
  `COL_IS_TAB_VISIBLE` varchar(2) DEFAULT NULL COMMENT '是否列表显示；Y-是，N-否；默认是',
  `COL_IS_DETAIL` varchar(2) DEFAULT NULL COMMENT '是否详细显示；Y-是，N-否；默认是',
  `COL_DROPDOWN_TYPE` varchar(2) DEFAULT NULL COMMENT '下拉类型；0-无，1-参选，2-只选，3-选择(选人，选部门，自定义弹出页)\r\n',
  `COL_GENE_METHOD` varchar(2) DEFAULT NULL COMMENT '生成方式；下拉选择：0-空，1-默认值，2-序列，3-顺带，4-组合项，5-统计生成，6-选择',
  `COL_RULE_NAME` text COMMENT '生成规则英文',
  `COL_RULE_TITLE` varchar(128) DEFAULT NULL COMMENT '生成规则中文',
  `CUSTOM_PATH` text COMMENT '路径',
  `REMARK` varchar(255) DEFAULT NULL COMMENT '说明',
  `ORG_ID` varchar(50) DEFAULT NULL COMMENT '组织ID',
  `DEPT_ID` varchar(50) DEFAULT NULL COMMENT '部门ID',
  `SYS_ID` varchar(50) DEFAULT NULL COMMENT '系统标识ID',
  `SECRET_LEVEL` varchar(50) DEFAULT NULL COMMENT '密级',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '多应用ID',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '预留字段1',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '预留字段2',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '预留字段3',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '预留字段4',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '预留字段5',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '预留字段6',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '预留字段7',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '预留字段8',
  `ATTRIBUTE_09` datetime DEFAULT NULL COMMENT '预留字段9',
  `ATTRIBUTE_10` datetime DEFAULT NULL COMMENT '预留字段10',
  `ATTRIBUTE_11` decimal(65,30) DEFAULT NULL COMMENT '预留字段11',
  `ATTRIBUTE_12` decimal(65,30) DEFAULT NULL COMMENT '预留字段12',
  `ATTRIBUTE_13` decimal(65,30) DEFAULT NULL COMMENT '预留字段13',
  `ATTRIBUTE_14` decimal(65,30) DEFAULT NULL COMMENT '预留字段14',
  `ATTRIBUTE_15` decimal(65,30) DEFAULT NULL COMMENT '预留字段15',
  `COL_SHOW_FORMAT` varchar(2) DEFAULT NULL COMMENT '显示格式 0 无 1 日期 2 金额',
  `COL_GENE_METHOD_RULE` text COMMENT '生成方式规则',
  `COL_IS_DISPLAY` varchar(2) DEFAULT NULL COMMENT '是否可见；Y是，N否',
  `ELEMENT_TYPE` varchar(50) DEFAULT NULL,
  `COL_VALIDATE_TYPE` varchar(50) DEFAULT NULL,
  `COL_IS_UNIQUE` varchar(50) DEFAULT NULL,
  `COL_AUTOCODE` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='列信息';

/*Data for the table `eform_tab_columns` */

/*Table structure for table `eform_tab_form` */

DROP TABLE IF EXISTS `eform_tab_form`;

CREATE TABLE `eform_tab_form` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `FORM_NAME` varchar(128) NOT NULL COMMENT '表单名称',
  `FORM_IS_DEFALT` varchar(2) NOT NULL COMMENT '是否默认表单；Y-是，N-否',
  `REMARK` varchar(255) DEFAULT NULL COMMENT '说明',
  `ORG_ID` varchar(50) DEFAULT NULL COMMENT '组织ID',
  `DEPT_ID` varchar(50) DEFAULT NULL COMMENT '部门ID',
  `SYS_ID` varchar(50) DEFAULT NULL COMMENT '系统标识ID',
  `SECRET_LEVEL` varchar(50) DEFAULT NULL COMMENT '密级',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '多应用ID',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '预留字段1',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '预留字段2',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '预留字段3',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '预留字段4',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '预留字段5',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '预留字段6',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '预留字段7',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '预留字段8',
  `ATTRIBUTE_09` datetime DEFAULT NULL COMMENT '预留字段9',
  `ATTRIBUTE_10` datetime DEFAULT NULL COMMENT '预留字段10',
  `ATTRIBUTE_11` decimal(65,30) DEFAULT NULL COMMENT '预留字段11',
  `ATTRIBUTE_12` decimal(65,30) DEFAULT NULL COMMENT '预留字段12',
  `ATTRIBUTE_13` decimal(65,30) DEFAULT NULL COMMENT '预留字段13',
  `ATTRIBUTE_14` decimal(65,30) DEFAULT NULL COMMENT '预留字段14',
  `ATTRIBUTE_15` decimal(65,30) DEFAULT NULL COMMENT '预留字段15',
  `FORM_CONTENT` longblob,
  `FORM_LAYOUT` longblob,
  `TABLE_ID` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='表单基本信息';

/*Data for the table `eform_tab_form` */

/*Table structure for table `eform_tab_form_config` */

DROP TABLE IF EXISTS `eform_tab_form_config`;

CREATE TABLE `eform_tab_form_config` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `FORM_ID` varchar(50) NOT NULL COMMENT '表单ID',
  `COLUMN_ID` varchar(50) NOT NULL COMMENT '列ID',
  `FORM_VERTICAL` decimal(65,30) NOT NULL COMMENT '纵向栏数',
  `FORM_HORIZONTAL` decimal(65,30) NOT NULL COMMENT '横向栏数',
  `REMARK` varchar(255) DEFAULT NULL COMMENT '说明',
  `ORG_ID` varchar(50) NOT NULL COMMENT '组织ID',
  `DEPT_ID` varchar(50) NOT NULL COMMENT '部门ID',
  `SYS_ID` varchar(50) DEFAULT NULL COMMENT '系统标识ID',
  `SECRET_LEVEL` varchar(50) DEFAULT NULL COMMENT '密级',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '多应用ID',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '预留字段1',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '预留字段2',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '预留字段3',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '预留字段4',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '预留字段5',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '预留字段6',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '预留字段7',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '预留字段8',
  `ATTRIBUTE_09` datetime DEFAULT NULL COMMENT '预留字段9',
  `ATTRIBUTE_10` datetime DEFAULT NULL COMMENT '预留字段10',
  `ATTRIBUTE_11` decimal(65,30) DEFAULT NULL COMMENT '预留字段11',
  `ATTRIBUTE_12` decimal(65,30) DEFAULT NULL COMMENT '预留字段12',
  `ATTRIBUTE_13` decimal(65,30) DEFAULT NULL COMMENT '预留字段13',
  `ATTRIBUTE_14` decimal(65,30) DEFAULT NULL COMMENT '预留字段14',
  `ATTRIBUTE_15` decimal(65,30) DEFAULT NULL COMMENT '预留字段15',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='表单配置信息';

/*Data for the table `eform_tab_form_config` */

/*Table structure for table `eform_tab_form_define` */

DROP TABLE IF EXISTS `eform_tab_form_define`;

CREATE TABLE `eform_tab_form_define` (
  `ID` varchar(50) NOT NULL,
  `TABLE_ID` varchar(50) DEFAULT NULL,
  `COLUMN_NAME` varchar(50) DEFAULT NULL,
  `TR_ORDER` decimal(65,30) DEFAULT NULL,
  `TD_ORDER` decimal(65,30) DEFAULT NULL,
  `TD_ROWSPAN` decimal(65,30) DEFAULT NULL,
  `TD_COLSPAN` decimal(65,30) DEFAULT NULL,
  `LAST_UPDATE_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` varchar(50) DEFAULT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATE_IP` varchar(50) DEFAULT NULL,
  `CREATED_BY` varchar(50) DEFAULT NULL,
  `VERSION` decimal(65,30) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `eform_tab_form_define` */

/*Table structure for table `eform_tab_form_node` */

DROP TABLE IF EXISTS `eform_tab_form_node`;

CREATE TABLE `eform_tab_form_node` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `TAB_NODE_ID` varchar(50) NOT NULL COMMENT '表与节点关系ID（外键）',
  `FORM_ID` varchar(50) NOT NULL COMMENT '表单ID（外键）',
  `REMARK` varchar(255) DEFAULT NULL COMMENT '说明',
  `ORG_ID` varchar(50) NOT NULL COMMENT '组织ID',
  `DEPT_ID` varchar(50) NOT NULL COMMENT '部门ID',
  `SYS_ID` varchar(50) DEFAULT NULL COMMENT '系统标识ID',
  `SECRET_LEVEL` varchar(50) DEFAULT NULL COMMENT '密级',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '多应用ID',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '预留字段1',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '预留字段2',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '预留字段3',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '预留字段4',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '预留字段5',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '预留字段6',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '预留字段7',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '预留字段8',
  `ATTRIBUTE_09` datetime DEFAULT NULL COMMENT '预留字段9',
  `ATTRIBUTE_10` datetime DEFAULT NULL COMMENT '预留字段10',
  `ATTRIBUTE_11` decimal(65,30) DEFAULT NULL COMMENT '预留字段11',
  `ATTRIBUTE_12` decimal(65,30) DEFAULT NULL COMMENT '预留字段12',
  `ATTRIBUTE_13` decimal(65,30) DEFAULT NULL COMMENT '预留字段13',
  `ATTRIBUTE_14` decimal(65,30) DEFAULT NULL COMMENT '预留字段14',
  `ATTRIBUTE_15` decimal(65,30) DEFAULT NULL COMMENT '预留字段15',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='表单与节点关联表';

/*Data for the table `eform_tab_form_node` */

/*Table structure for table `eform_tab_form_select` */

DROP TABLE IF EXISTS `eform_tab_form_select`;

CREATE TABLE `eform_tab_form_select` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `SEL_NAME` varchar(128) NOT NULL COMMENT '名称',
  `SEL_CODE` varchar(32) DEFAULT NULL COMMENT '代码',
  `SEL_URL` text COMMENT '路径',
  `REMARK` varchar(255) DEFAULT NULL COMMENT '说明',
  `ORG_ID` varchar(50) NOT NULL COMMENT '组织ID',
  `DEPT_ID` varchar(50) NOT NULL COMMENT '部门ID',
  `SYS_ID` varchar(50) DEFAULT NULL COMMENT '系统标识ID',
  `SECRET_LEVEL` varchar(50) DEFAULT NULL COMMENT '密级',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '多应用ID',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '预留字段1',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '预留字段2',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '预留字段3',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '预留字段4',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '预留字段5',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '预留字段6',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '预留字段7',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '预留字段8',
  `ATTRIBUTE_09` datetime DEFAULT NULL COMMENT '预留字段9',
  `ATTRIBUTE_10` datetime DEFAULT NULL COMMENT '预留字段10',
  `ATTRIBUTE_11` decimal(65,30) DEFAULT NULL COMMENT '预留字段11',
  `ATTRIBUTE_12` decimal(65,30) DEFAULT NULL COMMENT '预留字段12',
  `ATTRIBUTE_13` decimal(65,30) DEFAULT NULL COMMENT '预留字段13',
  `ATTRIBUTE_14` decimal(65,30) DEFAULT NULL COMMENT '预留字段14',
  `ATTRIBUTE_15` decimal(65,30) DEFAULT NULL COMMENT '预留字段15',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='生成方式选择表';

/*Data for the table `eform_tab_form_select` */

/*Table structure for table `eform_tab_node` */

DROP TABLE IF EXISTS `eform_tab_node`;

CREATE TABLE `eform_tab_node` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `TABLE_ID` varchar(50) NOT NULL COMMENT '表ID（外键）',
  `NODE_ID` varchar(50) NOT NULL COMMENT '节点ID（外键）',
  `TAB_ORDER` decimal(65,30) NOT NULL COMMENT '显示顺序；自动按序生成',
  `REMARK` varchar(255) DEFAULT NULL COMMENT '说明',
  `ORG_ID` varchar(50) NOT NULL COMMENT '组织ID',
  `DEPT_ID` varchar(50) NOT NULL COMMENT '部门ID',
  `SYS_ID` varchar(50) DEFAULT NULL COMMENT '系统标识ID',
  `SECRET_LEVEL` varchar(50) DEFAULT NULL COMMENT '密级',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '多应用ID',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '预留字段1',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '预留字段2',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '预留字段3',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '预留字段4',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '预留字段5',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '预留字段6',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '预留字段7',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '预留字段8',
  `ATTRIBUTE_09` datetime DEFAULT NULL COMMENT '预留字段9',
  `ATTRIBUTE_10` datetime DEFAULT NULL COMMENT '预留字段10',
  `ATTRIBUTE_11` decimal(65,30) DEFAULT NULL COMMENT '预留字段11',
  `ATTRIBUTE_12` decimal(65,30) DEFAULT NULL COMMENT '预留字段12',
  `ATTRIBUTE_13` decimal(65,30) DEFAULT NULL COMMENT '预留字段13',
  `ATTRIBUTE_14` decimal(65,30) DEFAULT NULL COMMENT '预留字段14',
  `ATTRIBUTE_15` decimal(65,30) DEFAULT NULL COMMENT '预留字段15',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT=' 表与节点关联表';

/*Data for the table `eform_tab_node` */

/*Table structure for table `eform_tab_node_record` */

DROP TABLE IF EXISTS `eform_tab_node_record`;

CREATE TABLE `eform_tab_node_record` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `TAB_NODE_ID` varchar(50) NOT NULL COMMENT '表与节点关系ID（外键）',
  `COLUMN_ID` varchar(50) NOT NULL COMMENT '列ID（外键）',
  `COL_IS_VISIBLE` varchar(2) NOT NULL COMMENT '是否显示；Y-是，N-否；默认是',
  `COL_IS_TAB_VISIBLE` varchar(2) NOT NULL COMMENT '是否列表显示；Y-是，N-否；默认是',
  `COL_IS_DETAIL` varchar(2) NOT NULL COMMENT '是否详细显示；Y-是，N-否；默认是',
  `COL_ORDER` decimal(65,30) NOT NULL COMMENT '显示顺序；自动按序生成',
  `REMARK` varchar(255) DEFAULT NULL COMMENT '说明',
  `ORG_ID` varchar(50) NOT NULL COMMENT '组织ID',
  `DEPT_ID` varchar(50) NOT NULL COMMENT '部门ID',
  `SYS_ID` varchar(50) DEFAULT NULL COMMENT '系统标识ID',
  `SECRET_LEVEL` varchar(50) DEFAULT NULL COMMENT '密级',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '多应用ID',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '最后更新IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '预留字段1',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '预留字段2',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '预留字段3',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '预留字段4',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '预留字段5',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '预留字段6',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '预留字段7',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '预留字段8',
  `ATTRIBUTE_09` datetime DEFAULT NULL COMMENT '预留字段9',
  `ATTRIBUTE_10` datetime DEFAULT NULL COMMENT '预留字段10',
  `ATTRIBUTE_11` decimal(65,30) DEFAULT NULL COMMENT '预留字段11',
  `ATTRIBUTE_12` decimal(65,30) DEFAULT NULL COMMENT '预留字段12',
  `ATTRIBUTE_13` decimal(65,30) DEFAULT NULL COMMENT '预留字段13',
  `ATTRIBUTE_14` decimal(65,30) DEFAULT NULL COMMENT '预留字段14',
  `ATTRIBUTE_15` decimal(65,30) DEFAULT NULL COMMENT '预留字段15',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='节点著录定义表';

/*Data for the table `eform_tab_node_record` */

/*Table structure for table `eform_tab_table_templet` */

DROP TABLE IF EXISTS `eform_tab_table_templet`;

CREATE TABLE `eform_tab_table_templet` (
  `ID` varchar(50) NOT NULL,
  `TABLE_ID` varchar(50) DEFAULT NULL,
  `TEMPLET_ID` varchar(50) DEFAULT NULL,
  `LAST_UPDATE_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` varchar(50) DEFAULT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `CREATED_BY` varchar(50) DEFAULT NULL,
  `LAST_UPDATE_IP` varchar(50) DEFAULT NULL,
  `VERSION` decimal(16,0) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `eform_tab_table_templet` */

/*Table structure for table `eform_tab_version` */

DROP TABLE IF EXISTS `eform_tab_version`;

CREATE TABLE `eform_tab_version` (
  `ID` varchar(50) DEFAULT NULL,
  `TABLE_ID` varchar(50) DEFAULT NULL,
  `VERSION_KEY` decimal(65,30) DEFAULT NULL,
  `VERSION_VALUE` varchar(50) DEFAULT NULL,
  `VERSION_DESC` longtext,
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL,
  `LAST_UPDATE_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` varchar(50) DEFAULT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `CREATED_BY` varchar(50) DEFAULT NULL,
  `LAST_UPDATE_IP` varchar(50) DEFAULT NULL,
  `VERSION` decimal(65,30) DEFAULT NULL,
  `COLUMN_ID` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `eform_tab_version` */

/*Table structure for table `eform_tables` */

DROP TABLE IF EXISTS `eform_tables`;

CREATE TABLE `eform_tables` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `TABLE_NAME` varchar(32) DEFAULT NULL COMMENT '表英文名',
  `TABLE_TITLE` varchar(32) DEFAULT NULL COMMENT '表中文名',
  `IS_VISIBLE` varchar(2) DEFAULT NULL COMMENT '是否可见；Y-是，N-否；默认是',
  `REMARK` varchar(255) DEFAULT NULL COMMENT '说明',
  `ORG_ID` varchar(50) DEFAULT NULL COMMENT '组织ID',
  `DEPT_ID` varchar(50) DEFAULT NULL COMMENT '部门ID',
  `SYS_ID` varchar(50) DEFAULT NULL COMMENT '系统标识ID',
  `SECRET_LEVEL` varchar(50) DEFAULT NULL COMMENT '密级',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '多应用ID',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '预留字段1',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '预留字段2',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '预留字段3',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '预留字段4',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '预留字段5',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '预留字段6',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '预留字段7',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '预留字段8',
  `ATTRIBUTE_09` datetime DEFAULT NULL COMMENT '预留字段9',
  `ATTRIBUTE_10` datetime DEFAULT NULL COMMENT '预留字段10',
  `ATTRIBUTE_11` decimal(65,30) DEFAULT NULL COMMENT '预留字段11',
  `ATTRIBUTE_12` decimal(65,30) DEFAULT NULL COMMENT '预留字段12',
  `ATTRIBUTE_13` decimal(65,30) DEFAULT NULL COMMENT '预留字段13',
  `ATTRIBUTE_14` decimal(65,30) DEFAULT NULL COMMENT '预留字段14',
  `ATTRIBUTE_15` decimal(65,30) DEFAULT NULL COMMENT '预留字段15',
  `TABLE_IS_TRUE_TABLE` varchar(2) DEFAULT NULL COMMENT '虚拟表标示；Y真实表，N虚拟表',
  `SUB_TABLE_NAME` varchar(50) DEFAULT NULL,
  `SUB_COLUMN_NAME` varchar(50) DEFAULT NULL,
  `TABLE_IS_CREATED` varchar(2) DEFAULT NULL,
  `TABLE_IS_UPLOAD` varchar(2) DEFAULT NULL,
  `TABLE_IS_BPM` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='表信息';

/*Data for the table `eform_tables` */

/*Table structure for table `eform_templet_code` */

DROP TABLE IF EXISTS `eform_templet_code`;

CREATE TABLE `eform_templet_code` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `TEMPLET_ID` varchar(50) NOT NULL COMMENT '模板ID',
  `FIELD_ID` varchar(50) NOT NULL COMMENT '字段ID',
  `CODE_ORDER` decimal(65,30) NOT NULL COMMENT '顺序',
  `LOOKUP_NAME` varchar(128) NOT NULL COMMENT '显示值',
  `LOOKUP_CODE` varchar(128) NOT NULL COMMENT '真实值；手动输入，默认与显示值一样',
  `CODE_IS_VALID` varchar(2) NOT NULL COMMENT '是否有效；Y-有效，N-无效',
  `REMARK` varchar(255) DEFAULT NULL COMMENT '说明',
  `ORG_ID` varchar(50) NOT NULL COMMENT '组织ID',
  `DEPT_ID` varchar(50) NOT NULL COMMENT '部门ID',
  `SYS_ID` varchar(50) DEFAULT NULL COMMENT '系统标识ID',
  `SECRET_LEVEL` varchar(50) DEFAULT NULL COMMENT '密级',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '多应用ID',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '预留字段1',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '预留字段2',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '预留字段3',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '预留字段4',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '预留字段5',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '预留字段6',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '预留字段7',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '预留字段8',
  `ATTRIBUTE_09` datetime DEFAULT NULL COMMENT '预留字段9',
  `ATTRIBUTE_10` datetime DEFAULT NULL COMMENT '预留字段10',
  `ATTRIBUTE_11` decimal(65,30) DEFAULT NULL COMMENT '预留字段11',
  `ATTRIBUTE_12` decimal(65,30) DEFAULT NULL COMMENT '预留字段12',
  `ATTRIBUTE_13` decimal(65,30) DEFAULT NULL COMMENT '预留字段13',
  `ATTRIBUTE_14` decimal(65,30) DEFAULT NULL COMMENT '预留字段14',
  `ATTRIBUTE_15` decimal(65,30) DEFAULT NULL COMMENT '预留字段15',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='参考模板代码维护';

/*Data for the table `eform_templet_code` */

/*Table structure for table `eform_templet_field` */

DROP TABLE IF EXISTS `eform_templet_field`;

CREATE TABLE `eform_templet_field` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `TEMPLET_ID` varchar(50) NOT NULL COMMENT '模板ID',
  `COL_NAME` varchar(32) NOT NULL COMMENT '字段英文名',
  `COL_LABEL` varchar(128) NOT NULL COMMENT '字段中文名',
  `COL_TYPE` varchar(50) NOT NULL COMMENT '字段类型；下拉选择：字符串，数值，日期时间',
  `COL_LENGTH` decimal(5,0) DEFAULT NULL COMMENT '字段长度；默认字符串长度为20，数值为3',
  `COL_DECIMAL` decimal(2,0) DEFAULT NULL COMMENT '小数位数',
  `COL_IS_SYS` varchar(2) DEFAULT NULL COMMENT '是否系统字段；Y-是，N-否；默认否',
  `COL_ORDER` decimal(65,30) NOT NULL COMMENT '显示顺序；自动按序生成',
  `COL_IS_MUST` varchar(2) NOT NULL COMMENT '是否必著；Y-是，N-否；默认否',
  `COL_IS_VISIBLE` varchar(2) NOT NULL COMMENT '是否显示；Y-是，N-否；默认是',
  `COL_IS_SEARCH` varchar(2) NOT NULL COMMENT '是否查询字段；Y-是，N-否；默认否',
  `COL_IS_EDIT` varchar(2) NOT NULL COMMENT '编辑标识；Y-是，N-否；默认是',
  `COL_IS_TAB_VISIBLE` varchar(2) NOT NULL COMMENT '是否列表显示；Y-是，N-否；默认是',
  `COL_IS_DETAIL` varchar(2) NOT NULL COMMENT '是否详细显示；Y-是，N-否；默认是',
  `COL_DROPDOWN_TYPE` varchar(2) NOT NULL COMMENT '下拉类型；0-无，1-只选，2-参选',
  `COL_GENE_METHOD` varchar(2) NOT NULL COMMENT '生成方式；下拉选择：0-空，1-默认值，2-序列，3-顺带，4-组合项，5-统计生成，6-选择',
  `COL_RULE_NAME` text COMMENT '生成规则英文',
  `COL_RULE_TITLE` varchar(128) DEFAULT NULL COMMENT '生成规则中文',
  `CUSTOM_PATH` text COMMENT '路径',
  `REMARK` varchar(255) DEFAULT NULL COMMENT '说明',
  `ORG_ID` varchar(50) DEFAULT NULL COMMENT '组织ID',
  `DEPT_ID` varchar(50) DEFAULT NULL COMMENT '部门ID',
  `SYS_ID` varchar(50) DEFAULT NULL COMMENT '系统标识ID',
  `SECRET_LEVEL` varchar(50) DEFAULT NULL COMMENT '密级',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '多应用ID',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '预留字段1',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '预留字段2',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '预留字段3',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '预留字段4',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '预留字段5',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '预留字段6',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '预留字段7',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '预留字段8',
  `ATTRIBUTE_09` datetime DEFAULT NULL COMMENT '预留字段9',
  `ATTRIBUTE_10` datetime DEFAULT NULL COMMENT '预留字段10',
  `ATTRIBUTE_11` decimal(65,30) DEFAULT NULL COMMENT '预留字段11',
  `ATTRIBUTE_12` decimal(65,30) DEFAULT NULL COMMENT '预留字段12',
  `ATTRIBUTE_13` decimal(65,30) DEFAULT NULL COMMENT '预留字段13',
  `ATTRIBUTE_14` decimal(65,30) DEFAULT NULL COMMENT '预留字段14',
  `ATTRIBUTE_15` decimal(65,30) DEFAULT NULL COMMENT '预留字段15',
  `COL_IS_DISPLAY` varchar(2) DEFAULT NULL COMMENT '是否可见；Y是，N否',
  `COL_GENE_METHOD_RULE` text COMMENT '生成方式规则值',
  `COL_SHOW_FORMAT` varchar(2) DEFAULT NULL COMMENT '显示格式 0无，1日期，2金额',
  `ELEMENT_TYPE` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='参考模板字段信息';

/*Data for the table `eform_templet_field` */

/*Table structure for table `eform_templet_info` */

DROP TABLE IF EXISTS `eform_templet_info`;

CREATE TABLE `eform_templet_info` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `TEMP_CODE` varchar(32) DEFAULT NULL COMMENT '编号',
  `TEMP_NAME` varchar(128) DEFAULT NULL COMMENT '名称',
  `PARENT_ID` varchar(50) DEFAULT NULL COMMENT '父ID',
  `TEMP_TYPE` varchar(2) DEFAULT NULL COMMENT '类型；R-根节点；F-模板夹，C-模板，O-组织标识，S-系统标识',
  `IS_SYS_INIT` varchar(2) DEFAULT NULL COMMENT '是否系统初始；Y-是，N-否',
  `REMARK` varchar(255) DEFAULT NULL COMMENT '说明',
  `ORG_ID` varchar(50) DEFAULT NULL COMMENT '组织ID',
  `DEPT_ID` varchar(50) DEFAULT NULL COMMENT '部门ID',
  `SYS_ID` varchar(50) DEFAULT NULL COMMENT '系统标识ID',
  `SECRET_LEVEL` varchar(50) DEFAULT NULL COMMENT '密级',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '多应用ID',
  `LAST_UPDATE_DATE` datetime DEFAULT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) DEFAULT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime DEFAULT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) DEFAULT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) DEFAULT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) DEFAULT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '预留字段1',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '预留字段2',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '预留字段3',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '预留字段4',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '预留字段5',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '预留字段6',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '预留字段7',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '预留字段8',
  `ATTRIBUTE_09` datetime DEFAULT NULL COMMENT '预留字段9',
  `ATTRIBUTE_10` datetime DEFAULT NULL COMMENT '预留字段10',
  `ATTRIBUTE_11` decimal(65,30) DEFAULT NULL COMMENT '预留字段11',
  `ATTRIBUTE_12` decimal(65,30) DEFAULT NULL COMMENT '预留字段12',
  `ATTRIBUTE_13` decimal(65,30) DEFAULT NULL COMMENT '预留字段13',
  `ATTRIBUTE_14` decimal(65,30) DEFAULT NULL COMMENT '预留字段14',
  `ATTRIBUTE_15` decimal(65,30) DEFAULT NULL COMMENT '预留字段15',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='参考模板基本信息';

/*Data for the table `eform_templet_info` */

insert  into `eform_templet_info` values ('8a58ab4d4c2141fd014c217c436a02b2','parent','参考模板分类','ROOT','R','Y',NULL,'8a58ab4d4c2141fd014c217c436a02b2','8a58ab4d4c2141fd014c217cdc5102b6','1','1','1','2015-09-01 00:00:00','1','2014-09-04 00:00:00','admin','0:0:0:0:0:0:0:1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

/*Table structure for table `eform_templet_sys_code` */

DROP TABLE IF EXISTS `eform_templet_sys_code`;

CREATE TABLE `eform_templet_sys_code` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `TEMPLET_ID` varchar(50) NOT NULL COMMENT '模板ID',
  `FIELD_ID` varchar(50) NOT NULL COMMENT '字段ID',
  `SYS_LOOKUP_ID` varchar(50) NOT NULL COMMENT '平台通用代码ID',
  `REMARK` varchar(255) DEFAULT NULL COMMENT '说明',
  `ORG_ID` varchar(50) DEFAULT NULL COMMENT '组织ID',
  `DEPT_ID` varchar(50) DEFAULT NULL COMMENT '部门ID',
  `SYS_ID` varchar(50) DEFAULT NULL COMMENT '系统标识ID',
  `SECRET_LEVEL` varchar(50) DEFAULT NULL COMMENT '密级',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '多应用ID',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '预留字段1',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '预留字段2',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '预留字段3',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '预留字段4',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '预留字段5',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '预留字段6',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '预留字段7',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '预留字段8',
  `ATTRIBUTE_09` datetime DEFAULT NULL COMMENT '预留字段9',
  `ATTRIBUTE_10` datetime DEFAULT NULL COMMENT '预留字段10',
  `ATTRIBUTE_11` decimal(65,30) DEFAULT NULL COMMENT '预留字段11',
  `ATTRIBUTE_12` decimal(65,30) DEFAULT NULL COMMENT '预留字段12',
  `ATTRIBUTE_13` decimal(65,30) DEFAULT NULL COMMENT '预留字段13',
  `ATTRIBUTE_14` decimal(65,30) DEFAULT NULL COMMENT '预留字段14',
  `ATTRIBUTE_15` decimal(65,30) DEFAULT NULL COMMENT '预留字段15',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='参考模板代码维护-平台通用';

/*Data for the table `eform_templet_sys_code` */

/*Table structure for table `files_fastdfs` */

DROP TABLE IF EXISTS `files_fastdfs`;

CREATE TABLE `files_fastdfs` (
  `ID` varchar(50) NOT NULL,
  `TEMP_FAST_ID` varchar(50) NOT NULL,
  `FASTDFS_LOCATION` text,
  `ORDER_BY` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `files_fastdfs` */

/*Table structure for table `files_temp` */

DROP TABLE IF EXISTS `files_temp`;

CREATE TABLE `files_temp` (
  `ID` varchar(50) NOT NULL,
  `FILE_NAME` varchar(100) DEFAULT NULL,
  `SCHUNK` decimal(10,0) DEFAULT NULL,
  `SCHUNKS` decimal(10,0) DEFAULT NULL,
  `FASTDFS_LOCATION` text,
  `PARENT_TABLE_ID` varchar(50) DEFAULT NULL,
  `PARENT_REGISTER_ID` varchar(50) DEFAULT NULL,
  `ATTACH_CATEGORY` varchar(32) DEFAULT NULL,
  `SECRET_LEVEL` varchar(32) DEFAULT NULL,
  `LASTDATE` varchar(100) DEFAULT NULL,
  `FILE_SIZE` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `files_temp` */

/*Table structure for table `model_business_flow` */

DROP TABLE IF EXISTS `model_business_flow`;

CREATE TABLE `model_business_flow` (
  `ID` varchar(50) NOT NULL COMMENT '主键ID',
  `TYPE` varchar(50) DEFAULT NULL COMMENT '模型类型',
  `NAME` varchar(100) DEFAULT NULL COMMENT '模型名称',
  `XML` longblob COMMENT '模型实体',
  `ATTRIBUTE` longblob COMMENT '模型属性',
  `REMARKS` text COMMENT '模型描述',
  `FLOW_ID` varchar(100) DEFAULT NULL COMMENT '模型ID',
  `VERSION` decimal(16,1) DEFAULT NULL COMMENT '模型版本'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='业务流程设计器模型表';

/*Data for the table `model_business_flow` */

/*Table structure for table `model_function_module` */

DROP TABLE IF EXISTS `model_function_module`;

CREATE TABLE `model_function_module` (
  `MODEL_ID` varchar(35) NOT NULL COMMENT '模型ID',
  `MODEL_NAME` varchar(255) DEFAULT NULL COMMENT '功能结构模型名称',
  `MODEL_DESC` varchar(255) DEFAULT NULL COMMENT '功能结构模型描述信息',
  `TYPE` varchar(25) DEFAULT NULL COMMENT '模型类型（功能结构图）',
  `MODEL_DEF_XML` longblob COMMENT '模型定义的XML内容',
  `VERSION` varchar(10) DEFAULT NULL COMMENT '模型版本信息',
  `MODEL_ATTRIBUTE01` varchar(255) DEFAULT NULL COMMENT '保留属性字段',
  `MODEL_ATTRIBUTE00` varchar(255) DEFAULT NULL COMMENT '保留属性字段',
  `MODEL_ALL_CONTENT` longblob COMMENT '利用XMLStream保存当前模型对象的所有信息',
  `DB_ID` varchar(38) NOT NULL COMMENT '主键ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `model_function_module` */

/*Table structure for table `model_function_module_tree` */

DROP TABLE IF EXISTS `model_function_module_tree`;

CREATE TABLE `model_function_module_tree` (
  `DBID` varchar(50) NOT NULL COMMENT '主键ID',
  `NODE_NAME` varchar(100) DEFAULT NULL COMMENT '显示名称',
  `CODE` varchar(100) DEFAULT NULL COMMENT '可能用到的代码',
  `TYPE` varchar(50) DEFAULT NULL COMMENT '类型描述',
  `PARENTID` varchar(100) DEFAULT NULL COMMENT '所属父元素ID',
  `REMARK` varchar(200) DEFAULT NULL COMMENT '其他',
  `MODELID` varchar(50) DEFAULT NULL COMMENT '模型ID',
  `ORDER_BY` varchar(10) DEFAULT NULL COMMENT '排序列'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `model_function_module_tree` */

/*Table structure for table `model_organiz` */

DROP TABLE IF EXISTS `model_organiz`;

CREATE TABLE `model_organiz` (
  `ID` varchar(50) NOT NULL COMMENT '主键ID',
  `TYPE` varchar(50) DEFAULT NULL COMMENT '模型类型',
  `NAME` varchar(100) DEFAULT NULL COMMENT '模型名称',
  `XML` longblob COMMENT '模型实体',
  `ATTRIBUTE` longblob COMMENT '模型属性',
  `REMARK` text COMMENT '模型描述',
  `VERSION` varchar(20) DEFAULT NULL COMMENT '模型版本'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='业务流程设计器模型表';

/*Data for the table `model_organiz` */

/*Table structure for table `model_user_case` */

DROP TABLE IF EXISTS `model_user_case`;

CREATE TABLE `model_user_case` (
  `ID` varchar(50) NOT NULL COMMENT '主键ID',
  `TYPE` varchar(50) DEFAULT NULL COMMENT '模型类型',
  `NAME` varchar(100) DEFAULT NULL COMMENT '模型名称',
  `XML` longblob COMMENT '模型实体',
  `ATTRIBUTE` longblob COMMENT '模型属性',
  `REMARK` text COMMENT '模型描述',
  `VERSION` varchar(20) DEFAULT NULL COMMENT '模型版本'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='业务流程设计器模型表';

/*Data for the table `model_user_case` */

/*Table structure for table `qrtz_blob_triggers` */

DROP TABLE IF EXISTS `qrtz_blob_triggers`;

CREATE TABLE `qrtz_blob_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `BLOB_DATA` longblob,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `qrtz_blob_triggers` */

/*Table structure for table `qrtz_calendars` */

DROP TABLE IF EXISTS `qrtz_calendars`;

CREATE TABLE `qrtz_calendars` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `CALENDAR_NAME` varchar(200) NOT NULL,
  `CALENDAR` longblob NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`CALENDAR_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `qrtz_calendars` */

/*Table structure for table `qrtz_cron_triggers` */

DROP TABLE IF EXISTS `qrtz_cron_triggers`;

CREATE TABLE `qrtz_cron_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `CRON_EXPRESSION` varchar(120) NOT NULL,
  `TIME_ZONE_ID` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `qrtz_cron_triggers` */

/*Table structure for table `qrtz_fired_triggers` */

DROP TABLE IF EXISTS `qrtz_fired_triggers`;

CREATE TABLE `qrtz_fired_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `ENTRY_ID` varchar(95) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `INSTANCE_NAME` varchar(200) NOT NULL,
  `FIRED_TIME` decimal(13,0) NOT NULL,
  `PRIORITY` decimal(13,0) NOT NULL,
  `STATE` varchar(16) NOT NULL,
  `JOB_NAME` varchar(200) DEFAULT NULL,
  `JOB_GROUP` varchar(200) DEFAULT NULL,
  `IS_NONCONCURRENT` varchar(1) DEFAULT NULL,
  `REQUESTS_RECOVERY` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`ENTRY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `qrtz_fired_triggers` */

/*Table structure for table `qrtz_job_details` */

DROP TABLE IF EXISTS `qrtz_job_details`;

CREATE TABLE `qrtz_job_details` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `JOB_NAME` varchar(200) NOT NULL,
  `JOB_GROUP` varchar(200) NOT NULL,
  `DESCRIPTION` varchar(250) DEFAULT NULL,
  `JOB_CLASS_NAME` varchar(250) NOT NULL,
  `IS_DURABLE` varchar(1) NOT NULL,
  `IS_NONCONCURRENT` varchar(1) NOT NULL,
  `IS_UPDATE_DATA` varchar(1) NOT NULL,
  `REQUESTS_RECOVERY` varchar(1) NOT NULL,
  `JOB_DATA` longblob,
  PRIMARY KEY (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `qrtz_job_details` */

/*Table structure for table `qrtz_locks` */

DROP TABLE IF EXISTS `qrtz_locks`;

CREATE TABLE `qrtz_locks` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `LOCK_NAME` varchar(40) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`LOCK_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `qrtz_locks` */

/*Table structure for table `qrtz_paused_trigger_grps` */

DROP TABLE IF EXISTS `qrtz_paused_trigger_grps`;

CREATE TABLE `qrtz_paused_trigger_grps` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `qrtz_paused_trigger_grps` */

/*Table structure for table `qrtz_scheduler_state` */

DROP TABLE IF EXISTS `qrtz_scheduler_state`;

CREATE TABLE `qrtz_scheduler_state` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `INSTANCE_NAME` varchar(200) NOT NULL,
  `LAST_CHECKIN_TIME` decimal(13,0) NOT NULL,
  `CHECKIN_INTERVAL` decimal(13,0) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`INSTANCE_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `qrtz_scheduler_state` */

/*Table structure for table `qrtz_simple_triggers` */

DROP TABLE IF EXISTS `qrtz_simple_triggers`;

CREATE TABLE `qrtz_simple_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `REPEAT_COUNT` decimal(7,0) NOT NULL,
  `REPEAT_INTERVAL` decimal(12,0) NOT NULL,
  `TIMES_TRIGGERED` decimal(10,0) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `qrtz_simple_triggers` */

/*Table structure for table `qrtz_simprop_triggers` */

DROP TABLE IF EXISTS `qrtz_simprop_triggers`;

CREATE TABLE `qrtz_simprop_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `STR_PROP_1` text,
  `STR_PROP_2` text,
  `STR_PROP_3` text,
  `INT_PROP_1` decimal(10,0) DEFAULT NULL,
  `INT_PROP_2` decimal(10,0) DEFAULT NULL,
  `LONG_PROP_1` decimal(13,0) DEFAULT NULL,
  `LONG_PROP_2` decimal(13,0) DEFAULT NULL,
  `DEC_PROP_1` decimal(13,4) DEFAULT NULL,
  `DEC_PROP_2` decimal(13,4) DEFAULT NULL,
  `BOOL_PROP_1` varchar(1) DEFAULT NULL,
  `BOOL_PROP_2` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `qrtz_simprop_triggers` */

/*Table structure for table `qrtz_triggers` */

DROP TABLE IF EXISTS `qrtz_triggers`;

CREATE TABLE `qrtz_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `JOB_NAME` varchar(200) NOT NULL,
  `JOB_GROUP` varchar(200) NOT NULL,
  `DESCRIPTION` varchar(250) DEFAULT NULL,
  `NEXT_FIRE_TIME` decimal(13,0) DEFAULT NULL,
  `PREV_FIRE_TIME` decimal(13,0) DEFAULT NULL,
  `PRIORITY` decimal(13,0) DEFAULT NULL,
  `TRIGGER_STATE` varchar(16) NOT NULL,
  `TRIGGER_TYPE` varchar(8) NOT NULL,
  `START_TIME` decimal(13,0) NOT NULL,
  `END_TIME` decimal(13,0) DEFAULT NULL,
  `CALENDAR_NAME` varchar(200) DEFAULT NULL,
  `MISFIRE_INSTR` decimal(2,0) DEFAULT NULL,
  `JOB_DATA` longblob,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `qrtz_triggers` */

/*Table structure for table `resteasy_authorization` */

DROP TABLE IF EXISTS `resteasy_authorization`;

CREATE TABLE `resteasy_authorization` (
  `ID` varchar(50) NOT NULL COMMENT '主键唯一',
  `RESOURCES_ID` varchar(50) DEFAULT NULL COMMENT '资源表主键',
  `SYSTEM_ID` varchar(50) DEFAULT NULL COMMENT '系统表主键',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `resteasy_authorization` */

/*Table structure for table `resteasy_org` */

DROP TABLE IF EXISTS `resteasy_org`;

CREATE TABLE `resteasy_org` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `ORG_NAME` varchar(100) DEFAULT NULL COMMENT '组织机构名称',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `resteasy_org` */

insert  into `resteasy_org` values ('402809814a801f6b014a801f84a70001','金航数码');

/*Table structure for table `resteasy_resources` */

DROP TABLE IF EXISTS `resteasy_resources`;

CREATE TABLE `resteasy_resources` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `REST_URL` varchar(200) DEFAULT NULL COMMENT '服务URL访问地址',
  `STATUS` varchar(2) DEFAULT NULL COMMENT '服务状态  1可用 0不可用',
  `URL_DESC` text COMMENT '服务描述',
  `SYSTEM_ID` varchar(50) DEFAULT NULL COMMENT '服务所属系统',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `resteasy_resources` */

/*Table structure for table `resteasy_system` */

DROP TABLE IF EXISTS `resteasy_system`;

CREATE TABLE `resteasy_system` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `ORG_ID` varchar(50) DEFAULT NULL COMMENT '所属组织机构',
  `SYSTEM_NAME` varchar(100) DEFAULT NULL COMMENT '系统名称',
  `SYSTEM_DESC` text COMMENT '系统描述',
  `STATUS` varchar(2) DEFAULT NULL COMMENT '状态  1可用 0不可用',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `resteasy_system` */

insert  into `resteasy_system` values ('402809814a801f6b014a801fec5e0004','402809814a801f6b014a801f84a70001','业务基础平台前端',NULL,'1');

/*Table structure for table `resteasy_user` */

DROP TABLE IF EXISTS `resteasy_user`;

CREATE TABLE `resteasy_user` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `USER_NAME` varchar(50) DEFAULT NULL COMMENT '用户名称',
  `USER_PASSWORD` varchar(50) DEFAULT NULL COMMENT '用户密码',
  `BASE_KEY` varchar(100) DEFAULT NULL COMMENT '用户秘钥   由名称和密码MD5计算',
  `STATUS` varchar(2) DEFAULT NULL COMMENT '状态  1可用  0不可用',
  `SYSTEM_ID` varchar(50) DEFAULT NULL COMMENT '所属系统',
  `TYPE` varchar(2) DEFAULT NULL COMMENT '用户类型   1系统间调用   0平台自己调用',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `resteasy_user` */

insert  into `resteasy_user` values ('402809814a9a55a0014a9a55a0dc0000','avicit2015','avicit2015','AEF56B8AE355963D6D75CD8CE4CB950F','1','402809814a801f6b014a801fec5e0004','0');

/*Table structure for table `search_connection` */

DROP TABLE IF EXISTS `search_connection`;

CREATE TABLE `search_connection` (
  `ID` varchar(50) NOT NULL,
  `CONNECTION_URL` varchar(100) DEFAULT NULL,
  `CONNECTION_USERNAME` varchar(100) DEFAULT NULL,
  `CONNECTION_PASSWORD` varchar(100) DEFAULT NULL,
  `CONNECTION_DRIVER` varchar(100) DEFAULT NULL,
  `CONNECTION_NAME` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `search_connection` */

/*Table structure for table `search_datasources` */

DROP TABLE IF EXISTS `search_datasources`;

CREATE TABLE `search_datasources` (
  `ID` varchar(50) NOT NULL,
  `DATASOURCE_NAME` varchar(50) DEFAULT NULL,
  `DISPLAY_NAME` varchar(50) DEFAULT NULL,
  `STATUS` varchar(2) DEFAULT NULL,
  `DATASOURCE_DESC` text,
  `DISPLAY_URL` text,
  `SQL_STATEMENT` text,
  `DOC_PATH` text,
  `TYPE` varchar(2) DEFAULT NULL,
  `CONNECTION_FK` varchar(50) DEFAULT NULL,
  `SYSROLE_FK` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `search_datasources` */

/*Table structure for table `search_details` */

DROP TABLE IF EXISTS `search_details`;

CREATE TABLE `search_details` (
  `ID` varchar(50) NOT NULL,
  `MAINDATA_ID` varchar(50) DEFAULT NULL,
  `COLUMN_NAME` varchar(50) DEFAULT NULL,
  `STORED` varchar(2) DEFAULT NULL,
  `INDEXED` varchar(2) DEFAULT NULL,
  `BELONG` varchar(2) DEFAULT NULL,
  `SECRETED` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `search_details` */

/*Table structure for table `sys_accesscontrol` */

DROP TABLE IF EXISTS `sys_accesscontrol`;

CREATE TABLE `sys_accesscontrol` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `TARGET_TYPE` varchar(50) NOT NULL COMMENT '设置权限设置的目标，可能的类型有：部门(DEPT)、角色(ROLE)、群组(GROUP)、岗位(POS)、用户(USER)\r\nTARGET_TYPE字段与TARGET_ID字段联合使用，当TARGET_TYPE存储不同的值时，TARGET_ID存储响应的类型的ID值。\r\n类型优先级如下：用户(USER) > 角色(ROLE) > 部门(DEPT) > 岗位(POS) > 群组(GROUP) > ',
  `TARGET_ID` varchar(100) NOT NULL COMMENT '根据TARGET_TYPE的不同的值存储不同的内容，具体内容如下：\r\nTARGET_TYPE的值， TARGET_ID存储的值\r\nROLE              ROLE_ID\r\nDEPT             DEPT_ID\r\n等等',
  `RESOURE_ID` text NOT NULL COMMENT '资源ID,  引用资源表的ID',
  `ACCESSIBILITY` decimal(1,0) NOT NULL COMMENT '可访问性，用来表示一个资源是否可以访问的属性，\r\n对于菜单来说，代表该菜单是否可以访问\r\n\r\n对于URL来说，代表是否可以访问该URL\r\n\r\n对于按钮来说，代表是否显隐\r\n对于表单列和表格列来说，代表是否显隐\r\n\r\n1-允许访问\r\n0-禁止访问',
  `OPERABILITY` decimal(1,0) NOT NULL COMMENT '可操作性，用来表示一个资源是否可以操作的属性，\r\n对于菜单和URL来说，没有可操作性的属性\r\n对于按钮来说，可操作性是指按钮是否可以点击\r\n对于表单列和表格列来说，可操作性是指是否可以更改其中的数据\r\n\r\n1-允许操作\r\n0-禁止操作',
  `SYS_APPLICATION_ID` varchar(50) NOT NULL COMMENT '应用ID，适用于多应用情况',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='资源权限控制表，存储权限设置\r\n';

/*Data for the table `sys_accesscontrol` */

insert  into `sys_accesscontrol` values ('8a58ab3d4c91a4c8014c91f305f70009','R','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c276a3f014c276f9f1a0027','1','1','1','2015-05-16 08:22:26','1','2015-04-07 11:36:05','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58ab3d4c91a4c8014c91f30662000b','R','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c276a3f014c276bcc2d0008','1','1','1','2016-03-14 10:56:06','1','2015-04-07 11:36:05','1','127.0.0.1','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58ab3d4c91a4c8014c91f30695000d','R','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c276a3f014c276b708c0003','1','1','1','2016-03-14 10:56:06','1','2015-04-07 11:36:05','1','127.0.0.1','7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57504b2a3201504b2b34e10049','R','8a58ab5f4be29ef7014be2d442bd01ab','8a58cd575016ab70015016af29f60052','1','1','1','2015-10-09 13:55:34','1','2015-10-09 13:55:34','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd575373003801537304a5ba005c','R','8a58ab4d4c207cca014c207ffff7034c','8a58cd57535417350153543765620072','1','1','1','2016-03-14 10:46:37','1','2016-03-14 10:46:37','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd5753730038015373072a4900b6','R','8a58ab4d4c207cca014c207ffff7034c','8a58cd57504b2a3201504b2b74190097','1','1','1','2016-03-14 10:49:22','1','2016-03-14 10:49:22','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57537300380153730732c900b7','R','8a58ab4d4c207cca014c207ffff7034c','8a58cd57504b2a3201504b2b7419009e','1','1','1','2016-03-14 10:49:24','1','2016-03-14 10:49:24','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd575373003801537307365e00b8','R','8a58ab4d4c207cca014c207ffff7034c','8a58cd57504b2a3201504b2b74190096','1','1','1','2016-03-14 10:49:25','1','2016-03-14 10:49:25','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd5753730038015373073d2a00b9','R','8a58ab4d4c207cca014c207ffff7034c','8a58cd57504b2a3201504b2b7419009c','1','1','1','2016-03-14 10:49:27','1','2016-03-14 10:49:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd5753730038015373074a1700be','R','8a58ab4d4c207cca014c207ffff7034c','8a58cd57504b2a3201504b2b7419009b','1','1','1','2016-03-14 10:49:30','1','2016-03-14 10:49:30','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd5753730038015373075ba900bf','R','8a58ab4d4c207cca014c207ffff7034c','8a58cd57504b2a3201504b2b74190099','1','1','1','2016-03-14 10:49:35','1','2016-03-14 10:49:35','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57537300380153730794c200c2','R','40288a46384feb2101384fef8ba80005','8a58a6b44c276a3f014c276f9f1a0027','1','1','1','2016-03-14 10:49:50','1','2016-03-14 10:49:50','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd575373003801537307a32a00c3','R','40288a46384feb2101384fef8ba80005','8a58cd57504b2a3201504b2b74190098','1','1','1','2016-03-14 10:49:53','1','2016-03-14 10:49:53','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd575373003801537307cb9b00c8','R','8a58ab4d4c207cca014c207ffff7034c','8a58cd57504b2a3201504b2b7419009a','1','1','1','2016-03-14 10:50:04','1','2016-03-14 10:50:04','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57537300380153730846e400cc','R','40288a46384feb2101384fef8ba80005','8a58cd57504b2a3201504b2b94fa00ae','1','1','1','2016-03-14 10:50:35','1','2016-03-14 10:50:35','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd5753730038015373085df400d6','R','40288a46384feb2101384fef8ba80005','8a58cd57504b2a3201504b2b94fa00af','1','1','1','2016-03-14 10:50:41','1','2016-03-14 10:50:41','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57537300380153730d530d01a3','R','8a58ab4d4c207cca014c207ffff7034c','8a58c8434d468f93014d4699721b0017','1','1','1','2016-03-14 10:56:06','1','2016-03-14 10:56:06','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57537300380153730d5ff401a4','R','8a58ab4d4c207cca014c207ffff7034c','8a58cd57504b2a3201504b2b94fa00aa','1','1','1','2016-03-14 10:56:09','1','2016-03-14 10:56:09','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57537300380153730d649001a9','R','8a58ab4d4c207cca014c207ffff7034c','8a58cd57504b2a3201504b2b94fa00ad','1','1','1','2016-03-14 10:56:10','1','2016-03-14 10:56:10','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57537300380153730d688b01aa','R','8a58ab4d4c207cca014c207ffff7034c','8a58cd57504b2a3201504b2b94fa00a9','1','1','1','2016-03-14 10:56:11','1','2016-03-14 10:56:11','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57537300380153730d7e0201ab','R','8a58ab4d4c207cca014c207ffff7034c','8a58cd57504b2a3201504b2b94fa00ab','1','1','1','2016-03-14 10:56:17','1','2016-03-14 10:56:17','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57537300380153730d84a201ac','R','8a58ab4d4c207cca014c207ffff7034c','8a58cd57504b2a3201504b2b94fa00a8','1','1','1','2016-03-14 10:56:19','1','2016-03-14 10:56:19','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57537300380153730d8ea601b1','R','8a58ab4d4c207cca014c207ffff7034c','8a58cd57504b2a3201504b2b94fa00b0','1','1','1','2016-03-14 10:56:21','1','2016-03-14 10:56:21','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57537300380153731479e30228','R','40288a46384feb2101384fef8ba80005','8a58cd57504b2a3201504b2b74190097','1','1','1','2016-03-14 11:03:55','1','2016-03-14 11:03:55','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a197814000e','R','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c275bab014c27648454002c','1','1','1','2015-05-16 08:22:08','1','2015-05-16 08:22:08','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c1450011','R','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c276a3f014c276e44d00018','1','1','1','2015-05-16 08:22:26','1','2015-05-16 08:22:26','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c15f0013','R','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c276a3f014c276ea970001d','1','1','1','2015-05-16 08:22:26','1','2015-05-16 08:22:26','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c16e0015','R','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c276a3f014c276f21ee0022','1','1','1','2015-05-16 08:22:26','1','2015-05-16 08:22:26','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c1970018','R','8a58ab4d4c207cca014c207ffff7034c','8a58c8434d468f93014d4696701d0009','1','1','1','2015-05-16 08:22:26','1','2015-05-16 08:22:26','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c1ab001a','R','8a58ab4d4c207cca014c207ffff7034c','8a58c8434d468f93014d4698ca290012','1','1','1','2015-05-16 08:22:26','1','2015-05-16 08:22:26','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c22c0029','R','8a58ab4d4c207cca014c207ffff7034c','8a58c8434d468f93014d469d824e0026','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c23a002b','R','8a58ab4d4c207cca014c207ffff7034c','8a58c8434d468f93014d46a40e83003b','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c249002d','R','8a58ab4d4c207cca014c207ffff7034c','8a58c8434d468f93014d46a4bdf50040','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c25b002f','R','8a58ab4d4c207cca014c207ffff7034c','8a58c8434d468f93014d46a533990045','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c26b0031','R','8a58ab4d4c207cca014c207ffff7034c','8a58c8434d468f93014d46a5ae9a004a','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c27a0033','R','8a58ab4d4c207cca014c207ffff7034c','8a58c8434d468f93014d46a62877004f','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c28c0035','R','8a58ab4d4c207cca014c207ffff7034c','8a58c8434d468f93014d46a6a33c0054','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c29c0037','R','8a58ab4d4c207cca014c207ffff7034c','8a58c8434d468f93014d46a71c050059','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c2ac0039','R','8a58ab4d4c207cca014c207ffff7034c','8a58c8434d468f93014d46a7b7c2005e','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c2bd003b','R','8a58ab4d4c207cca014c207ffff7034c','8a58c8434d468f93014d469b1dca001c','1','1','1','2016-03-14 10:46:37','1','2015-05-16 08:22:27','1','127.0.0.1','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c2cc003d','R','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c276a3f014c2a692d0800a0','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c2db003f','R','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c276a3f014c2a69888500a5','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c2ee0041','R','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c276a3f014c2a69e00100aa','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c3030043','R','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c276a3f014c2a6ac60200af','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c3150045','R','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c276a3f014c2a6b0c9500b4','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c3230047','R','8a58ab4d4c207cca014c207ffff7034c','8a58c8434d468f93014d46b7c03f00c8','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c3310049','R','8a58ab4d4c207cca014c207ffff7034c','8a58c8434d468f93014d46b85ae600cd','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c33f004b','R','8a58ab4d4c207cca014c207ffff7034c','8a58c8434d468f93014d46b8ce1d00d2','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c34d004d','R','8a58ab4d4c207cca014c207ffff7034c','8a58c8434d468f93014d46b92d0800d7','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c35d004f','R','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c276a3f014c2a66d819009b','1','1','1','2015-09-28 15:22:42','1','2015-05-16 08:22:27','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c3bb005b','R','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c276a3f014c2a7433c200e3','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c3cb005d','R','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c276a3f014c2a750edf00ee','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c3db005f','R','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c276a3f014c2a76550f00fd','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c3ea0061','R','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c276a3f014c2a76a9a90102','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c3f90063','R','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c276a3f014c2a73dfb700de','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c4080065','R','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c276a3f014c2a7f2b2f010f','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c4170067','R','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c276a3f014c2a7fb1100117','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c4260069','R','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c276a3f014c2a7e187b0107','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c437006b','R','8a58ab4d4c207cca014c207ffff7034c','8a58ab574c7d0e6c014c7d103ec70004','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a19c448006d','R','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c276a3f014c2a5b2a320040','1','1','1','2015-05-16 08:22:27','1','2015-05-16 08:22:27','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a2b598002ec','R','40288a46384feb2101384fef8ba80005','8a58a6b44c276a3f014c2a5f00fc0057','1','1','1','2015-05-16 08:41:39','1','2015-05-16 08:41:39','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a2b6aa402ee','R','40288a46384feb2101384fef8ba80005','8a58a6b44c276a3f014c2a6076d10061','1','1','1','2015-05-16 08:41:44','1','2015-05-16 08:41:44','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a2b6ac002f0','R','40288a46384feb2101384fef8ba80005','8a58a6b44c276a3f014c2a616bc70066','1','1','1','2015-05-16 08:41:44','1','2015-05-16 08:41:44','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a2b6ad802f2','R','40288a46384feb2101384fef8ba80005','8a58c8434d468f93014d46aa7ba90072','1','1','1','2015-05-16 08:41:44','1','2015-05-16 08:41:44','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a2b6ae702f4','R','40288a46384feb2101384fef8ba80005','8a58c8434d468f93014d46ab685b0080','1','1','1','2015-05-16 08:41:44','1','2015-05-16 08:41:44','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a2b9dc002f6','R','40288a46384feb2101384fef8ba80005','8a58a6b44c276a3f014c2a63ee62007a','1','1','1','2015-05-16 08:41:57','1','2015-05-16 08:41:57','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a2bbce202f8','R','40288a46384feb2101384fef8ba80005','8a58a6b44c276a3f014c2a645456007f','1','1','1','2015-05-16 08:42:05','1','2015-05-16 08:42:05','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a2bbd2002fc','R','40288a46384feb2101384fef8ba80005','8a58a6b44c276a3f014c2a652dd80089','1','1','1','2015-05-16 08:42:05','1','2015-05-16 08:42:05','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a2bbd2f02fe','R','40288a46384feb2101384fef8ba80005','8a58a6b44c276a3f014c2a6579c6008e','1','1','1','2015-05-16 08:42:05','1','2015-05-16 08:42:05','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a2bddd70300','R','40288a46384feb2101384fef8ba80005','8a58ab574c7d0e6c014c7d103ec70004','1','1','1','2015-05-16 08:42:13','1','2015-05-16 08:42:13','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a2bde1a0302','R','40288a46384feb2101384fef8ba80005','8a58a6b44c276a3f014c276b708c0003','1','1','1','2016-03-14 10:49:50','1','2015-05-16 08:42:13','1','127.0.0.1','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a2bf2de0304','R','40288a46384feb2101384fef8ba80005','8a58a6b44c276a3f014c2a5b2a320040','1','1','1','2015-05-16 08:42:19','1','2015-05-16 08:42:19','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a30263f043b','R','40288a46384feb2101384ff0efc20006','8a58a6b44c275bab014c27648454002c','1','1','1','2015-05-16 08:46:54','1','2015-05-16 08:46:54','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a305b29043d','R','40288a46384feb2101384ff0efc20006','8a58a6b44c276a3f014c2a645456007f','1','1','1','2015-05-16 08:47:08','1','2015-05-16 08:47:08','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a305b5b043f','R','40288a46384feb2101384ff0efc20006','8a58a6b44c276a3f014c2a63ee62007a','1','1','1','2015-05-16 08:47:08','1','2015-05-16 08:47:08','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a305b900441','R','40288a46384feb2101384ff0efc20006','8a58a6b44c276a3f014c276b708c0003','1','1','1','2015-05-16 08:47:14','1','2015-05-16 08:47:08','1','127.0.0.1','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a3069310443','R','40288a46384feb2101384ff0efc20006','8a58ab574c7d0e6c014c7d103ec70004','1','1','1','2015-05-16 08:47:11','1','2015-05-16 08:47:11','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a0f38014d5a3072550446','R','40288a46384feb2101384ff0efc20006','8a58a6b44c276a3f014c2a5b2a320040','1','1','1','2015-05-16 08:47:14','1','2015-05-16 08:47:14','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a32f6014d5a34e6810042','R','40288a46384feb2101384fef8ba80005','8a58a6b44c275bab014c27648454002c','1','1','1','2015-05-16 08:52:05','1','2015-05-16 08:52:05','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a32f6014d5a3604a80089','R','8a58ab5f4be29ef7014be2d442bd01ab','8a58a6b44c275bab014c2762df17001d','1','1','1','2015-05-16 08:53:19','1','2015-05-16 08:53:19','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a32f6014d5a3604b8008b','R','8a58ab5f4be29ef7014be2d442bd01ab','8a58a6b44c275bab014c275fdd42000e','1','1','1','2015-05-16 08:53:19','1','2015-05-16 08:53:19','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a32f6014d5a3604c8008d','R','8a58ab5f4be29ef7014be2d442bd01ab','8a58a6b44c275bab014c27648454002c','1','1','1','2015-05-16 08:53:19','1','2015-05-16 08:53:19','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a32f6014d5a3604d7008f','R','8a58ab5f4be29ef7014be2d442bd01ab','8a58a6b44c275bab014c2767bd9c003b','1','1','1','2015-05-16 08:53:19','1','2015-05-16 08:53:19','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a32f6014d5a3604e50091','R','8a58ab5f4be29ef7014be2d442bd01ab','8a58a6b44c275bab014c27675b0c0036','1','1','1','2015-05-16 08:53:19','1','2015-05-16 08:53:19','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a32f6014d5a3604f50093','R','8a58ab5f4be29ef7014be2d442bd01ab','8a58a6b44c275bab014c2768570b0040','1','1','1','2015-05-16 08:53:19','1','2015-05-16 08:53:19','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5a32f6014d5a3605030095','R','8a58ab5f4be29ef7014be2d442bd01ab','8a58a6b44c275bab014c2765ee040031','1','1','1','2015-10-09 13:55:34','1','2015-05-16 08:53:19','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5bb00f014d5bb5b3600058','R','8a58ab5f4be29ef7014be2d442bd01ab','8a58ab574c7d0e6c014c7d103ec70004','1','1','1','2015-05-16 15:52:24','1','2015-05-16 15:52:24','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604d5bb00f014d5bb5bc30005c','R','8a58ab5f4be29ef7014be2d442bd01ab','8a58a6b44c276a3f014c2a5b2a320040','1','1','1','2015-05-16 15:52:26','1','2015-05-16 15:52:26','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd605012d184015012d4aae3004d','R','8a58ab4d4c207cca014c207ffff7034c','8a58cd434fb53c16014fb53f01a5004d','1','1','1','2015-09-28 15:22:18','1','2015-09-28 15:22:18','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd605012d184015012d4c5310051','R','8a58ab4d4c207cca014c207ffff7034c','402809814f2a5144014f2ab7c74d0050','1','1','1','2015-09-28 15:22:25','1','2015-09-28 15:22:25','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd605012d184015012d4d1850052','R','8a58ab4d4c207cca014c207ffff7034c','402809814f2a5144014f2ab893490055','1','1','1','2015-09-28 15:22:28','1','2015-09-28 15:22:28','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd605012d184015012d508240059','R','8a58ab4d4c207cca014c207ffff7034c','8a58cd604e7156df014e71749f67010c','1','1','1','2015-09-28 15:22:42','1','2015-09-28 15:22:42','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd605012d184015012d5dc4c00a8','R','40288a46384feb2101384fef8ba80005','8a58c8434d468f93014d4699721b0017','1','1','1','2015-09-28 15:23:36','1','2015-09-28 15:23:36','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd605012d184015012d5dc8400a9','R','40288a46384feb2101384fef8ba80005','8a58a6b44c276a3f014c276bcc2d0008','1','1','1','2016-03-14 10:49:50','1','2015-09-28 15:23:36','1','127.0.0.1','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

/*Table structure for table `sys_app_role` */

DROP TABLE IF EXISTS `sys_app_role`;

CREATE TABLE `sys_app_role` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `SYSAPP_ID` varchar(50) NOT NULL COMMENT '应用id',
  `SYSROLE_ID` varchar(50) NOT NULL COMMENT '角色id',
  `SYSAPP_NAME` varchar(250) DEFAULT NULL COMMENT '应用名称',
  `SYSROLE_NAME` varchar(250) DEFAULT NULL COMMENT '角色名称',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用角色关系表';

/*Data for the table `sys_app_role` */

/*Table structure for table `sys_application` */

DROP TABLE IF EXISTS `sys_application`;

CREATE TABLE `sys_application` (
  `ID` varchar(50) NOT NULL COMMENT '唯一标识',
  `APPLICATION_NAME` varchar(100) DEFAULT NULL COMMENT '应用名称',
  `APPLICATION_CODE` varchar(50) DEFAULT NULL COMMENT '应用代码',
  `BASEPATH` varchar(100) DEFAULT NULL COMMENT '应用调用路径',
  `RUN_STATE` varchar(1) DEFAULT NULL COMMENT '运行状态\r\n1：run ;0:stop；default:0',
  `DESCRIPTION` varchar(240) DEFAULT NULL COMMENT '应用描述',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ORDER_BY` decimal(16,0) DEFAULT NULL COMMENT '排序',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='多应用配置表';

/*Data for the table `sys_application` */

insert  into `sys_application` values ('1','默认应用程序','platform','/p6','1','基于业务基础平台的应用','2015-04-07 11:37:34','1','2012-07-07 17:13:05','1','127.0.0.1','10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0');

/*Table structure for table `sys_attachment` */

DROP TABLE IF EXISTS `sys_attachment`;

CREATE TABLE `sys_attachment` (
  `ID` varchar(50) NOT NULL,
  `ATTACH_NAME` varchar(200) NOT NULL,
  `PARENT_TABLE_ID` varchar(50) DEFAULT NULL,
  `PARENT_REGISTER_ID` varchar(50) NOT NULL,
  `ATTACH_BLOB` longblob,
  `ATTACH_TYPE` varchar(10) DEFAULT NULL,
  `ATTACH_SIZE` decimal(20,0) DEFAULT NULL,
  `LAST_UPDATE_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` varchar(32) DEFAULT NULL,
  `LAST_UPDATE_IP` varchar(20) DEFAULT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `CREATED_BY` varchar(32) DEFAULT NULL,
  `VERSION` decimal(16,0) DEFAULT NULL,
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT 'groupName',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT 'remoteFlieName',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL,
  `UPLOAD_PATH` text,
  `PARENT_TABLE_FIELD` varchar(100) DEFAULT NULL COMMENT '附件所关联字段名称',
  `ATTACH_CATEGORY` varchar(32) DEFAULT NULL,
  `SECRET_LEVEL` varchar(32) DEFAULT NULL,
  `FASTDFS_LOCATION` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sys_attachment` */

/*Table structure for table `sys_bpm_hist_procinst` */

DROP TABLE IF EXISTS `sys_bpm_hist_procinst`;

CREATE TABLE `sys_bpm_hist_procinst` (
  `DBID_` varchar(50) NOT NULL,
  `ID_` varchar(255) DEFAULT NULL,
  `PROCDEFID_` varchar(255) DEFAULT NULL,
  `START_` datetime DEFAULT NULL,
  `END_` datetime DEFAULT NULL,
  `STATE_` varchar(255) DEFAULT NULL,
  `FORMID_` varchar(50) DEFAULT NULL,
  `TITLE_` varchar(255) DEFAULT NULL,
  `USERID_` varchar(255) DEFAULT NULL,
  `DEPTID_` varchar(255) DEFAULT NULL,
  `BUSINESSSTATE_` varchar(255) DEFAULT NULL,
  `ACTIVITYALIAS_` text,
  `LAST_UPDATE_DATE_` datetime DEFAULT NULL,
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sys_bpm_hist_procinst` */

/*Table structure for table `sys_bpm_hist_task` */

DROP TABLE IF EXISTS `sys_bpm_hist_task`;

CREATE TABLE `sys_bpm_hist_task` (
  `DBID_` varchar(50) NOT NULL,
  `EXECUTION_` varchar(255) DEFAULT NULL,
  `OUTCOME_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_` varchar(255) DEFAULT NULL,
  `STATE_` varchar(255) DEFAULT NULL,
  `CREATE_` datetime DEFAULT NULL,
  `END_` datetime DEFAULT NULL,
  `TASK_ORDER_` varchar(255) DEFAULT NULL,
  `OPEN_` datetime DEFAULT NULL,
  `TAKE_STATE_` varchar(255) DEFAULT NULL,
  `PROCINST_` varchar(50) DEFAULT NULL,
  `TASK_TYPE_` varchar(255) DEFAULT NULL,
  `TASK_B_ID_` varchar(255) DEFAULT NULL,
  `TASK_TITLE_` varchar(255) DEFAULT NULL,
  `TASK_SENDUSER_` varchar(255) DEFAULT NULL,
  `TASK_SENDDEPT_` varchar(255) DEFAULT NULL,
  `FORM_` varchar(255) DEFAULT NULL,
  `PROCESS_DEF_NAME_` varchar(255) DEFAULT NULL,
  `TASK_FINISHED_` varchar(255) DEFAULT NULL,
  `TASK_STATE_` varchar(255) DEFAULT NULL,
  `TASK_NAME_` varchar(255) DEFAULT NULL,
  `HISACTINST_` varchar(50) DEFAULT NULL,
  `WORKHAND_TYPE_` varchar(255) DEFAULT NULL,
  `WORKHAND_USER_` varchar(255) DEFAULT NULL,
  `APP_ID_` varchar(255) DEFAULT NULL,
  `ASSIGNEE_DEPT_` varchar(255) DEFAULT NULL,
  `LAST_UPDATE_DATE_` datetime DEFAULT NULL,
  PRIMARY KEY (`DBID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sys_bpm_hist_task` */

/*Table structure for table `sys_coding_com_segment` */

DROP TABLE IF EXISTS `sys_coding_com_segment`;

CREATE TABLE `sys_coding_com_segment` (
  `ID` varchar(32) NOT NULL COMMENT 'ID',
  `SYS_APPLICATION_ID` varchar(50) NOT NULL COMMENT '应用ID',
  `SEGMENT_NAME` varchar(200) NOT NULL COMMENT '码段名称',
  `SEGMENT_LENGTH` decimal(2,0) DEFAULT NULL COMMENT '码段长度',
  `SEGMENT_REMARK` text COMMENT '码段说明',
  `CREATED_BY` varchar(32) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` varchar(32) NOT NULL,
  `LAST_UPDATE_DATE` datetime NOT NULL,
  `LAST_UPDATE_IP` varchar(20) NOT NULL,
  `VERSION` decimal(16,0) NOT NULL,
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='自编代码规则-通用码段表';

/*Data for the table `sys_coding_com_segment` */

/*Table structure for table `sys_coding_com_segment_values` */

DROP TABLE IF EXISTS `sys_coding_com_segment_values`;

CREATE TABLE `sys_coding_com_segment_values` (
  `ID` varchar(32) NOT NULL,
  `SEGMENT_ID` varchar(32) NOT NULL COMMENT '通用码段ID',
  `SEGMENT_NAME` varchar(200) NOT NULL COMMENT '码名称',
  `SEGMENT_VALUE` varchar(200) NOT NULL COMMENT '码值',
  `CREATED_BY` varchar(32) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` varchar(32) NOT NULL,
  `LAST_UPDATE_DATE` datetime NOT NULL,
  `LAST_UPDATE_IP` varchar(20) NOT NULL,
  `VERSION` decimal(16,0) NOT NULL,
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='自编代码规则-通用码段码值表';

/*Data for the table `sys_coding_com_segment_values` */

/*Table structure for table `sys_coding_rule_base` */

DROP TABLE IF EXISTS `sys_coding_rule_base`;

CREATE TABLE `sys_coding_rule_base` (
  `ID` varchar(32) NOT NULL COMMENT '主键',
  `SYS_APPLICATION_ID` varchar(50) NOT NULL COMMENT '应用ID',
  `CODING_NAME` varchar(200) NOT NULL COMMENT '规则名称',
  `SEGMENT_NUMBER` decimal(2,0) NOT NULL COMMENT '码段个数',
  `STATUS` varchar(10) NOT NULL COMMENT '状态(通用代码：MDM_CODING_SEGMENT_STATUS)',
  `RULE_REMARK` text COMMENT '说明',
  `CREATED_BY` varchar(32) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` varchar(32) NOT NULL,
  `LAST_UPDATE_DATE` datetime NOT NULL,
  `LAST_UPDATE_IP` varchar(20) NOT NULL,
  `VERSION` decimal(16,0) NOT NULL,
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL,
  `CODING_CODE` varchar(50) NOT NULL COMMENT '规则编号',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='自编代码规则-基本设置表';

/*Data for the table `sys_coding_rule_base` */

/*Table structure for table `sys_coding_rule_segment` */

DROP TABLE IF EXISTS `sys_coding_rule_segment`;

CREATE TABLE `sys_coding_rule_segment` (
  `ID` varchar(32) NOT NULL COMMENT '主键',
  `BASE_ID` varchar(32) NOT NULL COMMENT '基本设置ID',
  `SEGMENT_INDEX` decimal(2,0) NOT NULL COMMENT '码段号',
  `SEGMENT_NAME` varchar(200) NOT NULL COMMENT '码段名称',
  `SEGMENT_TYPE` varchar(10) NOT NULL COMMENT '码段类型',
  `SEGMENT_LENGTH` decimal(2,0) DEFAULT NULL COMMENT '码段长度',
  `SEGMENT_PREFIXION` varchar(200) DEFAULT NULL COMMENT '前缀',
  `SEGMENT_RELATION` text COMMENT '分类码值关联',
  `SERIAL_NUMBER_START` decimal(16,0) DEFAULT NULL COMMENT '流水号开始',
  `SERIAL_NUMBER_END` decimal(16,0) DEFAULT NULL COMMENT '流水号结束',
  `SERIAL_STEP` decimal(16,0) DEFAULT NULL COMMENT '流水步长',
  `FORMAT` varchar(200) DEFAULT NULL COMMENT '格式',
  `COM_SEGMENT_ID` varchar(32) DEFAULT NULL COMMENT '通用码段ID',
  `CREATED_BY` varchar(32) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` varchar(32) NOT NULL,
  `LAST_UPDATE_DATE` datetime NOT NULL,
  `LAST_UPDATE_IP` varchar(20) NOT NULL,
  `VERSION` decimal(16,0) NOT NULL,
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL,
  `SEGMENT_SUFFIX` varchar(200) DEFAULT NULL COMMENT '后缀',
  `IS_CURRENT_TIME` varchar(1) DEFAULT NULL COMMENT '是否默认当前时间,Y表示是，N表示否',
  `IS_INPUT_SERIAL` varchar(1) DEFAULT NULL COMMENT '是否可以直接输入流水号,Y表示是，N表示否',
  `FUNC` varchar(200) DEFAULT NULL COMMENT '函数全路径',
  `SQL_EXPRESSION` text COMMENT 'SQL语句',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='自编代码规则-码段属性表';

/*Data for the table `sys_coding_rule_segment` */

/*Table structure for table `sys_coding_rule_segment_values` */

DROP TABLE IF EXISTS `sys_coding_rule_segment_values`;

CREATE TABLE `sys_coding_rule_segment_values` (
  `ID` varchar(32) NOT NULL COMMENT '主键',
  `BASE_ID` varchar(32) NOT NULL COMMENT '基本设置ID',
  `SEGMENT_INDEX` decimal(2,0) NOT NULL COMMENT '码段号',
  `SEGMENT_NAME` varchar(200) DEFAULT NULL COMMENT '码名称',
  `SEGMENT_VALUE` varchar(200) NOT NULL COMMENT '码值',
  `DEPEND_VALUES` text COMMENT '依赖值(null表示没有依赖关系)',
  `COM_SEGMENT_VALUE_ID` varchar(32) DEFAULT NULL COMMENT '通用码值ID',
  `CREATED_BY` varchar(32) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` varchar(32) NOT NULL,
  `LAST_UPDATE_DATE` datetime NOT NULL,
  `LAST_UPDATE_IP` varchar(20) NOT NULL,
  `VERSION` decimal(16,0) NOT NULL,
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='自编代码规则-码值表';

/*Data for the table `sys_coding_rule_segment_values` */

/*Table structure for table `sys_coding_rule_serial` */

DROP TABLE IF EXISTS `sys_coding_rule_serial`;

CREATE TABLE `sys_coding_rule_serial` (
  `ID` varchar(32) NOT NULL COMMENT '主键',
  `BASE_ID` varchar(32) NOT NULL COMMENT '基本设置ID',
  `SEGMENT_INDEX` decimal(2,0) NOT NULL COMMENT '码段号',
  `DEPEND_VALUES` text COMMENT '依赖值',
  `MAX_SERIAL` decimal(16,0) NOT NULL COMMENT '最大流水号',
  `CREATED_BY` varchar(32) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` varchar(32) NOT NULL,
  `LAST_UPDATE_DATE` datetime NOT NULL,
  `LAST_UPDATE_IP` varchar(20) NOT NULL,
  `VERSION` decimal(16,0) NOT NULL,
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='自编代码规则-流水号表';

/*Data for the table `sys_coding_rule_serial` */

/*Table structure for table `sys_coding_used_info` */

DROP TABLE IF EXISTS `sys_coding_used_info`;

CREATE TABLE `sys_coding_used_info` (
  `ID` varchar(32) NOT NULL COMMENT '主键',
  `CODING_ID` varchar(32) NOT NULL COMMENT '对应Table MDM_CODING_RULE_BASE表的ID',
  `CODING_VALUE` text NOT NULL COMMENT '编码值',
  `MODULE_NAME` text NOT NULL COMMENT '模块名称',
  `CREATED_BY` varchar(32) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` varchar(32) NOT NULL,
  `LAST_UPDATE_DATE` datetime NOT NULL,
  `LAST_UPDATE_IP` varchar(20) NOT NULL,
  `VERSION` decimal(16,0) NOT NULL,
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL,
  `FORM_ID` varchar(50) DEFAULT NULL COMMENT '业务数据ID',
  `USED_SERIAL` decimal(16,0) DEFAULT NULL COMMENT '使用的流水号',
  `USED_SERIAL_DEPEND` text COMMENT '使用的流水号的依赖值',
  `IS_DELETED` varchar(1) DEFAULT NULL COMMENT '是否已删除，Y表示已删除',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='编码使用情况表';

/*Data for the table `sys_coding_used_info` */

/*Table structure for table `sys_customed` */

DROP TABLE IF EXISTS `sys_customed`;

CREATE TABLE `sys_customed` (
  `ID` varchar(50) NOT NULL COMMENT '唯一标识',
  `ORG_ID` varchar(50) DEFAULT NULL COMMENT '组织ID',
  `USER_ID` varchar(50) DEFAULT NULL COMMENT '用户ID',
  `KEY` varchar(50) DEFAULT NULL COMMENT '惯用设置选项代码',
  `VALUE` text COMMENT '惯用设置选项值',
  `IS_MULTI` varchar(1) DEFAULT NULL COMMENT '是否是多值  1 代表多值  0代表单值',
  `IS_DEFAULT` varchar(1) DEFAULT NULL COMMENT '是否是默认  1 默认     ',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `SYS_APP_ID` varchar(50) NOT NULL COMMENT '所属应用id',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='惯用设置表';

/*Data for the table `sys_customed` */

insert  into `sys_customed` values ('4028098153e4321f0153e43612150063','8a58ab4d4c2141fd014c217c436a02b2','1','PLATFORM_USER_SKIN','azure','0','1','2016-04-05 10:17:51','1','2016-04-05 10:17:42','1','127.0.0.1','3','1');

/*Table structure for table `sys_dept` */

DROP TABLE IF EXISTS `sys_dept`;

CREATE TABLE `sys_dept` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `DEPT_CODE` varchar(100) NOT NULL COMMENT '部门代码，在同一组织下的部门代码不能重复',
  `PARENT_DEPT_ID` varchar(50) DEFAULT NULL COMMENT '父部门ID',
  `ORG_ID` varchar(50) NOT NULL COMMENT '组织ID',
  `ORDER_BY` decimal(16,0) NOT NULL COMMENT '排序',
  `POST` varchar(50) DEFAULT NULL COMMENT '邮编',
  `TEL` varchar(50) DEFAULT NULL COMMENT '电话',
  `FAX` varchar(50) DEFAULT NULL COMMENT '传真',
  `EMAIL` varchar(50) DEFAULT NULL COMMENT '邮件',
  `DEPT_ALIAS` varchar(50) DEFAULT NULL COMMENT '部门别称',
  `DEPT_TYPE` varchar(1) DEFAULT NULL COMMENT '部门类型',
  `DEPT_INDEX_TREE_NO` text COMMENT '树形索引',
  `WORK_CALENDAR_ID` varchar(50) DEFAULT NULL COMMENT '工作日历ID',
  `VALID_FLAG` varchar(1) NOT NULL COMMENT '设置部门是否有效，1-有效，0-无效',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `DEPT_LEVEL` decimal(16,0) DEFAULT NULL COMMENT '部门级别',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='部门表';

/*Data for the table `sys_dept` */

insert  into `sys_dept` values ('8a58ab4d4c2141fd014c217cdc5102b6','researchcenter','-1','8a58ab4d4c2141fd014c217c436a02b2','0',NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,'1','2015-03-16 15:29:33','1','2015-03-16 15:29:33','1','127.0.0.1','0','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

/*Table structure for table `sys_dept_tl` */

DROP TABLE IF EXISTS `sys_dept_tl`;

CREATE TABLE `sys_dept_tl` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `SYS_LANGUAGE_CODE` varchar(50) NOT NULL COMMENT '语言代码',
  `DEPT_NAME` varchar(100) NOT NULL COMMENT '部门名称',
  `DEPT_DESC` varchar(240) DEFAULT NULL COMMENT '部门描述',
  `DEPT_PLACE` varchar(100) DEFAULT NULL COMMENT '办公地点',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `SYS_DEPT_ID` varchar(50) NOT NULL COMMENT 'SYS_DEPT表ID',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='部门多语言表';

/*Data for the table `sys_dept_tl` */

insert  into `sys_dept_tl` values ('8a58ab4d4c2141fd014c217cdc6a02b8','zh_CN','研发中心',NULL,NULL,'2015-03-16 15:29:33','1','2015-03-16 15:29:33','1','127.0.0.1','0','8a58ab4d4c2141fd014c217cdc5102b6');

/*Table structure for table `sys_dynamic_datasource` */

DROP TABLE IF EXISTS `sys_dynamic_datasource`;

CREATE TABLE `sys_dynamic_datasource` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `DATASOURCE_NAME` varchar(100) NOT NULL COMMENT '数据源名称，不能重复',
  `JDBCURL` text NOT NULL COMMENT '数据库连接的jdbc字符串',
  `PASSWORD` varchar(100) NOT NULL COMMENT '密码',
  `USERNAME` varchar(100) NOT NULL COMMENT '用户名',
  `PROPERTIES` longtext COMMENT '保存数据库连接属性的字符串',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `DRIVERCLASS` text NOT NULL COMMENT '驱动类名称',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用于保存系统中的动态数据源定义';

/*Data for the table `sys_dynamic_datasource` */

/*Table structure for table `sys_excel_import_history` */

DROP TABLE IF EXISTS `sys_excel_import_history`;

CREATE TABLE `sys_excel_import_history` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `FILE_URL` varchar(255) DEFAULT NULL COMMENT '错误文件路径',
  `SUCCESS_COUNT` decimal(8,0) DEFAULT NULL COMMENT '成功数',
  `TOTAL_COUNT` decimal(8,0) DEFAULT NULL COMMENT '总数',
  `FAIL_COUNT` decimal(8,0) DEFAULT NULL COMMENT '失败数',
  `SYS_LOOKUP_CODE` varchar(255) DEFAULT NULL COMMENT '表的通用代码LOOKUPCODE',
  `SYS_LOOKUP_NAME` varchar(255) DEFAULT NULL COMMENT '表的通用代码LOOKUPNAME',
  `SYS_LOOKUP_TYPE` varchar(255) DEFAULT NULL COMMENT '表的通用代码LOOKUPTYPE',
  `SYS_APPLICATION` varchar(32) DEFAULT NULL COMMENT '应用ID',
  `SYS_LANGUAGE_CODE` varchar(32) DEFAULT NULL COMMENT '多语言CODE',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `OPETATOR_PERSON` varchar(255) DEFAULT NULL COMMENT '导入人',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='excel导入历史记录';

/*Data for the table `sys_excel_import_history` */

/*Table structure for table `sys_extend_metadata` */

DROP TABLE IF EXISTS `sys_extend_metadata`;

CREATE TABLE `sys_extend_metadata` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `TABLE_NAME` varchar(200) NOT NULL COMMENT '表名称，数据库中包含attribute扩展字段的表名称',
  `COL_NAME` varchar(200) NOT NULL COMMENT '源表中扩展列名称，一般以ATTRIBUTE开头',
  `DISPLAY_NAME` varchar(200) NOT NULL COMMENT '在界面上的显示名称',
  `DISPLAY_TIP` text COMMENT '在界面上的提示信息',
  `DISPLAY_TYPE` varchar(200) NOT NULL COMMENT '在界面上的显示类型，类型有：字符型、日期型、数字型',
  `DISPLAY_LENGTH` decimal(10,0) DEFAULT NULL COMMENT '最大显示长度，不能大于源表中扩展列的字段长度',
  `DISPLAY_COMMON_SELECTOR` varchar(200) DEFAULT NULL COMMENT '设置该字段引用哪个公共选择框，比如部门选择框、角色选择框等，界面要根据不同的选择框动态为该字段设置选择对话框',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `DISPLAY_COMMON_SELECTOR_TYPE` decimal(1,0) DEFAULT NULL COMMENT '该字段扩展类型0:自定义,1:系统代码,2:扩展控件:3:扩展javascript方法',
  `COL_IS_NULL` decimal(1,0) DEFAULT NULL COMMENT '该字段是否允许为空',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='扩展属性描述表。本表保存其他表中的扩展属性的名称、提示信息、展现类型、长度等定义信息，用于实现动态字段扩展功能。';

/*Data for the table `sys_extend_metadata` */

/*Table structure for table `sys_filter_config` */

DROP TABLE IF EXISTS `sys_filter_config`;

CREATE TABLE `sys_filter_config` (
  `ID` varchar(32) NOT NULL,
  `FILTER_CLASS_NAME` varchar(200) NOT NULL COMMENT '过滤器类名',
  `FILTER_ENABLE_FLG` varchar(1) NOT NULL COMMENT '过滤器启用标志',
  `VERSION` decimal(16,0) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sys_filter_config` */

insert  into `sys_filter_config` values ('8a58ab564c065b8e014c066d4cf702f5','avicit.platform6.core.shiroSecurity.cas.filler.CASFilter','0','1'),('8a58ab564c065b8e014c066d5e7402f6','avicit.platform6.core.shiroSecurity.cas.filler.LoginFilter','0','1'),('8a58ab564c074956014c074cbb2f0305','avicit.platform6.api.syssso.filter.LoginFilter','1','1'),('8a58ab564c074956014c074cbb3f0306','avicit.platform6.api.syssso.filter.CASFilter','1','1');

/*Table structure for table `sys_group` */

DROP TABLE IF EXISTS `sys_group`;

CREATE TABLE `sys_group` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `GROUP_PARENT_ID` varchar(50) DEFAULT NULL COMMENT '父群组ID',
  `ORG_ID` varchar(50) NOT NULL COMMENT '组织ID',
  `ORDER_BY` decimal(16,0) DEFAULT NULL COMMENT '排序',
  `TYPE` varchar(1) DEFAULT NULL COMMENT '群组类型',
  `BELONG_TO` varchar(50) DEFAULT NULL COMMENT '群组归属',
  `VALID_FLAG` varchar(1) NOT NULL COMMENT '设置群组是否有效，1-有效，0-无效',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '所属应用系统ID',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='群组表';

/*Data for the table `sys_group` */

/*Table structure for table `sys_group_tl` */

DROP TABLE IF EXISTS `sys_group_tl`;

CREATE TABLE `sys_group_tl` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `SYS_GROUP_ID` varchar(50) DEFAULT NULL COMMENT '群组ID',
  `SYS_LANGUAGE_CODE` varchar(50) DEFAULT NULL COMMENT '语言代码',
  `GROUP_NAME` varchar(100) DEFAULT NULL COMMENT '名称',
  `GROUP_DESC` varchar(240) DEFAULT NULL COMMENT '描述',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='群组多语言表';

/*Data for the table `sys_group_tl` */

/*Table structure for table `sys_job` */

DROP TABLE IF EXISTS `sys_job`;

CREATE TABLE `sys_job` (
  `ID_` varchar(150) NOT NULL COMMENT '主键',
  `NAME_` varchar(50) NOT NULL COMMENT '此Job的名称，要求具有描述性，如“月度销售统计任务”',
  `GROUP_` varchar(50) NOT NULL COMMENT '为了便于管理，将每个Job分组管理，要求具有描述性，如“报表组”。如果未指定，则框架提供一个默认的Group名称。',
  `PROGRAM_` varchar(100) NOT NULL COMMENT '此Job执行时调用的程序。由一个资源表达式定义，如spring:myBean#myFunction。',
  `CRON_` varchar(200) NOT NULL COMMENT '一个Cron表达式，用于定义Job的运行时机。如0 0 30 * * ?',
  `STATUS_` varchar(1) NOT NULL COMMENT '定时任务的当前状态，可能值为“未调度”、“暂停”、“运行中”',
  `DESCRIPTION_` varchar(200) DEFAULT NULL COMMENT '对此Job的描述。如“月度审计任务，将在每个月的第一天凌晨1点开始，审计上个月的销售情况，由XXX负责”',
  `CREATE_USER_` varchar(50) NOT NULL COMMENT '此条记录的创建人',
  `CREATE_DATE_` datetime NOT NULL COMMENT '此条记录的创建时间',
  `UPDATE_USER_` varchar(50) DEFAULT NULL COMMENT '此条记录的更新人',
  `UPDATE_DATE_` datetime DEFAULT NULL COMMENT '此条记录的更新日期',
  `TYPE_` varchar(20) DEFAULT NULL COMMENT 'spring,clazz,quartzClazz,sql,sp,jar',
  `LAST_STATE_` varchar(2) DEFAULT NULL COMMENT '最后一次执行的完成状态(S:成功，F:失败)',
  `COMPANY_ID_` varchar(45) DEFAULT NULL COMMENT '公司系统编号',
  PRIMARY KEY (`ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='定时任务任务定义表，用于定义一个定时任务的信息，包括名称、组、运行的程序、运行时机等。';

/*Data for the table `sys_job` */

/*Table structure for table `sys_job_calendar` */

DROP TABLE IF EXISTS `sys_job_calendar`;

CREATE TABLE `sys_job_calendar` (
  `ID_` varchar(50) NOT NULL COMMENT '主键',
  `NAME_` varchar(20) NOT NULL COMMENT '日历名称，用于标识日历对象，同时也作为Quartz的Calendar对象的名称。',
  `DESCRIPTION_` varchar(200) DEFAULT NULL COMMENT '日历描述，描述此日历的作用，如“法定节假日”',
  `CREATE_USER_` varchar(50) NOT NULL COMMENT '创建人',
  `CREATE_DATE_` datetime NOT NULL COMMENT '创建日期',
  `UPDATE_USER_` varchar(50) DEFAULT NULL COMMENT '更新人',
  `UPDATE_DATE_` datetime DEFAULT NULL COMMENT '更新日期',
  PRIMARY KEY (`ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='任务日历表，定义一些日历对象，用于排除某些天。';

/*Data for the table `sys_job_calendar` */

/*Table structure for table `sys_job_calendar_date` */

DROP TABLE IF EXISTS `sys_job_calendar_date`;

CREATE TABLE `sys_job_calendar_date` (
  `ID_` varchar(50) NOT NULL COMMENT '主键',
  `JOB_CALENDAR_ID_` varchar(50) NOT NULL COMMENT '任务日历主键，表示这一天属于哪一日历。',
  `EXCLUDED_DATE_` datetime NOT NULL COMMENT '被排除的天，在当天任务将不执行。',
  `DESCRIPTION_` varchar(200) DEFAULT NULL COMMENT '描述这一天为什么要被排除。',
  PRIMARY KEY (`ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='任务日历中的天，与任务日历表为多对一关系。定义了哪些天需要被排除。';

/*Data for the table `sys_job_calendar_date` */

/*Table structure for table `sys_job_calendar_job` */

DROP TABLE IF EXISTS `sys_job_calendar_job`;

CREATE TABLE `sys_job_calendar_job` (
  `ID_` varchar(50) NOT NULL COMMENT '主键',
  `JOB_ID_` varchar(50) NOT NULL COMMENT '任务主键',
  `JOB_CALENDAR_ID_` varchar(50) NOT NULL COMMENT '任务日历主键',
  PRIMARY KEY (`ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='此表用于维护任务与任务日历的一对多关系。';

/*Data for the table `sys_job_calendar_job` */

/*Table structure for table `sys_job_heartbeat` */

DROP TABLE IF EXISTS `sys_job_heartbeat`;

CREATE TABLE `sys_job_heartbeat` (
  `ID_` varchar(50) NOT NULL,
  `INSTANCE_NAME_` varchar(50) NOT NULL COMMENT '实例名，代表一个运行定时器的应用的实例。',
  `PRIORITY_` decimal(10,0) NOT NULL COMMENT '运行实例的优先级，通过拆解Preference中的job.servers定义获取。',
  `LAST_BEAT_TIME_` datetime NOT NULL COMMENT '最后跳动时间，同时也代表了当前实例的存活时间，通过对比此值判断实例的运行状态。',
  PRIMARY KEY (`ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='定时任务心跳表，以指定的时间间隔，不断向此表中更新心跳信息。';

/*Data for the table `sys_job_heartbeat` */

/*Table structure for table `sys_job_history` */

DROP TABLE IF EXISTS `sys_job_history`;

CREATE TABLE `sys_job_history` (
  `ID_` varchar(50) NOT NULL COMMENT '主键',
  `JOB_ID_` varchar(50) NOT NULL COMMENT '关联的定时任务的主键',
  `START_DATE_` datetime NOT NULL COMMENT '任务的开始时间',
  `END_DATE_` datetime DEFAULT NULL COMMENT '定时任务的结束时间',
  `END_STATUS_` varchar(1) NOT NULL COMMENT '定时任务的结束状态，共两种（S代表成功，F代表失败）',
  `MESSAGE_` varchar(250) DEFAULT NULL COMMENT '额外信息',
  PRIMARY KEY (`ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='定时任务历史记录表，用于记录每个定时任务的开始时间、完成时间、完成状况（失败或成功，失败时产生的消息）等';

/*Data for the table `sys_job_history` */

/*Table structure for table `sys_job_variables` */

DROP TABLE IF EXISTS `sys_job_variables`;

CREATE TABLE `sys_job_variables` (
  `ID_` varchar(50) NOT NULL COMMENT '变量主键 : 变量主键',
  `MASTER_ID_` varchar(50) DEFAULT NULL COMMENT '主表主键 : 主表主键',
  `MODULE_` varchar(100) DEFAULT NULL COMMENT '隶属模块名称 : 隶属模块名称',
  `TYPE_` varchar(10) DEFAULT NULL COMMENT '类型 : 类型',
  `NAME_` varchar(50) DEFAULT NULL COMMENT '变量名称 : 变量名称',
  `DATA_TYPE_` varchar(20) DEFAULT NULL COMMENT '变量数据类型 : 变量数据类型',
  `VALUE_` varchar(100) DEFAULT NULL COMMENT '变量默认值 : 变量默认值',
  `META1_` varchar(100) DEFAULT NULL COMMENT '备用字段1 : 备用字段1',
  `META2_` varchar(100) DEFAULT NULL COMMENT '备用字段2 : 备用字段2',
  PRIMARY KEY (`ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='定时器变量';

/*Data for the table `sys_job_variables` */

/*Table structure for table `sys_language` */

DROP TABLE IF EXISTS `sys_language`;

CREATE TABLE `sys_language` (
  `ID` varchar(50) NOT NULL COMMENT '唯一标识',
  `LANGUAGE_CODE` varchar(50) NOT NULL COMMENT '语言代码\r\n比如：ZH,EN,GB',
  `LANGUAGE_NAME` varchar(50) NOT NULL COMMENT '语言名称',
  `ORDER_BY` decimal(16,0) DEFAULT NULL COMMENT '排序索引值',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `IS_SYSTEM_DEFAULT` decimal(1,0) DEFAULT NULL COMMENT '是否是系统默认的语言',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='多语言配置表';

/*Data for the table `sys_language` */

insert  into `sys_language` values ('1','zh_CN','中文',NULL,'2014-11-18 16:30:58','1','2012-06-22 00:00:00','1','0:0:0:0:0:0:0:1','22','1');

/*Table structure for table `sys_log` */

DROP TABLE IF EXISTS `sys_log`;

CREATE TABLE `sys_log` (
  `ID` varchar(50) NOT NULL,
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL,
  `SYSLOG_USERNAME` varchar(50) DEFAULT NULL,
  `SYSLOG_TIME` datetime DEFAULT NULL,
  `SYSLOG_IP` varchar(50) DEFAULT NULL,
  `SYSLOG_OP` varchar(50) DEFAULT NULL,
  `SYSLOG_MODULE` varchar(50) DEFAULT NULL,
  `SYSLOG_TYPE` varchar(50) DEFAULT NULL,
  `SYSLOG_IS_GD` varchar(1) DEFAULT NULL,
  `SYSLOG_RESULT` varchar(10) DEFAULT NULL,
  `SYSLOG_CONTENT` longtext,
  `SYSLOG_TABLE` varchar(50) DEFAULT NULL,
  `SYSLOG_FORMID` varchar(50) DEFAULT NULL,
  `SYSLOG_SECRETLEVEL` varchar(50) DEFAULT NULL,
  `LAST_UPDATE_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` varchar(50) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `CREATED_BY` varchar(50) NOT NULL,
  `LAST_UPDATE_IP` varchar(50) NOT NULL,
  `VERSION` decimal(16,0) NOT NULL,
  `SYSLOG_TITLE` text,
  `SYSLOG_USERNAME_ZH` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sys_log` */

/*Table structure for table `sys_log_archived` */

DROP TABLE IF EXISTS `sys_log_archived`;

CREATE TABLE `sys_log_archived` (
  `ID` varchar(32) NOT NULL COMMENT '主键',
  `ARCHIVE_DATE` datetime DEFAULT NULL COMMENT '归档时间',
  `ARCHIVE_NAME` text COMMENT '归档名称',
  `ARCHIVE_TABLE_NAME` text COMMENT '归档表名称',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `SYS_APP_ID` varchar(32) DEFAULT NULL COMMENT '归档所属系统',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sys_log_archived` */

/*Table structure for table `sys_lookup` */

DROP TABLE IF EXISTS `sys_lookup`;

CREATE TABLE `sys_lookup` (
  `ID` varchar(50) NOT NULL COMMENT '唯一标识',
  `SYS_LOOKUP_TYPE_ID` varchar(50) DEFAULT NULL COMMENT '通用代码ID',
  `DISPLAY_ORDER` decimal(16,0) DEFAULT NULL COMMENT '显示顺序',
  `LOOKUP_CODE` text COMMENT '明细代码',
  `VALID_FLAG` varchar(1) DEFAULT NULL COMMENT '是否有效\r\n1代表有效,0代表无效 默认为1',
  `SYSTEM_FLAG` varchar(1) DEFAULT NULL COMMENT '是否是系统初始值\r\nY 是 N 否',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='通用代码选项表';

/*Data for the table `sys_lookup` */

insert  into `sys_lookup` values ('2c9ba38154dc5c6a0154dc7a5c6201c0','2c9ba38154dc5c6a0154dc7a004e01bc','1','email','1',NULL,'2016-05-23 15:18:07','1','2016-05-23 15:18:07','1','0:0:0:0:0:0:0:1','0'),('2c9ba38154dc5c6a0154dc7ac83901c5','2c9ba38154dc5c6a0154dc7a004e01bc','2','mobile','1',NULL,'2016-05-23 15:18:34','1','2016-05-23 15:18:34','1','0:0:0:0:0:0:0:1','0'),('2c9ba38154dc5c6a0154dc7b116e01ca','2c9ba38154dc5c6a0154dc7a004e01bc','3','chinese','1',NULL,'2016-05-23 15:18:53','1','2016-05-23 15:18:53','1','0:0:0:0:0:0:0:1','0'),('2c9ba38154dc5c6a0154dc7b459e01cf','2c9ba38154dc5c6a0154dc7a004e01bc','4','english','1',NULL,'2016-05-23 15:19:06','1','2016-05-23 15:19:06','1','0:0:0:0:0:0:0:1','0'),('2c9ba38154dc5c6a0154dc7c052501d4','2c9ba38154dc5c6a0154dc7a004e01bc','5','zipcode','1',NULL,'2016-05-23 15:19:55','1','2016-05-23 15:19:55','1','0:0:0:0:0:0:0:1','0'),('402809814d40e57c014d40e758c9000a','40288a1538e20d320138e20d32450000','2','avicit/platform6/modules/system/sysdashboard/traditional_index.jsp','1',NULL,'2015-05-11 16:20:21','1','2015-05-11 10:56:52','1','127.0.0.1','7'),('402809814eb01b2c014eb02dca9500f4','402809814eb01b2c014eb02d551600f0','1','1','1',NULL,'2015-07-21 18:34:27','1','2015-07-21 18:34:27','1','127.0.0.1','0'),('402809814eb01b2c014eb02dcaaf00f6','402809814eb01b2c014eb02d551600f0','2','2','1',NULL,'2015-07-21 18:34:27','1','2015-07-21 18:34:27','1','127.0.0.1','0'),('40288a1538e20d320138e20e08ce0006','40288a1538e20d320138e20d32450000','1','avicit/platform6/modules/system/sysdashboard/index.jsp','1',NULL,'2015-05-11 16:20:21','1','2012-08-01 19:59:26','1','127.0.0.1','38'),('40288a34392d730601392df526690006','40288a34392d730601392df526370004','1','openSubWindow_pwd::js','1',NULL,'2015-11-26 16:20:51','1','2012-08-16 13:43:24','1','127.0.0.1','41'),('40288a34392d730601392df7c2c00008','40288a34392d730601392df526370004','2','customedSetting::menu','1',NULL,'2015-11-26 16:20:51','1','2012-08-16 13:46:15','1','127.0.0.1','40'),('40288a34392d730601392df7c2c8000a','40288a34392d730601392df526370004','4','logout::js','1',NULL,'2016-03-14 10:42:46','1','2012-08-16 13:46:15','1','127.0.0.1','41'),('40288a3b38576e590138576ed2580002','40288a3b38576e590138576e590f0000','1','1','1',NULL,'2012-07-05 21:57:56','1','2012-07-05 21:57:56','1','0:0:0:0:0:0:0:1','13'),('40288a3b38576e590138576ed2770004','40288a3b38576e590138576e590f0000','2','0','1',NULL,'2012-07-12 11:27:52','1','2012-07-05 21:57:56','1','0:0:0:0:0:0:0:1','14'),('40288a3b38578f0f013857947578000a','40288a3b38578f0f0138579409520008','1','1','1',NULL,'2012-07-05 22:39:03','1','2012-07-05 22:39:03','1','0:0:0:0:0:0:0:1','8'),('40288a3b38578f0f0138579475c9000c','40288a3b38578f0f0138579409520008','2','2','1',NULL,'2013-04-08 10:59:30','1','2012-07-05 22:39:03','1','0:0:0:0:0:0:0:1','9'),('40288a3b38703f53013870418afd0001','40288afa380ece0201380ed4f81b000f','1','1','1',NULL,'2015-03-04 16:52:35','1','2012-07-10 17:38:59','1','10.216.43.205','24'),('40288a3b38703f53013870418b220003','40288afa380ece0201380ed4f81b000f','2','2','1',NULL,'2012-07-10 17:39:00','1','2012-07-10 17:39:00','1','0:0:0:0:0:0:0:1','22'),('40288a3b3873c2c2013875164c79000a','40288a3b3873c2c2013875158fb00008','1','1','1',NULL,'2012-07-11 16:09:51','1','2012-07-11 16:09:51','1','0:0:0:0:0:0:0:1','12'),('40288a3b3873c2c2013875164c93000c','40288a3b3873c2c2013875158fb00008','2','2','1',NULL,'2012-07-11 16:09:52','1','2012-07-11 16:09:52','1','0:0:0:0:0:0:0:1','12'),('40288a3b3873c2c2013875164ca3000e','40288a3b3873c2c2013875158fb00008','3','3','1',NULL,'2012-07-11 16:09:52','1','2012-07-11 16:09:52','1','0:0:0:0:0:0:0:1','12'),('40288a3b3873c2c2013875164cb50010','40288a3b3873c2c2013875158fb00008','4','4','1',NULL,'2012-09-12 14:40:55','1','2012-07-11 16:09:52','1','0:0:0:0:0:0:0:1','14'),('40288a3b3873c2c20138751bd2790014','40288a3b3873c2c20138751b361d0012','1','1','1',NULL,'2012-07-11 16:15:53','1','2012-07-11 16:15:53','1','0:0:0:0:0:0:0:1','15'),('40288a3b3873c2c20138751bd2860016','40288a3b3873c2c20138751b361d0012','2','2','1',NULL,'2012-07-11 16:15:53','1','2012-07-11 16:15:53','1','0:0:0:0:0:0:0:1','15'),('40288a3b3873c2c20138751bd2920018','40288a3b3873c2c20138751b361d0012','3','3','1',NULL,'2012-07-11 16:15:54','1','2012-07-11 16:15:54','1','0:0:0:0:0:0:0:1','15'),('40288a3b3873c2c20138751bd29a001a','40288a3b3873c2c20138751b361d0012','4','4','1',NULL,'2012-07-11 16:15:54','1','2012-07-11 16:15:54','1','0:0:0:0:0:0:0:1','15'),('40288a3b38c274470138c27b62ae0004','40288a3b38c274470138c27b62860002','1','1','1',NULL,'2012-07-26 16:51:02','1','2012-07-26 16:51:02','1','0:0:0:0:0:0:0:1','18'),('40288a3b38c274470138c27b62d20006','40288a3b38c274470138c27b62860002','2','0','1',NULL,'2012-07-26 16:51:02','1','2012-07-26 16:51:02','1','0:0:0:0:0:0:0:1','18'),('40288a3b38c2bb890138c2d41fed0008','40288a3b38c2bb890138c2d41fbd0006','1','Y','1',NULL,'2012-07-27 17:26:53','1','2012-07-26 18:27:58','1','0:0:0:0:0:0:0:1','23'),('40288a3b38c2bb890138c2d42033000a','40288a3b38c2bb890138c2d41fbd0006','2','N','1',NULL,'2012-07-27 17:26:53','1','2012-07-26 18:27:58','1','0:0:0:0:0:0:0:1','23'),('40288a6938c7b3d40138c7bacf760008','40288a6938c7b3d40138c7bacf460006','0','1','1',NULL,'2012-08-11 18:34:57','1','2012-07-27 17:18:25','1','127.0.0.1','24'),('40288a6938c8453b0138c85317310006','40288a6938c7b3d40138c7bacf460006','1','2','1',NULL,'2012-08-11 18:34:57','1','2012-07-27 20:04:44','1','127.0.0.1','23'),('40288ace39538b830139539568790012','40288ace39538b830139539503300010','1','true','1',NULL,'2012-08-23 21:04:24','1','2012-08-23 21:04:24','1','0:0:0:0:0:0:0:1','26'),('40288ace39538b8301395395688c0014','40288ace39538b830139539503300010','2','false','1',NULL,'2012-08-23 21:04:24','1','2012-08-23 21:04:24','1','0:0:0:0:0:0:0:1','26'),('40288af9386fe46a0138702a39800002','40288a3b38578f0f01385792df300002','1','1','1',NULL,'2012-07-10 17:13:31','1','2012-07-10 17:13:31','1','0:0:0:0:0:0:0:1','7'),('40288af9386fe46a0138702a39970004','40288a3b38578f0f01385792df300002','2','2','1',NULL,'2012-07-10 17:13:31','1','2012-07-10 17:13:31','1','0:0:0:0:0:0:0:1','7'),('40288af938761d0f0138762402cd0001','40288af9385c33b601385c8898600007','1','001','1',NULL,'2013-04-08 10:56:16','1','2012-07-11 21:04:27','1','0:0:0:0:0:0:0:1','10'),('40288af938761d0f0138762402ff0003','40288af9385c33b601385c8898600007','2','002','1',NULL,'2013-04-08 10:56:16','1','2012-07-11 21:04:27','1','0:0:0:0:0:0:0:1','10'),('40288afa3811e31b013811e36f420002','40288afa3811e31b013811e31b290000','1','1','1',NULL,'2012-06-22 09:51:54','1','2012-06-22 09:51:54','1','127.0.0.1','5'),('40288afa381308060138130806e30000','40288afa3811e31b013811e31b290000','2','2','1',NULL,'2012-06-22 15:11:29','1','2012-06-22 15:11:29','1','0:0:0:0:0:0:0:1','5'),('40288afb387038050138703b06550003','40288afb387038050138703a01750001','1','0','1',NULL,'2012-07-10 17:31:52','1','2012-07-10 17:31:52','1','127.0.0.1','7'),('40288afb387038050138703b06750005','40288afb387038050138703a01750001','2','1','1',NULL,'2012-07-10 17:31:52','1','2012-07-10 17:31:52','1','127.0.0.1','7'),('40288afb3870380501387049949c000f','40288afb387038050138704888c6000d','1','1','1',NULL,'2012-07-10 17:47:46','1','2012-07-10 17:47:46','1','127.0.0.1','20'),('40288afb387038050138704994ab0011','40288afb387038050138704888c6000d','2','3','1',NULL,'2014-03-20 15:02:32','1','2012-07-10 17:47:46','1','0:0:0:0:0:0:0:1','21'),('40288afb389e322901389e87188f0016','40288afb389e322901389e8718680014','1','1','1',NULL,'2012-07-19 17:17:30','1','2012-07-19 17:17:30','1','127.0.0.1','18'),('40288afb389e322901389e8718a40018','40288afb389e322901389e8718680014','2','2','1',NULL,'2012-07-19 17:17:30','1','2012-07-19 17:17:30','1','127.0.0.1','18'),('40288afb389e322901389e8718b2001a','40288afb389e322901389e8718680014','3','3','1',NULL,'2012-07-19 17:17:30','1','2012-07-19 17:17:30','1','127.0.0.1','18'),('40288afb38c1650d0138c1704e06000a','40288afb38c101240138c15be182001c','2','1','1',NULL,'2015-03-04 16:19:17','1','2012-07-26 11:59:19','1','10.216.43.205','16'),('40288afb38c1650d0138c1704e23000c','40288afb38c101240138c15be182001c','1','0','1',NULL,'2015-03-04 16:19:17','1','2012-07-26 11:59:19','1','10.216.43.205','17'),('8a58a6b43e832d5a013e83487c220012','8a58a6b43e832d5a013e834814f6000e','1','0','1',NULL,'2013-05-08 16:36:05','1','2013-05-08 16:36:05','1','10.216.43.171','24'),('8a58a6b43e832d5a013e83487ca00016','8a58a6b43e832d5a013e834814f6000e','2','1','1',NULL,'2013-05-08 16:36:05','1','2013-05-08 16:36:05','1','10.216.43.171','24'),('8a58a6b54faab7eb014fab78ab380ac0','8a58a6b54faab7eb014fab7815710abc','1','0','1',NULL,'2015-09-08 13:40:56','1','2015-09-08 13:40:56','1','10.216.77.195','0'),('8a58a6b54faab7eb014fab78ab620ac2','8a58a6b54faab7eb014fab7815710abc','2','1','1',NULL,'2015-09-08 13:40:56','1','2015-09-08 13:40:56','1','10.216.77.195','0'),('8a58ab2e3de781a7013de79295010012','40288af9385c33b601385c8898600007','3','003','1',NULL,'2015-05-15 11:21:01','1','2013-04-08 10:56:16','1','127.0.0.1','5'),('8a58ab2e3de781a7013de7958d490023','40288a3b38578f0f0138579409520008','3','3','1',NULL,'2013-04-08 10:59:30','1','2013-04-08 10:59:30','1','0:0:0:0:0:0:0:1','3'),('8a58ab2e3de781a7013de7958d5d0027','40288a3b38578f0f0138579409520008','4','4','1',NULL,'2013-04-08 10:59:30','1','2013-04-08 10:59:30','1','0:0:0:0:0:0:0:1','3'),('8a58ab2e3df1d260013df1dc2e3a0012','8a58ab2e3df1d260013df1dc2dc4000e','1','1','1',NULL,'2013-04-10 10:52:51','1','2013-04-10 10:52:51','1','0:0:0:0:0:0:0:1','18'),('8a58ab2e3df1d260013df1dc2e7f0016','8a58ab2e3df1d260013df1dc2dc4000e','2','0','1',NULL,'2013-04-10 10:52:51','1','2013-04-10 10:52:51','1','0:0:0:0:0:0:0:1','18'),('8a58ab2e3df28e91013df2905f670007','8a58ab2e3df28e91013df2905f2e0003','1','1','1',NULL,'2013-04-10 14:09:40','1','2013-04-10 14:09:40','1','0:0:0:0:0:0:0:1','19'),('8a58ab2e3df28e91013df2905f8c000b','8a58ab2e3df28e91013df2905f2e0003','2','0','1',NULL,'2013-04-10 14:10:12','1','2013-04-10 14:09:40','1','0:0:0:0:0:0:0:1','20'),('8a58ab393ff47bc1013ff47ec7700003','40288afb389e322901389e8718680014','4','4','1',NULL,'2013-07-19 09:15:16','1','2013-07-19 09:15:16','1','0:0:0:0:0:0:0:1','0'),('8a58ab393ff47bc1013ff47ec8410007','40288afb389e322901389e8718680014','5','5','1',NULL,'2013-07-19 09:15:16','1','2013-07-19 09:15:16','1','0:0:0:0:0:0:0:1','0'),('8a58ab394129d1e8014129e9b43f0010','8a58ab394129d1e8014129e9b38f000c','1','1','1',NULL,'2013-09-17 11:14:43','1','2013-09-17 11:14:43','1','0:0:0:0:0:0:0:1','32'),('8a58ab394129d1e8014129e9b4630014','8a58ab394129d1e8014129e9b38f000c','2','2','1',NULL,'2013-09-17 11:14:43','1','2013-09-17 11:14:43','1','0:0:0:0:0:0:0:1','32'),('8a58ab3b4144266d0141442a42c30007','8a58ab3b4144266d0141442a42670003','1','0','1',NULL,'2013-09-22 13:35:22','1','2013-09-22 13:35:22','1','127.0.0.1','26'),('8a58ab3b4144266d0141442a42fd000b','8a58ab3b4144266d0141442a42670003','2','1','1',NULL,'2013-09-22 13:35:22','1','2013-09-22 13:35:22','1','127.0.0.1','26'),('8a58ab3f3df30996013df32b7826000d','8a58ab3f3df30996013df32b77e50009','1','1','1',NULL,'2013-04-10 16:59:05','1','2013-04-10 16:59:05','1','0:0:0:0:0:0:0:1','68'),('8a58ab3f3df30996013df32b783d0011','8a58ab3f3df30996013df32b77e50009','2','0','1',NULL,'2013-04-10 16:59:05','1','2013-04-10 16:59:05','1','0:0:0:0:0:0:0:1','68'),('8a58ab473b8e50d9013b8e540ae60006','8a58ab473b8e50d9013b8e540a7f0002','1','user','1',NULL,'2012-12-13 11:10:06','1','2012-12-12 16:56:10','1','127.0.0.1','24'),('8a58ab473b9239fd013b923d90d40004','8a58ab473b8e50d9013b8e540a7f0002','2','dept','1',NULL,'2012-12-13 11:10:06','1','2012-12-13 11:10:06','1','127.0.0.1','21'),('8a58ab473b9239fd013b923d90f70008','8a58ab473b8e50d9013b8e540a7f0002','3','day','1',NULL,'2012-12-13 11:10:06','1','2012-12-13 11:10:06','1','127.0.0.1','21'),('8a58ab473b9239fd013b923d910d000c','8a58ab473b8e50d9013b8e540a7f0002','4','time','1',NULL,'2012-12-13 11:10:06','1','2012-12-13 11:10:06','1','127.0.0.1','21'),('8a58ab473b9239fd013b923d91250010','8a58ab473b8e50d9013b8e540a7f0002','5','idea','1',NULL,'2012-12-13 11:10:06','1','2012-12-13 11:10:06','1','127.0.0.1','21'),('8a58ab473b933866013b9345823d0002','8a58ab473b8e50d9013b8e540a7f0002','6','select','1',NULL,'2013-04-18 16:00:20','1','2012-12-13 15:58:24','1','0:0:0:0:0:0:0:1','21'),('8a58ab4d4c2c48e3014c2c4af2b5000b','8a58ab4d4c2c48e3014c2c4a69b60007','0','0','1',NULL,'2015-03-18 17:50:51','1','2015-03-18 17:50:51','1','127.0.0.1','0'),('8a58ab4d4c45da24014c45e0ce110085','8a58ab4d4c45da24014c45df9a0d0081','2','blue','1',NULL,'2015-03-23 17:05:03','1','2015-03-23 17:05:03','1','127.0.0.1','0'),('8a58ab574c7e3591014c7e369a790003','8a58ab4d4c45da24014c45df9a0d0081','1','gray','1',NULL,'2015-04-03 15:37:30','1','2015-04-03 15:37:30','1','127.0.0.1','0'),('8a58ab574c7e3591014c7e3c45b00007','8a58ab4d4c2c48e3014c2c4a69b60007','1','1','1',NULL,'2015-04-03 15:43:41','1','2015-04-03 15:43:41','1','127.0.0.1','0'),('8a58abce3b91d7f0013b91e3e4a2000b','8a58abce3b91d7f0013b91e3e4640007','1','0','1',NULL,'2012-12-13 09:32:09','1','2012-12-13 09:32:09','1','0:0:0:0:0:0:0:1','27'),('8a58abce3b91d7f0013b91e3e4c1000f','8a58abce3b91d7f0013b91e3e4640007','1','1','1',NULL,'2012-12-13 09:32:09','1','2012-12-13 09:32:09','1','0:0:0:0:0:0:0:1','27'),('8a58abce3b91d7f0013b91e515770017','8a58abce3b91d7f0013b91e515480013','1','0','1',NULL,'2012-12-13 09:33:27','1','2012-12-13 09:33:27','1','0:0:0:0:0:0:0:1','72'),('8a58abce3b91d7f0013b91e51586001b','8a58abce3b91d7f0013b91e515480013','2','1','1',NULL,'2012-12-13 09:33:27','1','2012-12-13 09:33:27','1','0:0:0:0:0:0:0:1','72'),('8a58abf63e6328e6013e633c43b00052','8a58abf63e6328e6013e633c4333004e','1','1','1',NULL,'2013-05-02 15:02:11','1','2013-05-02 11:14:54','1','127.0.0.1','20'),('8a58abf63e6328e6013e633c43ee0056','8a58abf63e6328e6013e633c4333004e','2','2','1',NULL,'2013-05-02 15:02:11','1','2013-05-02 11:14:54','1','127.0.0.1','20'),('8a58abf63e63d8ac013e64182f0f001a','8a58abf63e63d8ac013e6415b4e20016','1','1','1',NULL,'2013-05-02 15:15:06','1','2013-05-02 15:15:06','1','127.0.0.1','8'),('8a58abf63e63d8ac013e64182f2f001e','8a58abf63e63d8ac013e6415b4e20016','2','0','1',NULL,'2013-05-02 15:25:49','1','2013-05-02 15:15:06','1','127.0.0.1','9'),('8a58abf63e63d8ac013e6421cc04002a','8a58abf63e63d8ac013e6415b493000e','1','1','1',NULL,'2013-05-02 17:24:44','1','2013-05-02 15:25:36','1','0:0:0:0:0:0:0:1','10'),('8a58abf63e63d8ac013e6421cc15002e','8a58abf63e63d8ac013e6415b493000e','2','0','1',NULL,'2013-05-02 17:24:44','1','2013-05-02 15:25:36','1','0:0:0:0:0:0:0:1','10'),('8a58abf63e63d8ac013e643688bc0038','8a58abf63e63d8ac013e6436887d0034','1','1','1',NULL,'2014-11-28 14:43:43','1','2013-05-02 15:48:15','1','127.0.0.1','22'),('8a58abf63e63d8ac013e643688db003c','8a58abf63e63d8ac013e6436887d0034','2','0','1',NULL,'2013-05-02 15:51:16','1','2013-05-02 15:48:15','1','127.0.0.1','21'),('8a58c8434d468f93014d46ba5ddd00dc','40288afb389e322901389e8718680014','6','6','1',NULL,'2015-05-12 14:05:28','1','2015-05-12 14:05:28','1','127.0.0.1','0'),('8a58c8434d468f93014d46ba5df700e0','40288afb389e322901389e8718680014','7','7','1',NULL,'2015-05-12 14:05:28','1','2015-05-12 14:05:28','1','127.0.0.1','0'),('8a58cd574d5b89ad014d5b903871004a','8a58cd574d5b89ad014d5b8fb4360046','2','2','1',NULL,'2015-05-16 15:11:27','1','2015-05-16 15:11:27','1','127.0.0.1','0'),('8a58cd574d5b89ad014d5b90388d004e','8a58cd574d5b89ad014d5b8fb4360046','1','1','1',NULL,'2015-05-16 15:11:27','1','2015-05-16 15:11:27','1','127.0.0.1','0'),('8a58cd5750180ec80150181460d9004e','8a58ab4d4c45da24014c45df9a0d0081','3','blue_oa','1',NULL,'2016-03-08 10:51:44','1','2015-09-29 15:50:00','1','127.0.0.1','1'),('8a58cd57515b12c301515b43bbfc015a','40288a34392d730601392df526370004','3','changeLgg::js','1',NULL,'2016-03-14 10:42:46','1','2012-08-16 13:46:15','1','127.0.0.1','41'),('8a58cd575354173501535423e7240054','8a58ab4d4c45da24014c45df9a0d0081','4','azure','1',NULL,'2016-03-08 10:52:32','1','2016-03-08 10:52:32','1','127.0.0.1','0'),('8a58cd575354173501535431850c005d','40288a1538e20d320138e20d32450000','3','avicit/platform6/modules/system/sysdashboard/leftmenu_index.jsp','1',NULL,'2016-03-08 11:07:24','1','2016-03-08 11:07:24','1','127.0.0.1','0'),('8a58cd605654778a01565482a96600ed','8a58ab4d4c45da24014c45df9a0d0081','5','green','1',NULL,'2016-08-04 15:44:24','1','2016-08-04 15:44:24','1','127.0.0.1','0');

/*Table structure for table `sys_lookup_hiberarchy` */

DROP TABLE IF EXISTS `sys_lookup_hiberarchy`;

CREATE TABLE `sys_lookup_hiberarchy` (
  `ID` varchar(50) NOT NULL COMMENT '唯一标识',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '应用ID',
  `LOOKUP_TYPE` varchar(50) DEFAULT NULL COMMENT '代码类型',
  `SYSTEM_FLAG` varchar(1) DEFAULT NULL COMMENT '是否为系统初始\r\nY 是 N 否',
  `VALID_FLAG` varchar(1) DEFAULT NULL COMMENT '是否有效\r\n1代表有效,0代表无效 默认为1',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `PARENT_ID` varchar(32) NOT NULL COMMENT '父ID',
  `TYPE_KEY` varchar(255) DEFAULT NULL COMMENT '数据编码',
  `TYPE_VALUE` varchar(255) NOT NULL COMMENT '数据值',
  `ORDER_BY` decimal(65,30) NOT NULL COMMENT '排序',
  `REMARK` text COMMENT '备注',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '预留字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '预留字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '预留字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '预留字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '预留字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '预留字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '预留字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '预留字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '预留字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '预留字段',
  `SYS_LANGUAGE_CODE` varchar(255) DEFAULT NULL COMMENT '多语言 ',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='通用代码类型表 扩展支持多级层次';

/*Data for the table `sys_lookup_hiberarchy` */

insert  into `sys_lookup_hiberarchy` values ('1','1','AVICT_TT','0','1','2012-07-18 15:05:53','admin','2012-09-11 00:00:00','admin','0:0:0:0:0:0:0:1','3','-1','code','数据字典','1.000000000000000000000000000000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'zh_CN');

/*Table structure for table `sys_lookup_tl` */

DROP TABLE IF EXISTS `sys_lookup_tl`;

CREATE TABLE `sys_lookup_tl` (
  `ID` varchar(50) NOT NULL COMMENT '唯一标识',
  `SYS_LOOKUP_ID` varchar(50) DEFAULT NULL COMMENT '通用代码明细ID',
  `SYS_LANGUAGE_CODE` varchar(50) DEFAULT NULL COMMENT '语言代码',
  `LOOKUP_NAME` varchar(100) DEFAULT NULL COMMENT '显示名称',
  `DESCRIPTION` varchar(240) DEFAULT NULL COMMENT '描述',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='通用代码选项多语言表';

/*Data for the table `sys_lookup_tl` */

insert  into `sys_lookup_tl` values ('2c9ba38154dc5c6a0154dc7a5c7801c1','2c9ba38154dc5c6a0154dc7a5c6201c0','zh_CN','邮件',NULL,'2016-05-23 15:18:07','1','2016-05-23 15:18:07','1','0:0:0:0:0:0:0:1','0'),('2c9ba38154dc5c6a0154dc7ac84201c6','2c9ba38154dc5c6a0154dc7ac83901c5','zh_CN','手机',NULL,'2016-05-23 15:18:34','1','2016-05-23 15:18:34','1','0:0:0:0:0:0:0:1','0'),('2c9ba38154dc5c6a0154dc7b117601cb','2c9ba38154dc5c6a0154dc7b116e01ca','zh_CN','中文',NULL,'2016-05-23 15:18:53','1','2016-05-23 15:18:53','1','0:0:0:0:0:0:0:1','0'),('2c9ba38154dc5c6a0154dc7b45aa01d0','2c9ba38154dc5c6a0154dc7b459e01cf','zh_CN','英文',NULL,'2016-05-23 15:19:06','1','2016-05-23 15:19:06','1','0:0:0:0:0:0:0:1','0'),('2c9ba38154dc5c6a0154dc7c053001d5','2c9ba38154dc5c6a0154dc7c052501d4','zh_CN','邮编',NULL,'2016-05-23 15:19:55','1','2016-05-23 15:19:55','1','0:0:0:0:0:0:0:1','0'),('402809814d40e57c014d40e758cf000b','402809814d40e57c014d40e758c9000a','zh_CN','普通式','static/images/platform/syscustomed/commonMenu.jpg','2015-05-11 16:20:21','1','2015-05-11 10:56:52','1','127.0.0.1','7'),('402809814eb01b2c014eb02dcaa800f5','402809814eb01b2c014eb02dca9500f4','zh_CN','国家军用标准',NULL,'2015-07-21 18:34:27','1','2015-07-21 18:34:27','1','127.0.0.1','0'),('402809814eb01b2c014eb02dcab500f7','402809814eb01b2c014eb02dcaaf00f6','zh_CN','国家民用标准',NULL,'2015-07-21 18:34:27','1','2015-07-21 18:34:27','1','127.0.0.1','0'),('40288a1538e20d320138e20e08ce0007','40288a1538e20d320138e20e08ce0006','zh_CN','卡片式','static/images/platform/syscustomed/cardMenu.jpg','2015-05-11 16:20:21','1','2012-08-01 19:59:26','1','127.0.0.1','2'),('40288a34392d730601392df526690007','40288a34392d730601392df526690006','zh_CN','修改密码','修改密码','2015-11-26 16:20:51','1','2012-08-16 13:43:24','1','127.0.0.1','3'),('40288a34392d730601392df7c2c00009','40288a34392d730601392df7c2c00008','zh_CN','个人设置','个人设置','2015-11-26 16:20:51','1','2012-08-16 13:46:15','1','127.0.0.1','5'),('40288a34392d730601392df7c2c8000b','40288a34392d730601392df7c2c8000a','zh_CN','退出','退出','2016-03-14 10:42:46','1','2012-08-16 13:46:15','1','127.0.0.1','5'),('40288a3b38576e590138576ed2580003','40288a3b38576e590138576ed2580002','zh_CN','有效',NULL,'2012-07-05 21:57:56','1','2012-07-05 21:57:56','1','0:0:0:0:0:0:0:1','0'),('40288a3b38576e590138576ed2770005','40288a3b38576e590138576ed2770004','zh_CN','无效',NULL,'2012-07-12 11:27:52','1','2012-07-05 21:57:56','1','0:0:0:0:0:0:0:1','0'),('40288a3b38578f0f013857947578000b','40288a3b38578f0f013857947578000a','zh_CN','党员','党员','2012-07-05 22:39:03','1','2012-07-05 22:39:03','1','0:0:0:0:0:0:0:1','0'),('40288a3b38578f0f0138579475c9000d','40288a3b38578f0f0138579475c9000c','zh_CN','团员','团员','2012-07-05 22:39:03','1','2012-07-05 22:39:03','1','0:0:0:0:0:0:0:1','0'),('40288a3b38703f53013870418afe0002','40288a3b38703f53013870418afd0001','zh_CN','男','男','2015-03-04 16:52:35','1','2012-07-10 17:38:59','1','10.216.43.205','0'),('40288a3b38703f53013870418b240004','40288a3b38703f53013870418b220003','zh_CN','女','女','2012-07-10 17:39:00','1','2012-07-10 17:39:00','1','0:0:0:0:0:0:0:1','0'),('40288a3b3873c2c2013875164c7a000b','40288a3b3873c2c2013875164c79000a','zh_CN','非涉密人员','非涉密人员','2012-07-11 16:09:51','1','2012-07-11 16:09:51','1','0:0:0:0:0:0:0:1','0'),('40288a3b3873c2c2013875164c93000d','40288a3b3873c2c2013875164c93000c','zh_CN','一般涉密人员','一般涉密人员','2012-07-11 16:09:52','1','2012-07-11 16:09:52','1','0:0:0:0:0:0:0:1','0'),('40288a3b3873c2c2013875164ca4000f','40288a3b3873c2c2013875164ca3000e','zh_CN','重点涉密人员','重点涉密人员','2012-07-11 16:09:52','1','2012-07-11 16:09:52','1','0:0:0:0:0:0:0:1','0'),('40288a3b3873c2c2013875164cb50011','40288a3b3873c2c2013875164cb50010','zh_CN','核心涉密人员','核心涉密人员','2012-09-12 14:40:55','1','2012-07-11 16:09:52','1','0:0:0:0:0:0:0:1','0'),('40288a3b3873c2c20138751bd27a0015','40288a3b3873c2c20138751bd2790014','zh_CN','非涉密文档','非涉密文档','2012-07-11 16:15:53','1','2012-07-11 16:15:53','1','0:0:0:0:0:0:0:1','0'),('40288a3b3873c2c20138751bd2890017','40288a3b3873c2c20138751bd2860016','zh_CN','一般涉密文档','一般涉密文档','2012-07-11 16:15:53','1','2012-07-11 16:15:53','1','0:0:0:0:0:0:0:1','0'),('40288a3b3873c2c20138751bd2920019','40288a3b3873c2c20138751bd2920018','zh_CN','重点涉密文档','重点涉密文档','2012-07-11 16:15:54','1','2012-07-11 16:15:54','1','0:0:0:0:0:0:0:1','0'),('40288a3b3873c2c20138751bd29a001b','40288a3b3873c2c20138751bd29a001a','zh_CN','核心涉密文档','核心涉密文档','2012-07-11 16:15:54','1','2012-07-11 16:15:54','1','0:0:0:0:0:0:0:1','0'),('40288a3b38c274470138c27b62af0005','40288a3b38c274470138c27b62ae0004','zh_CN','是',NULL,'2012-07-26 16:51:02','1','2012-07-26 16:51:02','1','0:0:0:0:0:0:0:1','0'),('40288a3b38c274470138c27b62d20007','40288a3b38c274470138c27b62d20006','zh_CN','否',NULL,'2012-07-26 16:51:02','1','2012-07-26 16:51:02','1','0:0:0:0:0:0:0:1','0'),('40288a3b38c2bb890138c2d41fed0009','40288a3b38c2bb890138c2d41fed0008','zh_CN','是',NULL,'2012-07-27 17:26:53','1','2012-07-26 18:27:58','1','0:0:0:0:0:0:0:1','0'),('40288a3b38c2bb890138c2d42033000b','40288a3b38c2bb890138c2d42033000a','zh_CN','否',NULL,'2012-07-27 17:26:53','1','2012-07-26 18:27:58','1','0:0:0:0:0:0:0:1','0'),('40288a6938c7b3d40138c7bacf760009','40288a6938c7b3d40138c7bacf760008','zh_CN','领导的秘书是',NULL,'2012-08-11 18:34:57','1','2012-07-27 17:18:25','1','127.0.0.1','0'),('40288a6938c8453b0138c85317310007','40288a6938c8453b0138c85317310006','zh_CN','领导的行政助理是',NULL,'2012-08-11 18:34:57','1','2012-07-27 20:04:44','1','127.0.0.1','0'),('40288ace39538b830139539568790013','40288ace39538b830139539568790012','zh_CN','true',NULL,'2012-08-23 21:04:24','1','2012-08-23 21:04:24','1','0:0:0:0:0:0:0:1','0'),('40288ace39538b8301395395688c0015','40288ace39538b8301395395688c0014','zh_CN','false',NULL,'2012-08-23 21:04:24','1','2012-08-23 21:04:24','1','0:0:0:0:0:0:0:1','0'),('40288af9386fe46a0138702a39810003','40288af9386fe46a0138702a39800002','zh_CN','汉族',NULL,'2012-07-10 17:13:31','1','2012-07-10 17:13:31','1','0:0:0:0:0:0:0:1','0'),('40288af9386fe46a0138702a39980005','40288af9386fe46a0138702a39970004','zh_CN','回族',NULL,'2012-07-10 17:13:31','1','2012-07-10 17:13:31','1','0:0:0:0:0:0:0:1','0'),('40288af938761d0f0138762402ce0002','40288af938761d0f0138762402cd0001','zh_CN','研究生',NULL,'2013-04-08 10:56:16','1','2012-07-11 21:04:27','1','0:0:0:0:0:0:0:1','0'),('40288af938761d0f0138762403040004','40288af938761d0f0138762402ff0003','zh_CN','本科',NULL,'2013-04-08 10:56:16','1','2012-07-11 21:04:27','1','0:0:0:0:0:0:0:1','0'),('40288afa3811e31b013811e36f420003','40288afa3811e31b013811e36f420002','zh_CN','中国','中国','2012-06-22 09:51:54','1','2012-06-22 09:51:54','1','127.0.0.1','0'),('40288afa3813080601381308071b0001','40288afa381308060138130806e30000','zh_CN','美国','美国','2012-06-22 15:11:29','1','2012-06-22 15:11:29','1','0:0:0:0:0:0:0:1','0'),('40288afb387038050138703b06560004','40288afb387038050138703b06550003','zh_CN','系统角色',NULL,'2012-07-10 17:31:52','1','2012-07-10 17:31:52','1','127.0.0.1','0'),('40288afb387038050138703b06760006','40288afb387038050138703b06750005','zh_CN','用户角色',NULL,'2012-07-10 17:31:52','1','2012-07-10 17:31:52','1','127.0.0.1','0'),('40288afb3870380501387049949d0010','40288afb3870380501387049949c000f','zh_CN','有效',NULL,'2012-07-10 17:47:46','1','2012-07-10 17:47:46','1','127.0.0.1','0'),('40288afb387038050138704994ab0012','40288afb387038050138704994ab0011','zh_CN','无效',NULL,'2014-03-20 15:02:32','1','2012-07-10 17:47:46','1','0:0:0:0:0:0:0:1','0'),('40288afb389e322901389e87188f0017','40288afb389e322901389e87188f0016','zh_CN','第一组',NULL,'2012-07-19 17:17:30','1','2012-07-19 17:17:30','1','127.0.0.1','0'),('40288afb389e322901389e8718a40019','40288afb389e322901389e8718a40018','zh_CN','第二组',NULL,'2012-07-19 17:17:30','1','2012-07-19 17:17:30','1','127.0.0.1','0'),('40288afb389e322901389e8718b2001b','40288afb389e322901389e8718b2001a','zh_CN','第三组',NULL,'2012-07-19 17:17:30','1','2012-07-19 17:17:30','1','127.0.0.1','0'),('40288afb38c1650d0138c1704e06000b','40288afb38c1650d0138c1704e06000a','zh_CN','系统用户',NULL,'2015-03-04 16:19:17','1','2012-07-26 11:59:19','1','10.216.43.205','0'),('40288afb38c1650d0138c1704e23000d','40288afb38c1650d0138c1704e23000c','zh_CN','自定义用户',NULL,'2015-03-04 16:19:17','1','2012-07-26 11:59:19','1','10.216.43.205','0'),('8a58a6b43e832d5a013e83487c220013','8a58a6b43e832d5a013e83487c220012','zh_CN','停止',NULL,'2013-05-08 16:36:05','1','2013-05-08 16:36:05','1','10.216.43.171','0'),('8a58a6b43e832d5a013e83487ca00017','8a58a6b43e832d5a013e83487ca00016','zh_CN','启用',NULL,'2013-05-08 16:36:05','1','2013-05-08 16:36:05','1','10.216.43.171','0'),('8a58a6b54faab7eb014fab78ab4f0ac1','8a58a6b54faab7eb014fab78ab380ac0','zh_CN','未读',NULL,'2015-09-08 13:40:56','1','2015-09-08 13:40:56','1','10.216.77.195','0'),('8a58a6b54faab7eb014fab78ab680ac3','8a58a6b54faab7eb014fab78ab620ac2','zh_CN','已读',NULL,'2015-09-08 13:40:56','1','2015-09-08 13:40:56','1','10.216.77.195','0'),('8a58ab2e3de781a7013de79295010013','8a58ab2e3de781a7013de79295010012','zh_CN','高中',NULL,'2015-05-15 11:21:01','1','2013-04-08 10:56:16','1','127.0.0.1','1'),('8a58ab2e3de781a7013de7958d490024','8a58ab2e3de781a7013de7958d490023','zh_CN','群众','群众','2013-04-08 10:59:30','1','2013-04-08 10:59:30','1','0:0:0:0:0:0:0:1','0'),('8a58ab2e3de781a7013de7958d5d0028','8a58ab2e3de781a7013de7958d5d0027','zh_CN','其它','其它','2013-04-08 10:59:30','1','2013-04-08 10:59:30','1','0:0:0:0:0:0:0:1','0'),('8a58ab2e3df1d260013df1dc2e3a0013','8a58ab2e3df1d260013df1dc2e3a0012','zh_CN','正常','正常','2013-04-10 10:52:51','1','2013-04-10 10:52:51','1','0:0:0:0:0:0:0:1','0'),('8a58ab2e3df1d260013df1dc2e7f0017','8a58ab2e3df1d260013df1dc2e7f0016','zh_CN','无效','无效','2013-04-10 10:52:51','1','2013-04-10 10:52:51','1','0:0:0:0:0:0:0:1','0'),('8a58ab2e3df28e91013df2905f670008','8a58ab2e3df28e91013df2905f670007','zh_CN','启用','启用','2013-04-10 14:09:40','1','2013-04-10 14:09:40','1','0:0:0:0:0:0:0:1','0'),('8a58ab2e3df28e91013df2905f8c000c','8a58ab2e3df28e91013df2905f8c000b','zh_CN','停用','停用','2013-04-10 14:09:40','1','2013-04-10 14:09:40','1','0:0:0:0:0:0:0:1','0'),('8a58ab393ff47bc1013ff47ec7700004','8a58ab393ff47bc1013ff47ec7700003','zh_CN','第四组',NULL,'2013-07-19 09:15:16','1','2013-07-19 09:15:16','1','0:0:0:0:0:0:0:1','0'),('8a58ab393ff47bc1013ff47ec8410008','8a58ab393ff47bc1013ff47ec8410007','zh_CN','第五组',NULL,'2013-07-19 09:15:16','1','2013-07-19 09:15:16','1','0:0:0:0:0:0:0:1','0'),('8a58ab394129d1e8014129e9b43f0011','8a58ab394129d1e8014129e9b43f0010','zh_CN','业务组','业务组','2013-09-17 11:14:43','1','2013-09-17 11:14:43','1','0:0:0:0:0:0:0:1','0'),('8a58ab394129d1e8014129e9b4630015','8a58ab394129d1e8014129e9b4630014','zh_CN','业务实体','业务实体','2013-09-17 11:14:43','1','2013-09-17 11:14:43','1','0:0:0:0:0:0:0:1','0'),('8a58ab3b4144266d0141442a42c30008','8a58ab3b4144266d0141442a42c30007','zh_CN','有效',NULL,'2013-09-22 13:35:22','1','2013-09-22 13:35:22','1','127.0.0.1','0'),('8a58ab3b4144266d0141442a42fd000c','8a58ab3b4144266d0141442a42fd000b','zh_CN','无效',NULL,'2013-09-22 13:35:22','1','2013-09-22 13:35:22','1','127.0.0.1','0'),('8a58ab3f3df30996013df32b7826000e','8a58ab3f3df30996013df32b7826000d','zh_CN','启用','启用','2013-04-10 16:59:05','1','2013-04-10 16:59:05','1','0:0:0:0:0:0:0:1','0'),('8a58ab3f3df30996013df32b783d0012','8a58ab3f3df30996013df32b783d0011','zh_CN','禁用','禁用','2013-04-10 16:59:05','1','2013-04-10 16:59:05','1','0:0:0:0:0:0:0:1','0'),('8a58ab473b8e50d9013b8e540ae60007','8a58ab473b8e50d9013b8e540ae60006','zh_CN','人员','人员','2012-12-13 11:10:06','1','2012-12-12 16:56:10','1','127.0.0.1','0'),('8a58ab473b9239fd013b923d90d40005','8a58ab473b9239fd013b923d90d40004','zh_CN','部门','部门','2012-12-13 11:10:06','1','2012-12-13 11:10:06','1','127.0.0.1','0'),('8a58ab473b9239fd013b923d90f70009','8a58ab473b9239fd013b923d90f70008','zh_CN','日期','日期','2012-12-13 11:10:06','1','2012-12-13 11:10:06','1','127.0.0.1','0'),('8a58ab473b9239fd013b923d910d000d','8a58ab473b9239fd013b923d910d000c','zh_CN','时间','时间','2012-12-13 11:10:06','1','2012-12-13 11:10:06','1','127.0.0.1','0'),('8a58ab473b9239fd013b923d91250011','8a58ab473b9239fd013b923d91250010','zh_CN','意见','意见','2012-12-13 11:10:06','1','2012-12-13 11:10:06','1','127.0.0.1','0'),('8a58ab473b933866013b9345823d0003','8a58ab473b933866013b9345823d0002','zh_CN','select',NULL,'2012-12-13 15:58:24','1','2012-12-13 15:58:24','1','127.0.0.1','0'),('8a58ab4d4c2c48e3014c2c4af2ce000c','8a58ab4d4c2c48e3014c2c4af2b5000b','zh_CN','公共使用',NULL,'2015-03-18 17:50:51','1','2015-03-18 17:50:51','1','127.0.0.1','0'),('8a58ab4d4c45da24014c45e0ce210086','8a58ab4d4c45da24014c45e0ce110085','zh_CN','蓝色',NULL,'2015-03-23 17:05:03','1','2015-03-23 17:05:03','1','127.0.0.1','0'),('8a58ab574c7e3591014c7e369a8c0004','8a58ab574c7e3591014c7e369a790003','zh_CN','灰色',NULL,'2015-04-03 15:37:30','1','2015-04-03 15:37:30','1','127.0.0.1','0'),('8a58ab574c7e3591014c7e3c45b50008','8a58ab574c7e3591014c7e3c45b00007','zh_CN','私有使用',NULL,'2015-04-03 15:43:41','1','2015-04-03 15:43:41','1','127.0.0.1','0'),('8a58abce3b91d7f0013b91e3e4a2000c','8a58abce3b91d7f0013b91e3e4a2000b','zh_CN','IP点','IP点','2012-12-13 09:32:09','1','2012-12-13 09:32:09','1','0:0:0:0:0:0:0:1','0'),('8a58abce3b91d7f0013b91e3e4c10010','8a58abce3b91d7f0013b91e3e4c1000f','zh_CN','IP段','IP段','2012-12-13 09:32:09','1','2012-12-13 09:32:09','1','0:0:0:0:0:0:0:1','0'),('8a58abce3b91d7f0013b91e515770018','8a58abce3b91d7f0013b91e515770017','zh_CN','用户可访问','用户可访问','2012-12-13 09:33:27','1','2012-12-13 09:33:27','1','0:0:0:0:0:0:0:1','0'),('8a58abce3b91d7f0013b91e51586001c','8a58abce3b91d7f0013b91e51586001b','zh_CN','禁止用户访问','禁止用户访问','2012-12-13 09:33:27','1','2012-12-13 09:33:27','1','0:0:0:0:0:0:0:1','0'),('8a58abf63e68080f013e680c8d1d0006','8a58abf63e63d8ac013e643688bc0038','zh_CN','启用','启用','2013-05-03 09:40:53','1','2013-05-03 09:40:53','1','0:0:0:0:0:0:0:1','0'),('8a58abf63e68080f013e680ce6f20007','8a58abf63e63d8ac013e643688db003c','zh_CN','禁用','禁用','2013-05-03 09:41:16','1','2013-05-03 09:41:16','1','0:0:0:0:0:0:0:1','0'),('8a58abf63e68080f013e680d50bb0008','8a58abf63e63d8ac013e6421cc04002a','zh_CN','有',NULL,'2013-05-03 09:41:43','1','2013-05-03 09:41:43','1','0:0:0:0:0:0:0:1','0'),('8a58abf63e68080f013e680d8d4a0009','8a58abf63e63d8ac013e6421cc15002e','zh_CN','无',NULL,'2013-05-03 09:41:58','1','2013-05-03 09:41:58','1','0:0:0:0:0:0:0:1','0'),('8a58abf63e68080f013e680de249000a','8a58abf63e63d8ac013e64182f0f001a','zh_CN','显示',NULL,'2013-05-03 09:42:20','1','2013-05-03 09:42:20','1','0:0:0:0:0:0:0:1','0'),('8a58abf63e68080f013e680e414b000b','8a58abf63e63d8ac013e64182f2f001e','zh_CN','隐藏',NULL,'2013-05-03 09:42:44','1','2013-05-03 09:42:44','1','0:0:0:0:0:0:0:1','0'),('8a58abf63e68080f013e680f3957000e','8a58abf63e6328e6013e633c43b00052','zh_CN','功能菜单',NULL,'2013-05-03 09:43:48','1','2013-05-03 09:43:48','1','0:0:0:0:0:0:0:1','0'),('8a58abf63e68080f013e680f7bf7000f','8a58abf63e6328e6013e633c43ee0056','zh_CN','门户小页',NULL,'2013-05-03 09:44:05','1','2013-05-03 09:44:05','1','0:0:0:0:0:0:0:1','0'),('8a58c8434d468f93014d46ba5de900dd','8a58c8434d468f93014d46ba5ddd00dc','zh_CN','第六组',NULL,'2015-05-12 14:05:28','1','2015-05-12 14:05:28','1','127.0.0.1','0'),('8a58c8434d468f93014d46ba5dfc00e1','8a58c8434d468f93014d46ba5df700e0','zh_CN','第七组',NULL,'2015-05-12 14:05:28','1','2015-05-12 14:05:28','1','127.0.0.1','0'),('8a58cd574d5b89ad014d5b90387f004b','8a58cd574d5b89ad014d5b903871004a','zh_CN','个人群组',NULL,'2015-05-16 15:11:27','1','2015-05-16 15:11:27','1','127.0.0.1','0'),('8a58cd574d5b89ad014d5b903890004f','8a58cd574d5b89ad014d5b90388d004e','zh_CN','系统群组',NULL,'2015-05-16 15:11:27','1','2015-05-16 15:11:27','1','127.0.0.1','0'),('8a58cd5750180ec8015018146100004f','8a58cd5750180ec80150181460d9004e','zh_CN','OA蓝',NULL,'2016-03-08 10:51:44','1','2015-09-29 15:50:00','1','127.0.0.1','1'),('8a58cd57515b12c301515b43bc36015b','8a58cd57515b12c301515b43bbfc015a','zh_CN','语言','语言','2016-03-14 10:42:46','1','2012-08-16 13:46:15','1','127.0.0.1','5'),('8a58cd575354173501535423e72c0055','8a58cd575354173501535423e7240054','zh_CN','天蓝',NULL,'2016-03-08 10:52:32','1','2016-03-08 10:52:32','1','127.0.0.1','0'),('8a58cd5753541735015354318516005e','8a58cd575354173501535431850c005d','zh_CN','手风琴','static/images/platform/syscustomed/accordionMenu.jpg','2016-03-08 11:07:24','1','2016-03-08 11:07:24','1','127.0.0.1','0'),('8a58cd605654778a01565482a97200ee','8a58cd605654778a01565482a96600ed','zh_CN','绿色',NULL,'2016-08-04 15:44:24','1','2016-08-04 15:44:24','1','127.0.0.1','0');

/*Table structure for table `sys_lookup_type` */

DROP TABLE IF EXISTS `sys_lookup_type`;

CREATE TABLE `sys_lookup_type` (
  `ID` varchar(50) NOT NULL COMMENT '唯一标识',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '应用ID',
  `LOOKUP_TYPE` varchar(50) DEFAULT NULL COMMENT '代码类型',
  `SYSTEM_FLAG` varchar(1) DEFAULT NULL COMMENT '是否为系统初始\r\nY 是 N 否',
  `VALID_FLAG` varchar(1) DEFAULT NULL COMMENT '是否有效\r\n1代表有效,0代表无效 默认为1',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `BELONG_MODULE` varchar(50) DEFAULT NULL COMMENT '所属模块',
  `USAGE_MODIFIER` varchar(1) DEFAULT NULL COMMENT '0 公有可用     1私有可用',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='通用代码类型表';

/*Data for the table `sys_lookup_type` */

insert  into `sys_lookup_type` values ('2c9ba38154dc5c6a0154dc7a004e01bc','1','PLATFORM_EFORM_VALIDATE','1','1','2016-05-23 15:17:44','1','2016-05-23 15:17:44','1','0:0:0:0:0:0:0:1','0',NULL,'0'),('402809814eb01b2c014eb02d551600f0','1','PLATFORM_CODING_CRITERION_LEVEL','0','1','2015-10-09 14:01:17','1','2015-07-21 18:33:57','1','127.0.0.1','9',NULL,'0'),('40288a1538e20d320138e20d32450000','1','PLATFORM_MENU_STYLE','0','1','2012-08-01 19:58:32','1','2012-08-01 19:58:32','1','0:0:0:0:0:0:0:1','0',NULL,'0'),('40288a34392d730601392df526370004','1','PLATFORM_PORTAL_ITEMS','0','1','2012-08-16 14:06:14','1','2012-08-16 13:43:24','1','0:0:0:0:0:0:0:1','0',NULL,'0'),('40288a3b38576e590138576e590f0000','1','PLATFORM_VALID_FLAG','0','1','2012-07-12 20:46:38','1','2012-07-05 21:57:25','1','192.168.10.93','0',NULL,'0'),('40288a3b38578f0f01385792df300002','1','PLATFORM_FOLK','0','1','2012-07-11 16:10:45','1','2012-07-05 22:37:19','1','0:0:0:0:0:0:0:1','0',NULL,'0'),('40288a3b38578f0f0138579409520008','1','PLATFORM_POLITICAL','0','1','2012-07-11 16:10:45','1','2012-07-05 22:38:35','1','0:0:0:0:0:0:0:1','0',NULL,'0'),('40288a3b3873c2c2013875158fb00008','1','PLATFORM_USER_SECRET_LEVEL','0','1','2012-07-11 16:09:03','1','2012-07-11 16:09:03','1','0:0:0:0:0:0:0:1','0',NULL,'0'),('40288a3b3873c2c20138751b361d0012','1','PLATFORM_FILE_SECRET_LEVEL','0','1','2012-07-11 16:15:13','1','2012-07-11 16:15:13','1','0:0:0:0:0:0:0:1','0',NULL,'0'),('40288a3b38c274470138c27b62860002','1','PLATFORM_SYSTEM_FLAG','0','1','2012-07-26 16:51:56','1','2012-07-26 16:51:02','1','0:0:0:0:0:0:0:1','0',NULL,'0'),('40288a3b38c2bb890138c2d41fbd0006','1','PLATFORM_YES_NO_FLAG','0','1','2012-07-26 18:28:06','1','2012-07-26 18:27:58','1','0:0:0:0:0:0:0:1','0',NULL,'0'),('40288a6938c7b3d40138c7bacf460006','1','PLATFORM_SYS_USER_RELATION_TYPE','0','1','2012-08-11 18:34:57','1','2012-07-27 17:18:25','1','127.0.0.1','0',NULL,'0'),('40288ace39538b830139539503300010','1','PLATFORM_SYSTEM_BOOLEAN_FLAG','0','1','2012-08-23 21:05:08','1','2012-08-23 21:03:58','1','0:0:0:0:0:0:0:1','0',NULL,'0'),('40288af9385c33b601385c8898600007','1','PLATFORM_DEGREE','0','1','2012-07-11 16:11:05','1','2012-07-06 21:44:12','1','0:0:0:0:0:0:0:1','0',NULL,'0'),('40288afa380ece0201380ed4f81b000f','1','PLATFORM_SEX','0','1','2012-07-11 16:11:14','1','2012-06-21 19:37:14','1','0:0:0:0:0:0:0:1','0',NULL,'0'),('40288afa3811e31b013811e31b290000','1','PLATFORM_NATION','0','1','2012-07-11 16:10:30','1','2012-06-22 09:51:32','1','0:0:0:0:0:0:0:1','0',NULL,'0'),('40288afb387038050138703a01750001','1','PLATFORM_SYS_ROLETYPE','0','1','2012-07-21 12:04:17','1','2012-07-10 17:30:46','1','0:0:0:0:0:0:0:1','0',NULL,'0'),('40288afb387038050138704888c6000d','1','PLATFORM_USER_STATUS','0','1','2012-07-12 11:31:53','1','2012-07-10 17:46:38','1','0:0:0:0:0:0:0:1','0',NULL,'0'),('40288afb389e322901389e8718680014','1','PLATFORM_MENU_GROUP','0','1','2012-07-19 17:17:30','1','2012-07-19 17:17:30','1','127.0.0.1','0',NULL,'0'),('40288afb38c101240138c15be182001c','1','PLATFORM_USER_TYPE','0','1','2012-07-26 11:37:00','1','2012-07-26 11:37:00','1','127.0.0.1','0',NULL,'0'),('8a58a6b43e832d5a013e834814f6000e','1','PLATFORM_SYNC_TASK_STATE','0','1','2013-05-08 16:35:39','1','2013-05-08 16:35:39','1','10.216.43.171','0',NULL,'0'),('8a58a6b54faab7eb014fab7815710abc','1','PLATFORM_MESSAGE_READFLAG','0','1','2015-10-09 14:01:06','1','2015-09-08 13:40:18','1','127.0.0.1','1',NULL,'0'),('8a58ab2e3df1d260013df1dc2dc4000e','1','PLATFORM_APPLICATION_STATE','0','1','2013-04-10 10:52:51','1','2013-04-10 10:52:51','1','0:0:0:0:0:0:0:1','0',NULL,'0'),('8a58ab2e3df28e91013df2905f2e0003','1','PLATFORM_SYS_TEMPLATE_STATE','0','1','2013-04-10 14:09:40','1','2013-04-10 14:09:40','1','0:0:0:0:0:0:0:1','0',NULL,'0'),('8a58ab394129d1e8014129e9b38f000c','1','PLATFORM_DEPT_TYPE','0','1','2013-09-17 11:14:43','1','2013-09-17 11:14:43','1','0:0:0:0:0:0:0:1','0',NULL,'0'),('8a58ab3b4144266d0141442a42670003','1','PLATFORM_DATA_PERMI_STATUS','0','1','2015-03-04 14:30:15','1','2013-09-22 13:35:22','1','10.216.43.205','0',NULL,'0'),('8a58ab3f3df30996013df32b77e50009','1','PLATFORM_SYSMENU_STATE','0','1','2014-12-03 11:22:21','1','2013-04-10 16:59:05','1','127.0.0.1','0',NULL,'0'),('8a58ab473b8e50d9013b8e540a7f0002','1','PLATFORM_SYS_IDEA_STYLE','0','1','2012-12-12 16:56:10','1','2012-12-12 16:56:10','1','127.0.0.1','0',NULL,'0'),('8a58ab4d4c2c48e3014c2c4a69b60007','1','PLATFORM_USAGE_MODIFIER','0','1','2015-05-11 10:52:46','1','2015-03-18 17:50:16','1','127.0.0.1','2',NULL,'0'),('8a58ab4d4c45da24014c45df9a0d0081','1','PLATFORM_SYSTEM_SKIN','0','1','2015-03-23 17:03:44','1','2015-03-23 17:03:44','1','127.0.0.1','0',NULL,'0'),('8a58abce3b91d7f0013b91e3e4640007','1','PLATFORM_USER_LIMIT_IP_TYPE','0','1','2013-04-18 16:00:20','1','2012-12-13 09:32:09','1','0:0:0:0:0:0:0:1','0',NULL,'0'),('8a58abce3b91d7f0013b91e515480013','1','PLATFORM_USER_LIMTI_TYPE','0','1','2012-12-13 09:33:27','1','2012-12-13 09:33:27','1','0:0:0:0:0:0:0:1','0',NULL,'0'),('8a58abf63e6328e6013e633c4333004e','1','PLATFORM_MENU_TYPE','0','1','2013-05-02 11:14:53','1','2013-05-02 11:14:53','1','0:0:0:0:0:0:0:1','0',NULL,'0'),('8a58abf63e63d8ac013e6415b493000e','1','PLATFORM_PORTALPAGE_SCROLLSTATUS','0','1','2013-05-02 15:12:24','1','2013-05-02 15:12:24','1','127.0.0.1','0',NULL,'0'),('8a58abf63e63d8ac013e6415b4e20016','1','PLATFORM_PORTALPAGE_SHOWSTATUS','0','1','2013-05-02 15:12:24','1','2013-05-02 15:12:24','1','127.0.0.1','0',NULL,'0'),('8a58abf63e63d8ac013e6436887d0034','1','PLATFORM_MENU_ACTIVESTATUS','0','1','2013-05-02 15:51:30','1','2013-05-02 15:48:15','1','127.0.0.1','0',NULL,'0'),('8a58cd574d5b89ad014d5b8fb4360046','1','PLATFORM_GROUP_TYPE','0','1','2015-05-16 15:10:54','1','2015-05-16 15:10:54','1','127.0.0.1','0',NULL,'0');

/*Table structure for table `sys_lookup_type_tl` */

DROP TABLE IF EXISTS `sys_lookup_type_tl`;

CREATE TABLE `sys_lookup_type_tl` (
  `ID` varchar(50) NOT NULL COMMENT '唯一标识',
  `SYS_LOOKUP_TYPE_ID` varchar(50) DEFAULT NULL COMMENT 'SYS_LOOKUP_TYPE_Id value',
  `SYS_LANGUAGE_CODE` varchar(50) DEFAULT NULL COMMENT '语言代码\r\n对应SYS_LANGUAGE表中获LANGUAGE_CODE的值',
  `LOOKUP_TYPE_NAME` varchar(100) DEFAULT NULL COMMENT '代码名称',
  `DESCRIPTION` varchar(240) DEFAULT NULL COMMENT '描述',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='通用代码类型多语言表';

/*Data for the table `sys_lookup_type_tl` */

insert  into `sys_lookup_type_tl` values ('2c9ba38154dc5c6a0154dc7a004e01bd','2c9ba38154dc5c6a0154dc7a004e01bc','zh_CN','电子表单验证类型',NULL,'2016-05-23 15:17:43','1','2016-05-23 15:17:43','1','0:0:0:0:0:0:0:1','0'),('402809814eb01b2c014eb02d551600f1','402809814eb01b2c014eb02d551600f0','zh_CN','编码体系-标准级别','编码体系标准','2015-10-09 14:01:17','1','2015-07-21 18:33:57','1','127.0.0.1','9'),('40288a1538e20d320138e20d325b0001','40288a1538e20d320138e20d32450000','zh_CN','系统首页登陆后菜单风格','系统首页登陆后菜单风格','2012-08-01 19:58:32','1','2012-08-01 19:58:32','1','0:0:0:0:0:0:0:1','0'),('40288a34392d730601392df526530005','40288a34392d730601392df526370004','zh_CN','平台登陆后显示条目','平台登陆后显示条目','2012-08-16 14:06:14','1','2012-08-16 13:43:24','1','0:0:0:0:0:0:0:1','0'),('40288a3b38576e590138576e591f0001','40288a3b38576e590138576e590f0000','zh_CN','有效标识','1代表有效，0代表无效','2012-07-12 20:46:38','1','2012-07-05 21:57:25','1','192.168.10.93','0'),('40288a3b38578f0f01385792df310003','40288a3b38578f0f01385792df300002','zh_CN','民族','56个民族','2012-07-11 16:10:45','1','2012-07-05 22:37:19','1','0:0:0:0:0:0:0:1','0'),('40288a3b38578f0f0138579409520009','40288a3b38578f0f0138579409520008','zh_CN','政治面貌','政治面貌','2012-07-11 16:10:45','1','2012-07-05 22:38:35','1','0:0:0:0:0:0:0:1','0'),('40288a3b3873c2c2013875158fb10009','40288a3b3873c2c2013875158fb00008','zh_CN','企业划分人员密级','企业划分人员密级','2012-07-11 16:09:03','1','2012-07-11 16:09:03','1','0:0:0:0:0:0:0:1','0'),('40288a3b3873c2c20138751b361f0013','40288a3b3873c2c20138751b361d0012','zh_CN','文档密级','文档密级','2012-07-11 16:15:13','1','2012-07-11 16:15:13','1','0:0:0:0:0:0:0:1','0'),('40288a3b38c274470138c27b62980003','40288a3b38c274470138c27b62860002','zh_CN','是否系统初始值','是否系统初始值','2012-07-26 16:51:56','1','2012-07-26 16:51:02','1','0:0:0:0:0:0:0:1','0'),('40288a3b38c2bb890138c2d41fcf0007','40288a3b38c2bb890138c2d41fbd0006','zh_CN','是否','平台公用的是否标识','2012-07-26 18:28:06','1','2012-07-26 18:27:58','1','0:0:0:0:0:0:0:1','0'),('40288a6938c7b3d40138c7bacf660007','40288a6938c7b3d40138c7bacf460006','zh_CN','用户关系类型','用户间的关系，如：领导和秘书','2012-08-11 18:34:57','1','2012-07-27 17:18:25','1','127.0.0.1','0'),('40288ace39538b830139539503550011','40288ace39538b830139539503300010','zh_CN','是否为true与false','是否为true与false','2012-08-23 21:05:08','1','2012-08-23 21:03:58','1','0:0:0:0:0:0:0:1','0'),('40288af9385c33b601385c8898610008','40288af9385c33b601385c8898600007','zh_CN','学历','学历','2012-07-11 16:11:05','1','2012-07-06 21:44:12','1','0:0:0:0:0:0:0:1','0'),('40288afa380ece0201380ed4f81b000e','40288afa380ece0201380ed4f81b000f','zh_CN','性别','性别 0表示男，1表示女','2012-07-11 16:11:14','1','2012-06-21 19:37:14','1','0:0:0:0:0:0:0:1','0'),('40288afa3811e31b013811e31b580001','40288afa3811e31b013811e31b290000','zh_CN','国籍','国籍','2012-07-11 16:10:30','1','2012-06-22 09:51:32','1','0:0:0:0:0:0:0:1','0'),('40288afb387038050138703a01760002','40288afb387038050138703a01750001','zh_CN','角色类型','角色类型','2012-07-21 12:04:17','1','2012-07-10 17:30:46','1','0:0:0:0:0:0:0:1','0'),('40288afb387038050138704888c6000e','40288afb387038050138704888c6000d','zh_CN','用户状态','用户状态','2012-07-12 11:31:53','1','2012-07-10 17:46:38','1','0:0:0:0:0:0:0:1','0'),('40288afb389e322901389e8718750015','40288afb389e322901389e8718680014','zh_CN','菜单组','菜单组','2012-07-19 17:17:30','1','2012-07-19 17:17:30','1','127.0.0.1','0'),('40288afb38c101240138c15be196001d','40288afb38c101240138c15be182001c','zh_CN','用户类型','用户类型','2012-07-26 11:37:00','1','2012-07-26 11:37:00','1','127.0.0.1','0'),('8a58a6b43e832d5a013e83481525000f','8a58a6b43e832d5a013e834814f6000e','zh_CN','任务调度开关状态','任务调度开关状态','2013-05-08 16:35:39','1','2013-05-08 16:35:39','1','10.216.43.171','0'),('8a58a6b54faab7eb014fab7815710abd','8a58a6b54faab7eb014fab7815710abc','zh_CN','消息是否已读','消息是否阅读','2015-10-09 14:01:06','1','2015-09-08 13:40:17','1','127.0.0.1','1'),('8a58ab2e3df1d260013df1dc2deb000f','8a58ab2e3df1d260013df1dc2dc4000e','zh_CN','平台多应用状态','平台多应用状态','2013-04-10 10:52:51','1','2013-04-10 10:52:51','1','0:0:0:0:0:0:0:1','0'),('8a58ab2e3df28e91013df2905f430004','8a58ab2e3df28e91013df2905f2e0003','zh_CN','平台密码规则管理是否启用','平台密码规则管理是否启用','2013-04-10 14:09:40','1','2013-04-10 14:09:40','1','0:0:0:0:0:0:0:1','0'),('8a58ab394129d1e8014129e9b3a4000d','8a58ab394129d1e8014129e9b38f000c','zh_CN','部门类型','部门类型','2013-09-17 11:14:43','1','2013-09-17 11:14:43','1','0:0:0:0:0:0:0:1','0'),('8a58ab3b4144266d0141442a427f0004','8a58ab3b4144266d0141442a42670003','zh_CN','数据权限资源状态','数据权限资源状态','2015-03-04 14:30:15','1','2013-09-22 13:35:22','1','10.216.43.205','0'),('8a58ab3f3df30996013df32b7805000a','8a58ab3f3df30996013df32b77e50009','zh_CN','平台菜单管理状态','平台菜单状态','2014-12-03 11:22:21','1','2013-04-10 16:59:05','1','127.0.0.1','0'),('8a58ab473b8e50d9013b8e540a8d0003','8a58ab473b8e50d9013b8e540a7f0002','zh_CN','流程意见显示样式','流程意见显示样式','2012-12-12 16:56:10','1','2012-12-12 16:56:10','1','127.0.0.1','0'),('8a58ab4d4c2c48e3014c2c4a69b60008','8a58ab4d4c2c48e3014c2c4a69b60007','zh_CN','平台角色、代码、配置等使用的修饰符','0代表公共的所有系统可使用，1代表私有的仅本系统可使用','2015-05-11 10:52:46','1','2015-03-18 17:50:16','1','127.0.0.1','2'),('8a58ab4d4c45da24014c45df9a0d0082','8a58ab4d4c45da24014c45df9a0d0081','zh_CN','主题皮肤选项','主题皮肤选项','2015-03-23 17:03:44','1','2015-03-23 17:03:44','1','127.0.0.1','0'),('8a58abce3b91d7f0013b91e3e4830008','8a58abce3b91d7f0013b91e3e4640007','zh_CN','用户限制管理IP类型','用户限制管理IP类型','2012-12-13 09:32:09','1','2012-12-13 09:32:09','1','0:0:0:0:0:0:0:1','0'),('8a58abce3b91d7f0013b91e515570014','8a58abce3b91d7f0013b91e515480013','zh_CN','用户限制管理用户访问权限类型','用户限制管理用户访问权限类型','2012-12-13 09:33:27','1','2012-12-13 09:33:27','1','0:0:0:0:0:0:0:1','0'),('8a58abf63e6328e6013e633c4352004f','8a58abf63e6328e6013e633c4333004e','zh_CN','菜单类型','类型 1表示功能菜单 2表示门户小页','2013-05-02 11:14:53','1','2013-05-02 11:14:53','1','0:0:0:0:0:0:0:1','0'),('8a58abf63e63d8ac013e6415b4a3000f','8a58abf63e63d8ac013e6415b493000e','zh_CN','是否有滚动条','1表示有 0表示无','2013-05-02 15:12:24','1','2013-05-02 15:12:24','1','127.0.0.1','0'),('8a58abf63e63d8ac013e6415b4f20017','8a58abf63e63d8ac013e6415b4e20016','zh_CN','是否显示标题','1表示显示 0表示隐藏','2013-05-02 15:12:24','1','2013-05-02 15:12:24','1','127.0.0.1','0'),('8a58abf63e63d8ac013e6436888c0035','8a58abf63e63d8ac013e6436887d0034','zh_CN','菜单状态','1表示启用  0表示禁用','2013-05-02 15:51:30','1','2013-05-02 15:48:15','1','127.0.0.1','0'),('8a58cd574d5b89ad014d5b8fb4360047','8a58cd574d5b89ad014d5b8fb4360046','zh_CN','群组类型','平台群组类型','2015-05-16 15:10:54','1','2015-05-16 15:10:54','1','127.0.0.1','0');

/*Table structure for table `sys_menu` */

DROP TABLE IF EXISTS `sys_menu`;

CREATE TABLE `sys_menu` (
  `ID` varchar(50) NOT NULL COMMENT '唯一标识',
  `SYS_APPLICATION_ID` varchar(50) NOT NULL COMMENT '应用ID',
  `CODE` varchar(50) NOT NULL COMMENT '菜单CODE',
  `IMAGE` varchar(100) DEFAULT NULL COMMENT '图标引用地址',
  `URL` text COMMENT '路径',
  `PARENT_ID` varchar(50) NOT NULL COMMENT '父菜单',
  `ORDER_BY` decimal(16,0) DEFAULT NULL COMMENT '排序',
  `TYPE` varchar(1) DEFAULT NULL COMMENT '菜单类型  0  根节点，\r\n1功能菜单，\r\n2门户小页\r\n ',
  `CSS` text COMMENT '样式\r\n针对门户小页',
  `HEIGHT` varchar(50) DEFAULT NULL COMMENT '高度\r\n针对门户小页',
  `SCROLL` varchar(1) DEFAULT NULL COMMENT '是否有滚动条\r\n针对门户小页',
  `REFRESH` varchar(50) DEFAULT NULL COMMENT '刷新频率\r\n针对门户小页',
  `ISCLOSE` varchar(1) DEFAULT NULL COMMENT '是否有关闭按钮\r\n针对门户小页\r\n',
  `STATUS` varchar(1) DEFAULT NULL COMMENT '状态\r\n1启用，0禁用',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `MENU_GROUP` varchar(255) DEFAULT NULL COMMENT '菜单所属分组',
  `ISSHOWTITLE` varchar(1) DEFAULT NULL COMMENT '是否显示标题',
  `ISDRAG` varchar(1) DEFAULT NULL COMMENT '是否允许拖拽',
  `MOREURL` text COMMENT '其它跳转URL',
  `IS_ROBBIN` varchar(1) DEFAULT NULL,
  `MENU_VIEW` text,
  `ICON_CLASS` text COMMENT 'bootstrap图标',
  `ISMENU` varchar(1) DEFAULT NULL COMMENT '是否为菜单还是资源',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='菜单表';

/*Data for the table `sys_menu` */

insert  into `sys_menu` values ('1','1','1',NULL,NULL,'-1',NULL,'1',NULL,NULL,'0',NULL,'0','1','2015-03-05 13:26:06','1','2012-06-21 00:00:00','1','127.0.0.1','107',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,NULL,NULL,NULL,'1'),('402809814db30afe014db30c4e18008e','1','cc_root',NULL,NULL,'1','6','1',NULL,NULL,'0',NULL,'0','0','2016-03-14 13:23:05','1','2015-06-02 14:53:00','1','127.0.0.1','10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('402809814dff7814014dff92ebb900d6','1','cc_user','static/images/platform/sysmenu/icons.gif -100px -80px','platform/cc/sysuser/sysuserinfo','8a58cd574df6657e014df670084400d0','4','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:02:51','1','2015-06-17 11:32:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/centralcontrol/sysdept/sysuserList.jsp',NULL,'1'),('402809814dfff8d6014dfffa122d00cd','1','cc_sysorg','static/images/platform/sysmenu/icons.gif -20px -80px','platform/cc/sysorg/sysorginfo','8a58cd574df6657e014df670084400d0','1','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:02:32','1','2015-06-17 13:24:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/centralcontrol/sysorg/sysorg.jsp',NULL,'1'),('402809814dfff8d6014dfffad0c600d2','1','cc_sysposition','static/images/platform/sysmenu/icons.gif -280px -140px','platform/cc/sysposition/syspositioninfo','8a58cd574df6657e014df670084400d0','3','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:02:44','1','2015-06-17 13:25:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/centralcontrol/sysposition/sysposition.jsp',NULL,'1'),('402809814dfff8d6014dfffc115900dd','1','cc_sysgroup','static/images/platform/sysmenu/icons.gif -220px -80px','platform/cc/sysgroup/sysgroupinfo','8a58cd574df6657e014df670084400d0','6','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:03:03','1','2015-06-17 13:26:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/centralcontrol/sysgroup/sysgroup.jsp',NULL,'1'),('402809814dfff8d6014dfffc8d2300e2','1','cc_sysrole','static/images/platform/sysmenu/icons.gif -100px -60px','platform/cc/sysrole/sysroleinfo','8a58cd574df6657e014df670084400d0','7','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:03:10','1','2015-06-17 13:27:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/centralcontrol/sysrole/sysrole.jsp',NULL,'1'),('402809814dfff8d6014dffffee5200ea','1','cc_sys','static/images/platform/sysmenu/icons.gif -100px -40px',NULL,'402809814db30afe014db30c4e18008e','6','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:02:21','1','2015-06-17 13:31:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2','1','1',NULL,'0',NULL,NULL,'1'),('402809814dfff8d6014e000128e800f2','1','cc_sysmenu','static/images/platform/sysmenu/icons.gif -20px -100px','platform/cc/sysmenu/sysmenuinfo','402809814dfff8d6014dffffee5200ea','1','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 15:55:53','1','2015-06-17 13:32:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('402809814dfff8d6014e00026efb00f7','1','cc_sysprofile','static/images/platform/sysmenu/icons.gif -140px -60px','platform/cc/sysprofile/sysprofileinfo','402809814dfff8d6014dffffee5200ea','3','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:06:48','1','2015-06-17 13:33:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('402809814e0065ed014e006a7fae00cd','1','cc_userrelation','static/images/platform/sysmenu/icons.gif -20px -80px','platform/cc/userrelation/userrelationinfo','8a58cd574df6657e014df670084400d0','5','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:02:57','1','2015-06-17 15:27:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('402809814e0464bd014e0468318700ce','1','cc_application','static/images/platform/sysmenu/icons.gif -120px -80px','platform/cc/sysapp/sysappinfo','402809814dfff8d6014dffffee5200ea','7','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:07:14','1','2015-06-18 10:03:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('402809814e1f2ee8014e1f3223a200c6','1','cc_approle','static/images/platform/sysmenu/icons.gif -60px -160px','platform/cc/sysapprole/sysapproleinfo','402809814dfff8d6014dffffee5200ea','6','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:07:06','1','2015-06-23 14:54:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('402809814e472359014e4727572e00ca','1','cc_datapermission','static/images/platform/sysmenu/icons.gif -100px -80px','platform/cc/permissionresource/permissionresourceinfo','8a58cd5b4e3ce0ac014e3ce2bb1500ca','2','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:03:37','1','2015-07-01 09:07:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('402809814e51ecf1014e51f268c800cc','1','cc_crossdept','static/images/platform/sysmenu/icons.gif -120px -160px','platform/cc/crossdept/crossdeptinfo','8a58cd5b4e3ce0ac014e3ce2bb1500ca',NULL,'1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:06:12','1','2015-07-03 11:25:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('402809814f2a5144014f2ab7c74d0050','1','sys_coding','static/images/platform/sysmenu/icons.gif -20px -100px','avicit/platform6/modules/system/syscodingrule/sysCodingRuleManager.jsp','8a58c8434d468f93014d469b1dca001c','10','1',NULL,NULL,'0',NULL,'0','1','2015-08-14 16:44:28','1','2015-08-14 13:38:51','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('402809814f2a5144014f2ab893490055','1','sys_LookupHibearchy','static/images/platform/sysmenu/icons.gif -100px -100px','avicit/platform6/modules/system/syslookuphibearchy/sysLookupHibearchyManager.jsp','8a58c8434d468f93014d469b1dca001c',NULL,'1',NULL,NULL,'0',NULL,'0','1','2015-08-14 13:39:43','1','2015-08-14 13:39:43','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('40283f874f25ed9f014f2607b02200dc','1','cc_syscoding','static/images/platform/sysmenu/icons.gif -120px -80px','avicit/platform6/centralcontrol/syscodingrule/sysCodingRuleManager.jsp','402809814dfff8d6014dffffee5200ea','10','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:08:06','1','2015-08-13 15:48:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c275bab014c275fdd42000e','1','portal','static/images/platform/sysmenu/icons.gif -40px -20px',NULL,'1','0','2',NULL,NULL,'0',NULL,'0','1','2015-03-17 18:55:36','1','2015-03-17 18:55:36','1','10.216.43.205','110',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c275bab014c2762df17001d','1','myTaskList','static/images/platform/sysmenu/icons.gif -100px -80px','avicit/platform6/bpmclient/bpm/Todo.jsp','8a58a6b44c275bab014c275fdd42000e','0','2',NULL,NULL,'0',NULL,'0','1','2015-03-17 18:58:53','1','2015-03-17 18:58:53','1','10.216.43.205','110',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c275bab014c27648454002c','1','homePage','static/images/platform/sysmenu/icons.gif -0px -20px','avicit/platform6/modules/system/sysdashboard/indexPortlet.jsp','1','1','1',NULL,NULL,'0',NULL,'0','1','2015-03-17 19:00:41','1','2015-03-17 19:00:41','1','10.216.43.205','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c275bab014c2765ee040031','1','grsw',NULL,NULL,'1','2','1',NULL,NULL,'0',NULL,'0','1','2016-03-10 16:16:41','1','2015-03-17 19:02:13','1','127.0.0.1','110',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c275bab014c27675b0c0036','1','wdlc','static/images/platform/sysmenu/icons.gif -60px -20px','avicit/platform6/bpmclient/bpm/MyProcessInstanceList.jsp','8a58a6b44c275bab014c2765ee040031','0','1',NULL,NULL,'0',NULL,'0','1','2015-03-17 19:03:47','1','2015-03-17 19:03:47','1','10.216.43.205','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c275bab014c2767bd9c003b','1','wdgz','static/images/platform/sysmenu/icons.gif -40px -60px','avicit/platform6/bpmclient/bpm/ProcessWork.jsp','8a58a6b44c275bab014c2765ee040031','0','1',NULL,NULL,'0',NULL,'0','1','2015-03-17 19:04:12','1','2015-03-17 19:04:12','1','10.216.43.205','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c275bab014c2768570b0040','1','gzyj','static/images/platform/sysmenu/icons.gif -60px -60px','avicit/platform6/bpmclient/workhand/workhandlist.jsp','8a58a6b44c275bab014c2765ee040031','1','1',NULL,NULL,'0',NULL,'0','1','2015-03-17 19:04:51','1','2015-03-17 19:04:51','1','10.216.43.205','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c276a3f014c276b708c0003','1','sysusermgr',NULL,NULL,'1','5','1',NULL,NULL,'0',NULL,'0','1','2016-03-14 13:22:56','1','2015-03-17 19:08:14','1','127.0.0.1','109',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c276a3f014c276bcc2d0008','1','organddept','static/images/platform/sysmenu/icons.gif -200px -0px',NULL,'8a58a6b44c276a3f014c276b708c0003','1','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:46:23','1','2015-03-17 19:08:38','1','127.0.0.1','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c276a3f014c276e44d00018','1','sysOrg','static/images/platform/sysmenu/icons.gif -140px -60px','platform/sysorg/sysOrgController/toSysOrgList','8a58a6b44c276a3f014c276bcc2d0008','1','1',NULL,NULL,'0',NULL,'0','1','2015-04-10 15:37:02','1','2015-03-17 19:11:20','1','127.0.0.1','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/modules/system/sysorg/sysorg.jsp',NULL,'1'),('8a58a6b44c276a3f014c276ea970001d','1','sysDept','static/images/platform/sysmenu/icons.gif -20px -60px','platform//sysdept/sysDeptController/sysDeptInfo','8a58a6b44c276a3f014c276bcc2d0008','2','1',NULL,NULL,'0',NULL,'0','1','2015-04-10 15:40:57','1','2015-03-17 19:11:46','1','127.0.0.1','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/modules/system/sysdept/sysdept.jsp',NULL,'1'),('8a58a6b44c276a3f014c276f21ee0022','1','sysPosition','static/images/platform/sysmenu/icons.gif -260px -60px','platform/sysposition/sysPositionController/positionlistinfo','8a58a6b44c276a3f014c276bcc2d0008','3','1',NULL,NULL,'0',NULL,'0','1','2015-03-17 19:12:16','1','2015-03-17 19:12:16','1','10.216.43.205','107',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/modules/system/sysposition/sysposition.jsp',NULL,'1'),('8a58a6b44c276a3f014c276f9f1a0027','1','sysuser','static/images/platform/sysmenu/icons.gif -140px -100px','platform/sysuser/userlistinfo','8a58a6b44c276a3f014c276bcc2d0008','4','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:21:22','1','2015-03-17 19:12:48','1','127.0.0.1','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/modules/system/sysdept/sysuserList.jsp',NULL,'1'),('8a58a6b44c276a3f014c2a5b2a320040','1','customedSetting','static/images/platform/sysmenu/icons.gif -160px -180px','platform/syscustomed/sysCustomedController/toSyscustomed','8a58a6b44c276a3f014c276b708c0003','99','1',NULL,NULL,'0',NULL,'0','0','2015-05-12 14:12:09','1','2015-03-18 08:49:19','1','127.0.0.1','426',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/modules/system/syscustomed/syscustomed.jsp',NULL,'1'),('8a58a6b44c276a3f014c2a5f00fc0057','1','sysaccesscontrol','static/images/platform/sysmenu/icons.gif -200px -0px',NULL,'8a58a6b44c276a3f014c276b708c0003','2','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 14:13:23','1','2015-03-18 08:53:31','1','127.0.0.1','109',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c276a3f014c2a6076d10061','1','menuauthoritymanager','static/images/platform/sysmenu/icons.gif -260px -140px','platform/sysAccessControlController/menuAuthManager','8a58a6b44c276a3f014c2a5f00fc0057','1','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:48:23','1','2015-03-18 08:55:07','1','127.0.0.1','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/modules/system/sysaccesscontrol/menuAuthManager.jsp',NULL,'1'),('8a58a6b44c276a3f014c2a616bc70066','1','uniteAuthManager','static/images/platform/sysmenu/icons.gif -240px -140px','platform/securityControlController/toauthManager','8a58a6b44c276a3f014c2a5f00fc0057','2','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:48:29','1','2015-03-18 08:56:09','1','127.0.0.1','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/modules/system/sysaccesscontrol/authManager.jsp',NULL,'1'),('8a58a6b44c276a3f014c2a63ee62007a','1','sanyuanmanage','static/images/platform/sysmenu/icons.gif -200px -0px',NULL,'8a58a6b44c276a3f014c276b708c0003','5','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 14:27:27','1','2015-03-18 08:58:54','1','127.0.0.1','111',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'4','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c276a3f014c2a645456007f','1','syslog','static/images/platform/sysmenu/icons.gif -0px -180px','platform/syslog/sysloginfo','8a58a6b44c276a3f014c2a63ee62007a','1','1',NULL,NULL,'0',NULL,'0','1','2015-08-14 13:54:52','1','2015-03-18 08:59:20','1','127.0.0.1','110',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c276a3f014c2a652dd80089','1','syspasswordTemplate','static/images/platform/sysmenu/icons.gif -280px -60px','avicit/platform6/modules/system/syspasswordconfigure/syspasswordconfigure.jsp','8a58a6b44c276a3f014c2a63ee62007a','3','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:51:22','1','2015-03-18 09:00:16','1','127.0.0.1','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c276a3f014c2a6579c6008e','1','usrlimitmanager','static/images/platform/sysmenu/icons.gif -80px -160px','avicit/platform6/modules/system/sysuserlimitip/sysuserlimitip.jsp','8a58a6b44c276a3f014c2a63ee62007a','4','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:51:31','1','2015-03-18 09:00:35','1','127.0.0.1','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c276a3f014c2a66d819009b','1','workflowmanager','static/images/platform/sysmenu/icons.gif -200px -0px',NULL,'8a58a6b44c276a3f014c276b708c0003','4','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 14:27:18','1','2015-03-18 09:02:05','1','127.0.0.1','112',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'3','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c276a3f014c2a692d0800a0','1','lcywmlgl','static/images/platform/sysmenu/icons.gif -220px -0px','avicit/platform6/bpmconsole/publish/ProcessCatalogManage.jsp','8a58a6b44c276a3f014c2a66d819009b','1','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:59:00','1','2015-03-18 09:04:38','1','127.0.0.1','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c276a3f014c2a69888500a5','1','lcbdgl','static/images/platform/sysmenu/icons.gif -60px -40px','avicit/platform6/bpmconsole/publish/ProcessFormManage.jsp','8a58a6b44c276a3f014c2a66d819009b','2','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:59:07','1','2015-03-18 09:05:01','1','127.0.0.1','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c276a3f014c2a69e00100aa','1','zwmbgl','static/images/platform/sysmenu/icons.gif -40px -60px','avicit/platform6/bpmconsole/word/WordTempletManager.jsp','8a58a6b44c276a3f014c2a66d819009b','3','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:59:13','1','2015-03-18 09:05:23','1','127.0.0.1','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c276a3f014c2a6ac60200af','1','lcmbpzgl','static/images/platform/sysmenu/icons.gif -80px -140px','avicit/platform6/bpmconsole/publish/ProcessPublishManage.jsp','8a58a6b44c276a3f014c2a66d819009b','4','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:59:30','1','2015-03-18 09:06:22','1','127.0.0.1','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c276a3f014c2a6b0c9500b4','1','lcsljkgy','static/images/platform/sysmenu/icons.gif -60px -120px','avicit/platform6/bpmconsole/entry/ProcessEntryList.jsp','8a58a6b44c276a3f014c2a66d819009b','5','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:59:44','1','2015-03-18 09:06:40','1','127.0.0.1','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c276a3f014c2a73dfb700de','1','restmanage','static/images/platform/sysmenu/icons.gif -200px -0px',NULL,'8a58a6b44c276a3f014c276b708c0003','6','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 14:27:35','1','2015-03-18 09:16:19','1','127.0.0.1','112',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'4','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c276a3f014c2a7433c200e3','1','restorg','static/images/platform/sysmenu/icons.gif -160px -140px','platform/restmanage/org/index','8a58a6b44c276a3f014c2a73dfb700de','1','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:54:11','1','2015-03-18 09:16:40','1','127.0.0.1','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/modules/system/restmanage/org.jsp',NULL,'1'),('8a58a6b44c276a3f014c2a750edf00ee','1','restsystem','static/images/platform/sysmenu/icons.gif -180px -140px','platform/restmanage/system/index','8a58a6b44c276a3f014c2a73dfb700de','2','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:54:51','1','2015-03-18 09:17:36','1','127.0.0.1','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/modules/system/restmanage/system.jsp',NULL,'1'),('8a58a6b44c276a3f014c2a76550f00fd','1','restauth','static/images/platform/sysmenu/icons.gif -80px -20px','platform/restmanage/resources/index','8a58a6b44c276a3f014c2a73dfb700de','3','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:55:28','1','2015-03-18 09:19:00','1','127.0.0.1','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/modules/system/restmanage/resources.jsp',NULL,'1'),('8a58a6b44c276a3f014c2a76a9a90102','1','restuser','static/images/platform/sysmenu/icons.gif -240px -140px','platform/restmanage/auth/index','8a58a6b44c276a3f014c2a73dfb700de','4','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:56:06','1','2015-03-18 09:19:22','1','127.0.0.1','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/modules/system/restmanage/auth.jsp',NULL,'1'),('8a58a6b44c276a3f014c2a7e187b0107','1','searchmodule','static/images/platform/sysmenu/icons.gif -200px -0px',NULL,'8a58a6b44c276a3f014c276b708c0003','7','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 14:27:42','1','2015-03-18 09:27:29','1','127.0.0.1','112',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'4','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c276a3f014c2a7f2b2f010f','1','searchdb','static/images/platform/sysmenu/icons.gif -20px -160px','platform/search/connection/index.html','8a58a6b44c276a3f014c2a7e187b0107','1','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:57:42','1','2015-03-18 09:28:39','1','127.0.0.1','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b44c276a3f014c2a7fb1100117','1','searchindex','static/images/platform/sysmenu/icons.gif -80px -100px','platform/search/index.html','8a58a6b44c276a3f014c2a7e187b0107','2','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:58:05','1','2015-03-18 09:29:13','1','127.0.0.1','108',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b54f2b3339014f2b40c2680074','1','cc_syspasswordTemplate','static/images/platform/sysmenu/icons.gif -180px -60px','avicit/platform6/modules/system/syspasswordconfigure/syspasswordconfigure.jsp','8a58cd574e90f106014e90f1f69900da','2','1',NULL,NULL,'0',NULL,'0','1','2015-08-14 16:08:28','1','2015-08-14 16:08:28','1','10.216.77.215','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b54f2b3339014f2b45d2c50079','1','cc_usrlimitmanager','static/images/platform/sysmenu/icons.gif -60px -80px','avicit/platform6/modules/system/sysuserlimitip/sysuserlimitip.jsp','8a58cd574e90f106014e90f1f69900da','3','1',NULL,NULL,'0',NULL,'0','1','2015-08-14 16:14:00','1','2015-08-14 16:14:00','1','10.216.77.215','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58a6b54f4f35af014f4f38bdb9007c','1','cc_reloadcache','static/images/platform/sysmenu/icons.gif -220px -80px','avicit/platform6/modules/system/sysdashboard/reLoadCache.jsp','402809814dfff8d6014dffffee5200ea',NULL,'1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:11:41','1','2015-08-21 15:46:02','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58ab574c7d0e6c014c7d103ec70004','1','messageMgr','static/images/platform/sysmenu/icons.gif -220px -80px','platform/sysmessage/sysMessageController/toSysMessage','8a58a6b44c276a3f014c276b708c0003','99','1',NULL,NULL,'0',NULL,'0','0','2015-05-12 14:06:06','1','2015-04-03 10:15:58','1','127.0.0.1','373',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/modules/system/sysmessage/sysmessage.jsp',NULL,'1'),('8a58c8434d468f93014d4696701d0009','1','yhgxgl','static/images/platform/sysmenu/icons.gif -140px -100px','platform/sysUserRelationController/toUserRelation','8a58a6b44c276a3f014c276bcc2d0008','5','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:26:13','1','2015-05-12 13:26:13','1','127.0.0.1','37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/modules/system/sysuserrelation/userrelation.jsp',NULL,'1'),('8a58c8434d468f93014d4698ca290012','1','sysgroup','static/images/platform/sysmenu/icons.gif -240px -180px','platform/sysgroup/sysgroupinfo','8a58a6b44c276a3f014c276bcc2d0008','6','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:28:47','1','2015-05-12 13:28:47','1','127.0.0.1','37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/modules/system/sysgroup/sysgroup.jsp',NULL,'1'),('8a58c8434d468f93014d4699721b0017','1','sysrole','static/images/platform/sysmenu/icons.gif -160px -100px','platform/sysrole/sysroleinfo','8a58a6b44c276a3f014c276bcc2d0008','7','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:29:30','1','2015-05-12 13:29:30','1','127.0.0.1','37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/modules/system/sysrole/sysrole.jsp',NULL,'1'),('8a58c8434d468f93014d469b1dca001c','1','xtpzgl','static/images/platform/sysmenu/icons.gif -200px -0px',NULL,'8a58a6b44c276a3f014c276b708c0003','3','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 14:16:10','1','2015-05-12 13:31:20','1','127.0.0.1','41',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2','1','1',NULL,'0',NULL,NULL,'1'),('8a58c8434d468f93014d469d824e0026','1','SysMenu','static/images/platform/sysmenu/icons.gif -0px -120px','platform/sysmenu/sysmenuinfo','8a58c8434d468f93014d469b1dca001c','1','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:33:57','1','2015-05-12 13:33:57','1','127.0.0.1','37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/modules/system/sysmenu/sysmenu.jsp',NULL,'1'),('8a58c8434d468f93014d46a40e83003b','1','porlets','static/images/platform/sysmenu/icons.gif -60px -140px','avicit/platform6/modules/system/sysportal/portletconfig.jsp','8a58c8434d468f93014d469b1dca001c','2','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:41:06','1','2015-05-12 13:41:06','1','127.0.0.1','37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58c8434d468f93014d46a4bdf50040','1','profileManage','static/images/platform/sysmenu/icons.gif -40px -180px','platform/sysprofile/sysProfileInfo','8a58c8434d468f93014d469b1dca001c','3','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:41:51','1','2015-05-12 13:41:51','1','127.0.0.1','37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/modules/system/sysprofile/sysprofile.jsp',NULL,'1'),('8a58c8434d468f93014d46a533990045','1','lookup','static/images/platform/sysmenu/icons.gif -40px -180px','platform/syslookuptype/sysLookupTypeInfo','8a58c8434d468f93014d469b1dca001c','4','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:42:21','1','2015-05-12 13:42:21','1','127.0.0.1','37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/modules/system/syslookuptype/syslookupType.jsp',NULL,'1'),('8a58c8434d468f93014d46a5ae9a004a','1','sysapplication','static/images/platform/sysmenu/icons.gif -160px -40px','platform/sysApps/sysAppsInfo','8a58c8434d468f93014d469b1dca001c','5','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:42:52','1','2015-05-12 13:42:52','1','127.0.0.1','37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/modules/system/sysapplication/sysApplicationManager.jsp',NULL,'1'),('8a58c8434d468f93014d46a62877004f','1','onlineUser','static/images/platform/sysmenu/icons.gif -260px -60px','avicit/platform6/modules/system/onlineuser/onlineuser.jsp','8a58c8434d468f93014d469b1dca001c','6','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:43:24','1','2015-05-12 13:43:24','1','127.0.0.1','37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58c8434d468f93014d46a6a33c0054','1','reLoadCache','static/images/platform/sysmenu/icons.gif -260px -180px','avicit/platform6/modules/system/sysdashboard/reLoadCache.jsp','8a58c8434d468f93014d469b1dca001c','7','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:43:55','1','2015-05-12 13:43:55','1','127.0.0.1','37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58c8434d468f93014d46a71c050059','1','ssoconfig','static/images/platform/sysmenu/icons.gif -120px -100px','platform/ssoUpdate/casConfig','8a58c8434d468f93014d469b1dca001c','8','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:44:26','1','2015-05-12 13:44:26','1','127.0.0.1','37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/modules/system/ssologin/ssoconfigure.jsp',NULL,'1'),('8a58c8434d468f93014d46a7b7c2005e','1','sysjob','static/images/platform/sysmenu/icons.gif -100px -40px','avicit/platform6/modules/system/quartz/jobMaintainManager.jsp','8a58c8434d468f93014d469b1dca001c','9','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:45:06','1','2015-05-12 13:45:06','1','127.0.0.1','37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58c8434d468f93014d46aa7ba90072','1','privelity','static/images/platform/sysmenu/icons.gif -240px -40px','avicit/platform6/modules/system/sysdatapermission/SysPermissionResource.jsp','8a58a6b44c276a3f014c2a5f00fc0057','3','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:48:34','1','2015-05-12 13:48:07','1','127.0.0.1','38',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58c8434d468f93014d46ab685b0080','1','deptLeaderSetting','static/images/platform/sysmenu/icons.gif -280px -40px','platform/sysPermissionLeaddeptController/leaddept','8a58a6b44c276a3f014c2a5f00fc0057','4','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 13:49:08','1','2015-05-12 13:49:08','1','127.0.0.1','37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/modules/system/sysdatapermission/deptleadermanager.jsp',NULL,'1'),('8a58c8434d468f93014d46b7c03f00c8','1','lcwdfxyj','static/images/platform/sysmenu/icons.gif -100px -140px','avicit/platform6/bpmconsole/analysis/ProcessDurationAnalysis.jsp','8a58a6b44c276a3f014c2a66d819009b','6','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 14:02:36','1','2015-05-12 14:02:36','1','127.0.0.1','37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58c8434d468f93014d46b85ae600cd','1','bmwdtjfx','static/images/platform/sysmenu/icons.gif -100px -140px','avicit/platform6/bpmconsole/analysis/ProcessDeptAnalysis.jsp','8a58a6b44c276a3f014c2a66d819009b','7','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 14:03:16','1','2015-05-12 14:03:16','1','127.0.0.1','37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58c8434d468f93014d46b8ce1d00d2','1','gwwdtjfx','static/images/platform/sysmenu/icons.gif -100px -140px','avicit/platform6/bpmconsole/analysis/ProcessPositionAnalysis.jsp','8a58a6b44c276a3f014c2a66d819009b','8','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 14:03:46','1','2015-05-12 14:03:46','1','127.0.0.1','37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58c8434d468f93014d46b92d0800d7','1','yhwdfxyj','static/images/platform/sysmenu/icons.gif -160px -140px','avicit/platform6/bpmconsole/analysis/ProcessUserAnalysis.jsp','8a58a6b44c276a3f014c2a66d819009b','9','1',NULL,NULL,'0',NULL,'0','1','2015-05-12 14:04:10','1','2015-05-12 14:04:10','1','127.0.0.1','37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd434fb53c16014fb53f01a5004d','1','secretManager','static/images/platform/sysmenu/icons.gif -260px -60px','platform/syssecret/toSecretManager','8a58c8434d468f93014d469b1dca001c','5','1',NULL,NULL,'0',NULL,'0','1','2015-09-10 11:14:09','1','2015-09-10 11:14:09','1','0:0:0:0:0:0:0:1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/modules/system/secret/secretManager.jsp',NULL,'1'),('8a58cd574df6657e014df670084400d0','1','cc_organddept','static/images/platform/sysmenu/icons.gif -200px -40px',NULL,'402809814db30afe014db30c4e18008e','0','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:02:01','1','2015-06-15 16:57:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd574df6657e014df673fdb400d5','1','cc_dept','static/images/platform/sysmenu/icons.gif -240px -100px','platform/cc/sysdept/sysdeptinfo','8a58cd574df6657e014df670084400d0','2','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:02:38','1','2015-06-15 17:01:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0','avicit/platform6/centralcontrol/sysdept/sysdept.jsp',NULL,'1'),('8a58cd574e75cfbe014e75d560cc00d8','1','cc_onlineuser','static/images/platform/sysmenu/icons.gif -40px -60px','platform/cc/onlineuser/onlineuserinfo','402809814dfff8d6014dffffee5200ea','8','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:07:21','1','2015-07-10 10:39:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd574e75cfbe014e75d7db2300de','1','cc_cas','static/images/platform/sysmenu/icons.gif -160px -80px','platform/cc/ssoconfig/ssoconfiginfo/null','402809814dfff8d6014dffffee5200ea','9','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:07:30','1','2015-07-10 10:42:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd574e90f106014e90f1f69900da','1','cc_safemgr','static/images/platform/sysmenu/icons.gif -180px -80px',NULL,'402809814db30afe014db30c4e18008e','5','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:02:14','1','2015-07-15 17:00:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'3','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd574e90f106014e90f2ba3300df','1','cc_syslog','static/images/platform/sysmenu/icons.gif -0px -180px','platform/syslog/sysloginfo','8a58cd574e90f106014e90f1f69900da','1','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:06:22','1','2015-07-15 17:01:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'4','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd574eb461d7014eb469fcf700f5','1','cc_restmanage','static/images/platform/sysmenu/icons.gif -80px -100px',NULL,'402809814db30afe014db30c4e18008e','6','1',NULL,NULL,'0',NULL,'0','1','2015-09-28 10:46:11','1','2015-07-22 14:18:00','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'3','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd574eb48823014eb49026ac00db','1','cc_restorg','static/images/platform/sysmenu/icons.gif -40px -140px','platform/restmanage/org/index','8a58cd574eb461d7014eb469fcf700f5','1','1',NULL,NULL,'0',NULL,'0','1','2015-07-22 15:00:00','1','2015-07-22 15:00:00','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd574eb48823014eb4926b4000e0','1','cc_restsystem','static/images/platform/sysmenu/icons.gif -100px -140px','platform/restmanage/system/index','8a58cd574eb461d7014eb469fcf700f5','2','1',NULL,NULL,'0',NULL,'0','1','2015-07-22 15:02:00','1','2015-07-22 15:02:00','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd574eb48823014eb493161f00e5','1','cc_restauth','static/images/platform/sysmenu/icons.gif -60px -140px','platform/restmanage/resources/index','8a58cd574eb461d7014eb469fcf700f5','3','1',NULL,NULL,'0',NULL,'0','1','2015-07-22 15:03:00','1','2015-07-22 15:03:00','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd574eb48823014eb493fc3200ea','1','cc_restuser','static/images/platform/sysmenu/icons.gif -180px -160px','platform/restmanage/auth/index','8a58cd574eb461d7014eb469fcf700f5','4','1',NULL,NULL,'0',NULL,'0','1','2015-07-22 15:04:00','1','2015-07-22 15:04:00','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd574eb48823014eb49503b700ef','1','cc_searchmodule','static/images/platform/sysmenu/icons.gif -140px -100px',NULL,'402809814db30afe014db30c4e18008e','7','1',NULL,NULL,'0',NULL,'0','1','2015-09-28 10:46:05','1','2015-07-22 15:05:00','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'3','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd574eb48823014eb495b51800f4','1','cc_searchdb','static/images/platform/sysmenu/icons.gif -60px -80px','platform/search/connection/index.html','8a58cd574eb48823014eb49503b700ef','1','1',NULL,NULL,'0',NULL,'0','1','2015-07-22 15:06:00','1','2015-07-22 15:06:00','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd574eb48823014eb4965d0700f9','1','cc_searchindex','static/images/platform/sysmenu/icons.gif -100px -120px','platform/search/index.html','8a58cd574eb48823014eb49503b700ef','2','1',NULL,NULL,'0',NULL,'0','1','2015-07-22 15:07:00','1','2015-07-22 15:07:00','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd575016ab70015016af29f60052','1','bpm_FocusedTask','static/images/platform/sysmenu/icons.gif -20px -100px','avicit/platform6/bpmclient/bpm/FocusedTask.jsp','8a58a6b44c275bab014c2765ee040031','4','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 09:19:49','1','2015-09-29 09:19:49','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd57501c05fb01501c1337ab006e','1','bpm_zwml','static/images/platform/sysmenu/icons.gif -140px -100px','avicit/platform6/bpmconsole/publish/WordCatalogManage.jsp','8a58a6b44c276a3f014c2a66d819009b','11','1',NULL,NULL,'0',NULL,'0','1','2015-09-30 10:27:12','1','2015-09-30 10:27:12','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd57535417350153543765620072','1','sys_language','static/images/platform/sysmenu/icons.gif -100px -20px','platform/syslanguage/mgr','8a58c8434d468f93014d469b1dca001c','11','1',NULL,NULL,'0',NULL,'0','1','2016-03-08 11:14:01','1','2016-03-08 11:13:49','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd5b4d5acbde014d5ae7db420045','1','fineReportAuth','static/images/platform/sysmenu/icons.gif -240px -160px','platform/fineReportAuthorityController/fineReportInfo','8a58a6b44c276a3f014c2a5f00fc0057','3','1',NULL,NULL,'0',NULL,'0','0','2015-05-16 12:07:33','1','2015-05-16 12:07:33','1','0:0:0:0:0:0:0:1','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd5b4e042750014e045b413900dc','1','cc_portalconfig','static/images/platform/sysmenu/icons.gif -180px -40px','platform/cc/sysportal/sysportalinfo','402809814dfff8d6014dffffee5200ea','4','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:06:56','1','2015-06-18 09:49:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd5b4e042750014e045c584000e1','1','cc_lookup','static/images/platform/sysmenu/icons.gif -40px -100px','platform/cc/syslookup/syslookupinfo','402809814dfff8d6014dffffee5200ea','3','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 15:56:07','1','2015-06-18 09:50:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd5b4e3ce0ac014e3ce2bb1500ca','1','cc_sysaccesscontrol','static/images/platform/sysmenu/icons.gif -180px -60px',NULL,'402809814db30afe014db30c4e18008e','2','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:02:08','1','2015-06-29 09:16:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd5b4e3ce0ac014e3d61a41500eb','1','cc_menuaccesscontrol','static/images/platform/sysmenu/icons.gif -200px -100px','platform/cc/menuaccesscontrol/menuaccesscontrolinfo','8a58cd5b4e3ce0ac014e3ce2bb1500ca',NULL,'1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:03:56','1','2015-06-29 11:34:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd5b4e706483014e706c730c00cb','1','cc_authManager','static/images/platform/sysmenu/icons.gif -220px -80px','platform/cc/securitycontrol/securitycontrolinfo','8a58cd5b4e3ce0ac014e3ce2bb1500ca','3','1',NULL,NULL,'0',NULL,'0','1','2015-09-29 16:03:46','1','2015-07-09 09:27:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1'),('8a58cd604e7156df014e71749f67010c','1','bpmdesigner','static/images/platform/sysmenu/icons.gif -60px -120px','platform/bpm/bpmdesigner/bpmWebDesigner/index','8a58a6b44c276a3f014c2a66d819009b','0','1',NULL,NULL,'0',NULL,'0','1','2015-07-09 14:15:45','1','2015-07-09 14:15:45','1','127.0.0.1','74',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1',NULL,'0',NULL,NULL,'1');

/*Table structure for table `sys_menu_tl` */

DROP TABLE IF EXISTS `sys_menu_tl`;

CREATE TABLE `sys_menu_tl` (
  `ID` varchar(50) NOT NULL COMMENT '唯一标识',
  `SYS_MENU_ID` varchar(50) NOT NULL COMMENT '菜单ID',
  `SYS_LANGUAGE_CODE` varchar(50) NOT NULL COMMENT '语言代码',
  `NAME` varchar(100) NOT NULL COMMENT '显示名称',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `COMMENTS` text COMMENT '菜单的描述信息',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='菜单多语言表';

/*Data for the table `sys_menu_tl` */

insert  into `sys_menu_tl` values ('1','1','zh_CN','菜单树','2015-03-05 13:26:06','1','2012-06-22 00:00:00','1','127.0.0.1','2','描述'),('402809814db30afe014db30c4e860091','402809814db30afe014db30c4e18008e','zh_CN','集中管控','2016-03-14 13:23:05','1','2015-06-02 14:53:00','1','127.0.0.1','12',NULL),('402809814dff7814014dff92ebea00d9','402809814dff7814014dff92ebb900d6','zh_CN','用户集中管理','2015-09-29 16:02:51','1','2015-06-17 11:32:00','1','127.0.0.1','5',NULL),('402809814dfff8d6014dfffa128f00d0','402809814dfff8d6014dfffa122d00cd','zh_CN','组织集中管理','2015-09-29 16:02:32','1','2015-06-17 13:24:00','1','127.0.0.1','9',NULL),('402809814dfff8d6014dfffad0f500d5','402809814dfff8d6014dfffad0c600d2','zh_CN','岗位集中管理','2015-09-29 16:02:44','1','2015-06-17 13:25:00','1','127.0.0.1','3',NULL),('402809814dfff8d6014dfffc118500e0','402809814dfff8d6014dfffc115900dd','zh_CN','群组集中管理','2015-09-29 16:03:03','1','2015-06-17 13:26:00','1','127.0.0.1','2',NULL),('402809814dfff8d6014dfffc8d4a00e5','402809814dfff8d6014dfffc8d2300e2','zh_CN','角色集中管理','2015-09-29 16:03:10','1','2015-06-17 13:27:00','1','127.0.0.1','3',NULL),('402809814dfff8d6014dffffee7700ed','402809814dfff8d6014dffffee5200ea','zh_CN','系统配置集中管理','2015-09-29 16:02:21','1','2015-06-17 13:31:00','1','127.0.0.1','4',NULL),('402809814dfff8d6014e0001290e00f5','402809814dfff8d6014e000128e800f2','zh_CN','菜单集中管理','2015-09-29 15:55:53','1','2015-06-17 13:32:00','1','127.0.0.1','2',NULL),('402809814dfff8d6014e00026f2600fa','402809814dfff8d6014e00026efb00f7','zh_CN','系统参数集中管理','2015-09-29 16:06:48','1','2015-06-17 13:33:00','1','127.0.0.1','2',NULL),('402809814e0065ed014e006a7ff300d0','402809814e0065ed014e006a7fae00cd','zh_CN','用户关系集中管理','2015-09-29 16:02:57','1','2015-06-17 15:27:00','1','127.0.0.1','2',NULL),('402809814e0464bd014e046831c900d1','402809814e0464bd014e0468318700ce','zh_CN','多应用集中管理','2015-09-29 16:07:14','1','2015-06-18 10:03:00','1','127.0.0.1','1',NULL),('402809814e1f2ee8014e1f32241400c9','402809814e1f2ee8014e1f3223a200c6','zh_CN','多应用权限管理','2015-09-29 16:07:06','1','2015-06-23 14:54:00','1','127.0.0.1','1',NULL),('402809814e472359014e4727579100cd','402809814e472359014e4727572e00ca','zh_CN','数据权限集中管理','2015-09-29 16:03:37','1','2015-07-01 09:07:00','1','127.0.0.1','2',NULL),('402809814e51ecf1014e51f2931f00cf','402809814e51ecf1014e51f268c800cc','zh_CN','跨部门领导管理','2015-09-29 16:06:12','1','2015-07-03 11:25:00','1','127.0.0.1','2',NULL),('402809814f2a5144014f2ab7c79a0051','402809814f2a5144014f2ab7c74d0050','zh_CN','编码管理','2015-08-14 16:44:28','1','2015-08-14 13:38:51','1','127.0.0.1','1',NULL),('402809814f2a5144014f2ab893920056','402809814f2a5144014f2ab893490055','zh_CN','多维通用代码','2015-08-14 13:39:43','1','2015-08-14 13:39:43','1','127.0.0.1','0',NULL),('40283f874f25ed9f014f2607b10300dd','40283f874f25ed9f014f2607b02200dc','zh_CN','编码集中管理','2015-09-29 16:08:06','1','2015-08-13 15:48:00','1','127.0.0.1','4',NULL),('8a58a6b44c275bab014c275fddb10011','8a58a6b44c275bab014c275fdd42000e','zh_CN','门户小页','2015-03-17 18:55:36','1','2015-03-17 18:55:36','1','10.216.43.205','0',NULL),('8a58a6b44c275bab014c2762df4f0020','8a58a6b44c275bab014c2762df17001d','zh_CN','我的待办事务','2015-03-17 18:58:53','1','2015-03-17 18:58:53','1','10.216.43.205','0',NULL),('8a58a6b44c275bab014c27648492002f','8a58a6b44c275bab014c27648454002c','zh_CN','系统首页','2015-03-17 19:00:41','1','2015-03-17 19:00:41','1','10.216.43.205','0',NULL),('8a58a6b44c275bab014c2765ee400034','8a58a6b44c275bab014c2765ee040031','zh_CN','个人事务','2016-03-10 16:16:41','1','2015-03-17 19:02:13','1','127.0.0.1','2',NULL),('8a58a6b44c275bab014c27675b470039','8a58a6b44c275bab014c27675b0c0036','zh_CN','我的流程','2015-03-17 19:03:47','1','2015-03-17 19:03:47','1','10.216.43.205','0',NULL),('8a58a6b44c275bab014c2767bdd5003e','8a58a6b44c275bab014c2767bd9c003b','zh_CN','我的工作','2015-03-17 19:04:12','1','2015-03-17 19:04:12','1','10.216.43.205','0',NULL),('8a58a6b44c275bab014c276857430043','8a58a6b44c275bab014c2768570b0040','zh_CN','工作移交','2015-03-17 19:04:51','1','2015-03-17 19:04:51','1','10.216.43.205','0',NULL),('8a58a6b44c276a3f014c276b710a0006','8a58a6b44c276a3f014c276b708c0003','zh_CN','系统管理','2016-03-14 13:22:56','1','2015-03-17 19:08:15','1','127.0.0.1','2',NULL),('8a58a6b44c276a3f014c276bcc72000b','8a58a6b44c276a3f014c276bcc2d0008','zh_CN','组织机构管理','2015-05-12 13:46:23','1','2015-03-17 19:08:38','1','127.0.0.1','1',NULL),('8a58a6b44c276a3f014c276e450b001b','8a58a6b44c276a3f014c276e44d00018','zh_CN','组织管理','2015-04-10 15:37:02','1','2015-03-17 19:11:20','1','127.0.0.1','1',NULL),('8a58a6b44c276a3f014c276ea9b20020','8a58a6b44c276a3f014c276ea970001d','zh_CN','部门用户管理','2015-04-10 15:40:57','1','2015-03-17 19:11:46','1','127.0.0.1','1',NULL),('8a58a6b44c276a3f014c276f222f0025','8a58a6b44c276a3f014c276f21ee0022','zh_CN','岗位管理','2015-03-17 19:12:16','1','2015-03-17 19:12:16','1','10.216.43.205','0',NULL),('8a58a6b44c276a3f014c276f9f5d002a','8a58a6b44c276a3f014c276f9f1a0027','zh_CN','用户管理','2015-05-12 13:21:22','1','2015-03-17 19:12:48','1','127.0.0.1','1',NULL),('8a58a6b44c276a3f014c2a5b2a860043','8a58a6b44c276a3f014c2a5b2a320040','zh_CN','个人设置','2015-05-12 14:12:09','1','2015-03-18 08:49:20','1','127.0.0.1','2',NULL),('8a58a6b44c276a3f014c2a5f0133005a','8a58a6b44c276a3f014c2a5f00fc0057','zh_CN','授权管理','2015-05-12 14:13:23','1','2015-03-18 08:53:31','1','127.0.0.1','2',NULL),('8a58a6b44c276a3f014c2a6077030064','8a58a6b44c276a3f014c2a6076d10061','zh_CN','菜单授权管理','2015-05-12 13:48:23','1','2015-03-18 08:55:07','1','127.0.0.1','1',NULL),('8a58a6b44c276a3f014c2a616c020069','8a58a6b44c276a3f014c2a616bc70066','zh_CN','集中授权管理','2015-05-12 13:48:29','1','2015-03-18 08:56:09','1','127.0.0.1','1',NULL),('8a58a6b44c276a3f014c2a63ee96007d','8a58a6b44c276a3f014c2a63ee62007a','zh_CN','系统安全管理','2015-05-12 14:27:27','1','2015-03-18 08:58:54','1','127.0.0.1','4',NULL),('8a58a6b44c276a3f014c2a64549e0082','8a58a6b44c276a3f014c2a645456007f','zh_CN','日志与审计','2015-08-14 13:54:52','1','2015-03-18 08:59:20','1','127.0.0.1','3',NULL),('8a58a6b44c276a3f014c2a652e12008c','8a58a6b44c276a3f014c2a652dd80089','zh_CN','密码模版配置','2015-05-12 13:51:22','1','2015-03-18 09:00:16','1','127.0.0.1','1',NULL),('8a58a6b44c276a3f014c2a657a0a0091','8a58a6b44c276a3f014c2a6579c6008e','zh_CN','IP限制管理','2015-05-12 13:51:31','1','2015-03-18 09:00:35','1','127.0.0.1','1',NULL),('8a58a6b44c276a3f014c2a66d897009e','8a58a6b44c276a3f014c2a66d819009b','zh_CN','业务流程管理','2015-05-12 14:27:18','1','2015-03-18 09:02:05','1','127.0.0.1','5',NULL),('8a58a6b44c276a3f014c2a692d3c00a3','8a58a6b44c276a3f014c2a692d0800a0','zh_CN','流程目录管理','2015-05-12 13:59:00','1','2015-03-18 09:04:38','1','127.0.0.1','1',NULL),('8a58a6b44c276a3f014c2a6988b700a8','8a58a6b44c276a3f014c2a69888500a5','zh_CN','流程表单管理','2015-05-12 13:59:07','1','2015-03-18 09:05:01','1','127.0.0.1','1',NULL),('8a58a6b44c276a3f014c2a69e03400ad','8a58a6b44c276a3f014c2a69e00100aa','zh_CN','正文模板管理','2015-05-12 13:59:13','1','2015-03-18 09:05:24','1','127.0.0.1','1',NULL),('8a58a6b44c276a3f014c2a6ac63b00b2','8a58a6b44c276a3f014c2a6ac60200af','zh_CN','流程模板配置','2015-05-12 13:59:30','1','2015-03-18 09:06:22','1','127.0.0.1','1',NULL),('8a58a6b44c276a3f014c2a6b0cc500b7','8a58a6b44c276a3f014c2a6b0c9500b4','zh_CN','流程实例监控','2015-05-12 13:59:44','1','2015-03-18 09:06:40','1','127.0.0.1','1',NULL),('8a58a6b44c276a3f014c2a73dff800e1','8a58a6b44c276a3f014c2a73dfb700de','zh_CN','服务管理','2015-05-12 14:27:35','1','2015-03-18 09:16:19','1','127.0.0.1','5',NULL),('8a58a6b44c276a3f014c2a7433ff00e6','8a58a6b44c276a3f014c2a7433c200e3','zh_CN','单位注册管理','2015-05-12 13:54:11','1','2015-03-18 09:16:40','1','127.0.0.1','1',NULL),('8a58a6b44c276a3f014c2a750f1900f1','8a58a6b44c276a3f014c2a750edf00ee','zh_CN','系统注册管理','2015-05-12 13:54:51','1','2015-03-18 09:17:36','1','127.0.0.1','1',NULL),('8a58a6b44c276a3f014c2a7655440100','8a58a6b44c276a3f014c2a76550f00fd','zh_CN','服务资源管理','2015-05-12 13:55:29','1','2015-03-18 09:19:00','1','127.0.0.1','1',NULL),('8a58a6b44c276a3f014c2a76a9ea0105','8a58a6b44c276a3f014c2a76a9a90102','zh_CN','服务授权配置','2015-05-12 13:56:06','1','2015-03-18 09:19:22','1','127.0.0.1','1',NULL),('8a58a6b44c276a3f014c2a7e18b2010a','8a58a6b44c276a3f014c2a7e187b0107','zh_CN','搜索配置管理','2015-05-12 14:27:42','1','2015-03-18 09:27:29','1','127.0.0.1','5',NULL),('8a58a6b44c276a3f014c2a7f2b680112','8a58a6b44c276a3f014c2a7f2b2f010f','zh_CN','数据源配置','2015-05-12 13:57:42','1','2015-03-18 09:28:39','1','127.0.0.1','1',NULL),('8a58a6b44c276a3f014c2a7fb140011a','8a58a6b44c276a3f014c2a7fb1100117','zh_CN','搜索索引配置','2015-05-12 13:58:05','1','2015-03-18 09:29:13','1','127.0.0.1','1',NULL),('8a58a6b54f2b3339014f2b40c2be0075','8a58a6b54f2b3339014f2b40c2680074','zh_CN','密码模版配置','2015-08-14 16:08:28','1','2015-08-14 16:08:28','1','10.216.77.215','0',NULL),('8a58a6b54f2b3339014f2b45d33d007a','8a58a6b54f2b3339014f2b45d2c50079','zh_CN','IP限制管理','2015-08-14 16:14:00','1','2015-08-14 16:14:00','1','10.216.77.215','0',NULL),('8a58a6b54f4f35af014f4f38be34007d','8a58a6b54f4f35af014f4f38bdb9007c','zh_CN','缓存集中管理','2015-09-29 16:11:41','1','2015-08-21 15:46:02','1','127.0.0.1','1',NULL),('8a58ab574c7d0e6c014c7d103f410007','8a58ab574c7d0e6c014c7d103ec70004','zh_CN','消息','2015-05-12 14:06:06','1','2015-04-03 10:15:59','1','127.0.0.1','1',NULL),('8a58c8434d468f93014d4696708b000c','8a58c8434d468f93014d4696701d0009','zh_CN','用户关系管理','2015-05-12 13:26:13','1','2015-05-12 13:26:13','1','127.0.0.1','0',NULL),('8a58c8434d468f93014d4698ca6a0015','8a58c8434d468f93014d4698ca290012','zh_CN','群组管理','2015-05-12 13:28:47','1','2015-05-12 13:28:47','1','127.0.0.1','0',NULL),('8a58c8434d468f93014d4699723f001a','8a58c8434d468f93014d4699721b0017','zh_CN','角色管理','2015-05-12 13:29:30','1','2015-05-12 13:29:30','1','127.0.0.1','0',NULL),('8a58c8434d468f93014d469b1df2001f','8a58c8434d468f93014d469b1dca001c','zh_CN','系统配置管理','2015-05-12 14:16:10','1','2015-05-12 13:31:20','1','127.0.0.1','4',NULL),('8a58c8434d468f93014d469d82730029','8a58c8434d468f93014d469d824e0026','zh_CN','菜单管理','2015-05-12 13:33:57','1','2015-05-12 13:33:57','1','127.0.0.1','0',NULL),('8a58c8434d468f93014d46a40eae003e','8a58c8434d468f93014d46a40e83003b','zh_CN','门户布局管理','2015-05-12 13:41:06','1','2015-05-12 13:41:06','1','127.0.0.1','0',NULL),('8a58c8434d468f93014d46a4be1f0043','8a58c8434d468f93014d46a4bdf50040','zh_CN','系统参数配置','2015-05-12 13:41:51','1','2015-05-12 13:41:51','1','127.0.0.1','0',NULL),('8a58c8434d468f93014d46a533c80048','8a58c8434d468f93014d46a533990045','zh_CN','通用代码管理','2015-05-12 13:42:21','1','2015-05-12 13:42:21','1','127.0.0.1','0',NULL),('8a58c8434d468f93014d46a5aec1004d','8a58c8434d468f93014d46a5ae9a004a','zh_CN','多应用管理','2015-05-12 13:42:52','1','2015-05-12 13:42:52','1','127.0.0.1','0',NULL),('8a58c8434d468f93014d46a6289a0052','8a58c8434d468f93014d46a62877004f','zh_CN','在线用户','2015-05-12 13:43:24','1','2015-05-12 13:43:24','1','127.0.0.1','0',NULL),('8a58c8434d468f93014d46a6a35b0057','8a58c8434d468f93014d46a6a33c0054','zh_CN','缓存管理','2015-05-12 13:43:55','1','2015-05-12 13:43:55','1','127.0.0.1','0',NULL),('8a58c8434d468f93014d46a71c30005c','8a58c8434d468f93014d46a71c050059','zh_CN','单点配置管理','2015-05-12 13:44:26','1','2015-05-12 13:44:26','1','127.0.0.1','0',NULL),('8a58c8434d468f93014d46a7b7e60061','8a58c8434d468f93014d46a7b7c2005e','zh_CN','定时任务管理','2015-05-12 13:45:06','1','2015-05-12 13:45:06','1','127.0.0.1','0',NULL),('8a58c8434d468f93014d46aa7bce0075','8a58c8434d468f93014d46aa7ba90072','zh_CN','数据权限配置','2015-05-12 13:48:34','1','2015-05-12 13:48:07','1','127.0.0.1','1',NULL),('8a58c8434d468f93014d46ab68850083','8a58c8434d468f93014d46ab685b0080','zh_CN','跨部门领导配置','2015-05-12 13:49:08','1','2015-05-12 13:49:08','1','127.0.0.1','0',NULL),('8a58c8434d468f93014d46b7c06d00cb','8a58c8434d468f93014d46b7c03f00c8','zh_CN','流程维度分析','2015-05-12 14:02:37','1','2015-05-12 14:02:37','1','127.0.0.1','0',NULL),('8a58c8434d468f93014d46b85b2100d0','8a58c8434d468f93014d46b85ae600cd','zh_CN','部门维度分析','2015-05-12 14:03:16','1','2015-05-12 14:03:16','1','127.0.0.1','0',NULL),('8a58c8434d468f93014d46b8ce5800d5','8a58c8434d468f93014d46b8ce1d00d2','zh_CN','岗位维度分析','2015-05-12 14:03:46','1','2015-05-12 14:03:46','1','127.0.0.1','0',NULL),('8a58c8434d468f93014d46b92d3600da','8a58c8434d468f93014d46b92d0800d7','zh_CN','用户维度分析','2015-05-12 14:04:10','1','2015-05-12 14:04:10','1','127.0.0.1','0',NULL),('8a58cd434fb53c16014fb53f01e7004e','8a58cd434fb53c16014fb53f01a5004d','zh_CN','密级关系管理','2015-09-10 11:14:09','1','2015-09-10 11:14:09','1','0:0:0:0:0:0:0:1','0',NULL),('8a58cd574df6657e014df670088700d3','8a58cd574df6657e014df670084400d0','zh_CN','组织结构集中管理','2015-09-29 16:02:01','1','2015-06-15 16:57:00','1','127.0.0.1','2',NULL),('8a58cd574df6657e014df673fde000d8','8a58cd574df6657e014df673fdb400d5','zh_CN','部门用户集中管理','2015-09-29 16:02:38','1','2015-06-15 17:01:00','1','127.0.0.1','4',NULL),('8a58cd574e75cfbe014e75d5611a00db','8a58cd574e75cfbe014e75d560cc00d8','zh_CN','在线用户集中管理','2015-09-29 16:07:21','1','2015-07-10 10:39:00','1','127.0.0.1','1',NULL),('8a58cd574e75cfbe014e75d7db5b00e1','8a58cd574e75cfbe014e75d7db2300de','zh_CN','单点配置集中管理','2015-09-29 16:07:30','1','2015-07-10 10:42:00','1','127.0.0.1','2',NULL),('8a58cd574e90f106014e90f1f71600db','8a58cd574e90f106014e90f1f69900da','zh_CN','系统安全集中管理','2015-09-29 16:02:14','1','2015-07-15 17:00:00','1','127.0.0.1','3',NULL),('8a58cd574e90f106014e90f2ba6500e0','8a58cd574e90f106014e90f2ba3300df','zh_CN','日志审计集中管理','2015-09-29 16:06:22','1','2015-07-15 17:01:00','1','127.0.0.1','3',NULL),('8a58cd574eb461d7014eb469fd1d00f6','8a58cd574eb461d7014eb469fcf700f5','zh_CN','服务管理','2015-09-28 10:46:11','1','2015-07-22 14:18:00','1','127.0.0.1','2',NULL),('8a58cd574eb48823014eb49026e800dc','8a58cd574eb48823014eb49026ac00db','zh_CN','单位注册管理','2015-07-22 15:00:00','1','2015-07-22 15:00:00','1','127.0.0.1','0',NULL),('8a58cd574eb48823014eb4926b6a00e1','8a58cd574eb48823014eb4926b4000e0','zh_CN','系统注册管理','2015-07-22 15:02:00','1','2015-07-22 15:02:00','1','127.0.0.1','0',NULL),('8a58cd574eb48823014eb493164600e6','8a58cd574eb48823014eb493161f00e5','zh_CN','服务资源管理','2015-07-22 15:03:00','1','2015-07-22 15:03:00','1','127.0.0.1','0',NULL),('8a58cd574eb48823014eb493fc5b00eb','8a58cd574eb48823014eb493fc3200ea','zh_CN','服务授权配置','2015-07-22 15:04:00','1','2015-07-22 15:04:00','1','127.0.0.1','0',NULL),('8a58cd574eb48823014eb49503e200f0','8a58cd574eb48823014eb49503b700ef','zh_CN','搜索配置管理','2015-09-28 10:46:05','1','2015-07-22 15:05:00','1','127.0.0.1','2',NULL),('8a58cd574eb48823014eb495b53e00f5','8a58cd574eb48823014eb495b51800f4','zh_CN','数据源配置','2015-07-22 15:06:00','1','2015-07-22 15:06:00','1','127.0.0.1','0',NULL),('8a58cd574eb48823014eb4965d2b00fa','8a58cd574eb48823014eb4965d0700f9','zh_CN','搜索索引配置','2015-07-22 15:07:00','1','2015-07-22 15:07:00','1','127.0.0.1','0',NULL),('8a58cd575016ab70015016af2a270053','8a58cd575016ab70015016af29f60052','zh_CN','关注工作','2015-09-29 09:19:49','1','2015-09-29 09:19:49','1','127.0.0.1','0',NULL),('8a58cd57501c05fb01501c1337ca006f','8a58cd57501c05fb01501c1337ab006e','zh_CN','正文目录管理','2015-09-30 10:27:12','1','2015-09-30 10:27:12','1','127.0.0.1','0',NULL),('8a58cd57535417350153543765b30073','8a58cd57535417350153543765620072','zh_CN','系统语言维护','2016-03-08 11:14:01','1','2016-03-08 11:13:50','1','127.0.0.1','1',NULL),('8a58cd5b4d5acbde014d5ae7dbad0048','8a58cd5b4d5acbde014d5ae7db420045','zh_CN','报表模版授权管理','2015-05-16 12:07:34','1','2015-05-16 12:07:34','1','0:0:0:0:0:0:0:1','0',NULL),('8a58cd5b4e042750014e045b419000df','8a58cd5b4e042750014e045b413900dc','zh_CN','门户布局集中管理','2015-09-29 16:06:56','1','2015-06-18 09:49:00','1','127.0.0.1','1',NULL),('8a58cd5b4e042750014e045c587900e4','8a58cd5b4e042750014e045c584000e1','zh_CN','通用代码集中管理','2015-09-29 15:56:07','1','2015-06-18 09:50:00','1','127.0.0.1','2',NULL),('8a58cd5b4e3ce0ac014e3ce2bb6800cd','8a58cd5b4e3ce0ac014e3ce2bb1500ca','zh_CN','授权集中管理','2015-09-29 16:02:08','1','2015-06-29 09:16:00','1','127.0.0.1','3',NULL),('8a58cd5b4e3ce0ac014e3d61a45700ee','8a58cd5b4e3ce0ac014e3d61a41500eb','zh_CN','菜单授权集中管理','2015-09-29 16:03:56','1','2015-06-29 11:34:00','1','127.0.0.1','2',NULL),('8a58cd5b4e706483014e706c737b00ce','8a58cd5b4e706483014e706c730c00cb','zh_CN','授权集中管理','2015-09-29 16:03:46','1','2015-07-09 09:27:00','1','127.0.0.1','4',NULL),('8a58cd604e7156df014e71749fbf010f','8a58cd604e7156df014e71749f67010c','zh_CN','流程设计器','2015-07-09 14:15:45','1','2015-07-09 14:15:45','1','127.0.0.1','0',NULL);

/*Table structure for table `sys_message` */

DROP TABLE IF EXISTS `sys_message`;

CREATE TABLE `sys_message` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `TITLE` varchar(255) NOT NULL COMMENT '消息的标题',
  `CONTENT` text COMMENT '消息的内容，可以含有HTML标签',
  `URL_ADDRESS` text COMMENT '打开该消息时转向的地址，一般为相对路径',
  `SEND_USER` varchar(50) NOT NULL COMMENT '消息发送人',
  `SEND_DATE` datetime NOT NULL COMMENT '发送日期',
  `RECV_USER` varchar(50) NOT NULL COMMENT '消息接收人',
  `RECV_DATE` datetime NOT NULL COMMENT '接收日期',
  `IS_READED` varchar(1) DEFAULT NULL COMMENT '消息是否已经被打开。1-已打开，0-未打开',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `URL_TYPE` varchar(2) DEFAULT NULL COMMENT 'URL类型，是URL就是1,是js方法，就是0。',
  `AUTO_DISAPPEAR` varchar(2) DEFAULT NULL COMMENT '是否自动消失',
  `DISAPPEAR_DATE` datetime DEFAULT NULL COMMENT '到期时间',
  `SEND_DEPTID` varchar(50) DEFAULT NULL COMMENT '发送人部门ID',
  `SYS_APPLICATION_ID` varchar(32) DEFAULT NULL COMMENT '所属应用ID',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统消息表，用于在系统中保存提示消息';

/*Data for the table `sys_message` */

/*Table structure for table `sys_org` */

DROP TABLE IF EXISTS `sys_org`;

CREATE TABLE `sys_org` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `ORG_CODE` varchar(100) NOT NULL COMMENT '组织代码',
  `PARENT_ORG_ID` varchar(100) NOT NULL COMMENT '父组织ID',
  `ORDER_BY` decimal(16,0) NOT NULL COMMENT '排序',
  `POST` varchar(50) DEFAULT NULL COMMENT '邮编',
  `TEL` varchar(50) DEFAULT NULL COMMENT '电话',
  `FAX` varchar(50) DEFAULT NULL COMMENT '传真',
  `EMAIL` varchar(50) DEFAULT NULL COMMENT '邮件',
  `WORK_CALENDAR_ID` varchar(50) DEFAULT NULL COMMENT '工作日历',
  `VALID_FLAG` varchar(1) NOT NULL COMMENT '设置组织是否有效，1-有效，0-无效',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `RESPONSIBLE_DEPT_ID` varchar(50) DEFAULT NULL COMMENT '该组织下负责部门ID，这个部门不一定组织的下级部门，也可以是部门的子部门，组织和对外接口部门是一对一的关系。\r\n\r\n用于在流程引擎中和多项目管理中确定一个组织的负责部门',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='多组织表';

/*Data for the table `sys_org` */

insert  into `sys_org` values ('8a58ab4d4c2141fd014c217c436a02b2','avicit','ORG_ROOT','1',NULL,NULL,NULL,NULL,NULL,'1','2015-03-16 00:00:00','1','2015-03-16 00:00:00','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('ORG_ROOT','ORG_ROOT','-1','1',NULL,NULL,NULL,NULL,NULL,'1','2015-05-11 16:33:47','1','2015-03-16 00:00:00','1','127.0.0.1','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

/*Table structure for table `sys_org_tl` */

DROP TABLE IF EXISTS `sys_org_tl`;

CREATE TABLE `sys_org_tl` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `SYS_ORG_ID` varchar(50) NOT NULL COMMENT '组织ID',
  `SYS_LANGUAGE_CODE` varchar(50) NOT NULL COMMENT '语言代码',
  `ORG_NAME` varchar(100) NOT NULL COMMENT '名称',
  `ORG_DESC` varchar(240) DEFAULT NULL COMMENT '描述',
  `ORG_PLACE` varchar(100) DEFAULT NULL COMMENT '办公地点',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='组织机构多语言表';

/*Data for the table `sys_org_tl` */

insert  into `sys_org_tl` values ('8a58ab4d4c2141fd014c217c437b02b4','8a58ab4d4c2141fd014c217c436a02b2','zh_CN','中航工业信息技术中心',NULL,NULL,'2015-03-16 15:28:54','1','2015-03-16 15:28:54','1','127.0.0.1','0'),('ORG_ROOT_TL','ORG_ROOT','zh_CN','中航工业',NULL,'组织机构','2015-05-11 16:33:47','1','2014-08-20 17:47:13','1','127.0.0.1','4');

/*Table structure for table `sys_password_configure` */

DROP TABLE IF EXISTS `sys_password_configure`;

CREATE TABLE `sys_password_configure` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '应用id',
  `CONFIGURE_KEY` varchar(50) DEFAULT NULL COMMENT '密码规则代码',
  `CONFIGURE_NAME` varchar(100) DEFAULT NULL COMMENT '密码规则中文名称',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='密码规则表';

/*Data for the table `sys_password_configure` */

insert  into `sys_password_configure` values ('-23456789',NULL,'firstLogin','首次登录修改密码(0-修改,1-不修改)','2015-09-15 23:00:00','1','2015-09-14 00:00:00','1','127.0.0.1','0'),('4028009e2238eb61012238f099d10001',NULL,'intensity','密码强度（最高为4级，最低为1级）','2010-12-17 15:49:51','1','2009-07-02 00:00:00','1','192.168.12.37','0'),('4028009e2238eb61012238f231c60003',NULL,'difference','密码差异度','2011-10-19 16:27:30','1','2009-07-02 00:00:00','1','0:0:0:0:0:0:0:1','0'),('4028009e2238eb61012238f623f80009',NULL,'distinctBefore','密码不能和以前多少次密码重复','2010-12-17 15:49:55','1','2009-07-02 00:00:00','1','192.168.12.37','0'),('4028009e2238eb61012238f7e6e5000b',NULL,'howLongModify','密码多少天需要修改一次','2012-05-25 09:29:54','1','2009-07-02 00:00:00','1','0:0:0:0:0:0:0:1','0'),('4028009e2238eb61012238fca281000d',NULL,'tipBeforeTime','密码到期多少天前提示','2010-12-17 15:50:00','1','2009-07-02 00:00:00','1','192.168.12.37','0'),('4028009e2238eb61012238fe7712000f',NULL,'modifyDefault','默认密码几天修改','2010-12-17 15:49:45','1','2009-07-02 00:00:00','1','192.168.12.37','0'),('4028009e2238eb610122390c9729001a',NULL,'howTimeLock','用户登录错误几次密码锁定','2011-11-10 15:56:57','1','2009-07-02 00:00:00','1','0:0:0:0:0:0:0:1','0'),('4028009e224e910201224ea9ca7d0005',NULL,'howLongLimitToLock','用户多少小时内登录失败限制','2011-11-10 16:29:11','1','2009-07-06 00:00:00','1','0:0:0:0:0:0:0:1','0'),('402800b1222ec7ca01222eca77bf0001',NULL,'maxlength','密码最大长度','2010-12-17 15:49:37','1','2009-06-30 00:00:00','1','192.168.12.37','0'),('402800b1222ec7ca01222ed2f5450003',NULL,'minlength','密码最小长度','2010-12-17 15:49:33','1','2009-06-30 00:00:00','1','192.168.12.37','0');

/*Table structure for table `sys_password_templet` */

DROP TABLE IF EXISTS `sys_password_templet`;

CREATE TABLE `sys_password_templet` (
  `ID` varchar(50) NOT NULL COMMENT '唯一标识',
  `TEMPLET_KEY` varchar(50) DEFAULT NULL COMMENT '密码规则KEY',
  `TEMPLET_VALUE` varchar(100) DEFAULT NULL COMMENT '密码规则值',
  `TEMPLET_STATE` varchar(1) DEFAULT NULL COMMENT '是否有效\r\n1有效，0无效， 默认1',
  `TEMPLET_TYPE` varchar(50) DEFAULT NULL COMMENT '密码模板类型（级别）',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='密码模板配置表';

/*Data for the table `sys_password_templet` */

insert  into `sys_password_templet` values ('402809814fc9e8a5014fca397185020e','difference','1','1','402809814fc9e8a5014fca39717b020d','2015-09-17 11:22:11','1','2015-09-14 13:00:06','1','10.216.77.215','1'),('402809814fc9e8a5014fca397187020f','maxlength','8','1','402809814fc9e8a5014fca39717b020d','2015-09-17 11:22:11','1','2015-09-14 13:00:06','1','10.216.77.215','1'),('402809814fc9e8a5014fca3971890210','minlength','5','1','402809814fc9e8a5014fca39717b020d','2015-09-17 11:22:11','1','2015-09-14 13:00:06','1','10.216.77.215','1'),('402809814fc9e8a5014fca39718a0211','howLongModify','90','1','402809814fc9e8a5014fca39717b020d','2015-09-28 15:56:13','1','2015-09-14 13:00:06','1','127.0.0.1','2'),('402809814fc9e8a5014fca39718b0212','modifyDefault','7','1','402809814fc9e8a5014fca39717b020d','2015-09-28 15:56:13','1','2015-09-14 13:00:06','1','127.0.0.1','2'),('402809814fc9e8a5014fca39718d0213','howTimeLock','5','1','402809814fc9e8a5014fca39717b020d','2015-09-28 15:56:13','1','2015-09-14 13:00:06','1','127.0.0.1','2'),('402809814fc9e8a5014fca39718e0214','intensity','2','1','402809814fc9e8a5014fca39717b020d','2015-09-17 11:22:10','1','2015-09-14 13:00:06','1','10.216.77.215','1'),('402809814fc9e8a5014fca39718f0215','distinctBefore','1','1','402809814fc9e8a5014fca39717b020d','2015-09-28 15:56:13','1','2015-09-14 13:00:06','1','127.0.0.1','2'),('402809814fc9e8a5014fca3971910216','tipBeforeTime','7','1','402809814fc9e8a5014fca39717b020d','2015-09-28 15:56:13','1','2015-09-14 13:00:06','1','127.0.0.1','2'),('402809814fc9e8a5014fca3971930217','howLongLimitToLock','2','1','402809814fc9e8a5014fca39717b020d','2015-09-17 11:22:11','1','2015-09-14 13:00:06','1','10.216.77.215','1'),('402809814fc9e8a5014fca3971940218','firstLogin','0','1','402809814fc9e8a5014fca39717b020d','2015-09-17 11:22:11','1','2015-09-14 13:00:06','1','10.216.77.215','1'),('402809814fc9e8a5014fca3acd7a021c','difference','2','1','402809814fc9e8a5014fca3acd70021b','2015-09-17 11:17:15','1','2015-09-14 13:01:35','1','10.216.77.215','1'),('402809814fc9e8a5014fca3acd7c021d','maxlength','8','1','402809814fc9e8a5014fca3acd70021b','2015-09-17 11:17:15','1','2015-09-14 13:01:35','1','10.216.77.215','1'),('402809814fc9e8a5014fca3acd7e021e','minlength','6','1','402809814fc9e8a5014fca3acd70021b','2015-09-17 11:17:15','1','2015-09-14 13:01:35','1','10.216.77.215','1'),('402809814fc9e8a5014fca3acd7f021f','howLongModify','4','1','402809814fc9e8a5014fca3acd70021b','2015-09-17 11:17:15','1','2015-09-14 13:01:35','1','10.216.77.215','1'),('402809814fc9e8a5014fca3acd800220','modifyDefault','60','1','402809814fc9e8a5014fca3acd70021b','2015-09-28 15:57:35','1','2015-09-14 13:01:35','1','127.0.0.1','2'),('402809814fc9e8a5014fca3acd820221','howTimeLock','4','1','402809814fc9e8a5014fca3acd70021b','2015-09-28 15:57:35','1','2015-09-14 13:01:35','1','127.0.0.1','2'),('402809814fc9e8a5014fca3acd830222','intensity','3','1','402809814fc9e8a5014fca3acd70021b','2015-09-17 11:17:15','1','2015-09-14 13:01:35','1','10.216.77.215','1'),('402809814fc9e8a5014fca3acd850223','distinctBefore','2','1','402809814fc9e8a5014fca3acd70021b','2015-09-28 15:57:35','1','2015-09-14 13:01:35','1','127.0.0.1','2'),('402809814fc9e8a5014fca3acd870224','tipBeforeTime','7','1','402809814fc9e8a5014fca3acd70021b','2015-09-28 15:57:35','1','2015-09-14 13:01:35','1','127.0.0.1','2'),('402809814fc9e8a5014fca3acd8a0225','howLongLimitToLock','4','1','402809814fc9e8a5014fca3acd70021b','2015-09-17 11:17:15','1','2015-09-14 13:01:35','1','10.216.77.215','1'),('402809814fc9e8a5014fca3acd8c0226','firstLogin','0','1','402809814fc9e8a5014fca3acd70021b','2015-09-17 11:17:15','1','2015-09-14 13:01:35','1','10.216.77.215','1'),('402809814fc9e8a5014fca3f57e6022a','difference','1','1','402809814fc9e8a5014fca3f57dd0229','2015-09-17 11:16:34','1','2015-09-14 13:06:33','1','10.216.77.215','1'),('402809814fc9e8a5014fca3f57e8022b','maxlength','8','1','402809814fc9e8a5014fca3f57dd0229','2015-09-17 11:16:34','1','2015-09-14 13:06:33','1','10.216.77.215','1'),('402809814fc9e8a5014fca3f57ea022c','minlength','8','1','402809814fc9e8a5014fca3f57dd0229','2015-09-17 11:21:30','1','2015-09-14 13:06:33','1','10.216.77.215','2'),('402809814fc9e8a5014fca3f57eb022d','howLongModify','30','1','402809814fc9e8a5014fca3f57dd0229','2015-09-28 15:58:43','1','2015-09-14 13:06:33','1','127.0.0.1','7'),('402809814fc9e8a5014fca3f57ec022e','modifyDefault','7','1','402809814fc9e8a5014fca3f57dd0229','2015-09-28 15:58:43','1','2015-09-14 13:06:33','1','127.0.0.1','7'),('402809814fc9e8a5014fca3f57ef022f','howTimeLock','3','1','402809814fc9e8a5014fca3f57dd0229','2015-09-16 14:19:32','1','2015-09-14 13:06:33','1','127.0.0.1','1'),('402809814fc9e8a5014fca3f57f20230','intensity','4','1','402809814fc9e8a5014fca3f57dd0229','2015-09-28 15:58:43','1','2015-09-14 13:06:33','1','127.0.0.1','2'),('402809814fc9e8a5014fca3f57f40231','distinctBefore','3','1','402809814fc9e8a5014fca3f57dd0229','2015-09-28 15:58:43','1','2015-09-14 13:06:33','1','127.0.0.1','3'),('402809814fc9e8a5014fca3f57f60232','tipBeforeTime','7','1','402809814fc9e8a5014fca3f57dd0229','2015-09-28 15:58:43','1','2015-09-14 13:06:33','1','127.0.0.1','3'),('402809814fc9e8a5014fca3f57f80233','howLongLimitToLock','6','1','402809814fc9e8a5014fca3f57dd0229','2015-09-28 15:58:43','1','2015-09-14 13:06:33','1','127.0.0.1','3'),('402809814fc9e8a5014fca3f57fa0234','firstLogin','0','1','402809814fc9e8a5014fca3f57dd0229','2015-09-16 11:16:17','1','2015-09-14 13:06:33','1','127.0.0.1','1'),('402809814fc9e8a5014fca401fcf0238','difference','1','0','402809814fc9e8a5014fca401fc40237','2015-09-16 16:11:30','1','2015-09-14 13:07:24','1','127.0.0.1','2'),('402809814fc9e8a5014fca401fd10239','maxlength','8','0','402809814fc9e8a5014fca401fc40237','2015-09-16 16:11:30','1','2015-09-14 13:07:24','1','127.0.0.1','2'),('402809814fc9e8a5014fca401fd2023a','minlength','3','0','402809814fc9e8a5014fca401fc40237','2015-09-16 16:11:30','1','2015-09-14 13:07:24','1','127.0.0.1','2'),('402809814fc9e8a5014fca401fd4023b','howLongModify','3','0','402809814fc9e8a5014fca401fc40237','2015-09-16 16:11:30','1','2015-09-14 13:07:24','1','127.0.0.1','2'),('402809814fc9e8a5014fca401fd6023c','modifyDefault','3','0','402809814fc9e8a5014fca401fc40237','2015-09-16 16:11:30','1','2015-09-14 13:07:24','1','127.0.0.1','2'),('402809814fc9e8a5014fca401fd8023d','howTimeLock','8','1','402809814fc9e8a5014fca401fc40237','2015-09-17 11:16:07','1','2015-09-14 13:07:24','1','10.216.77.215','3'),('402809814fc9e8a5014fca401fda023e','intensity','4','0','402809814fc9e8a5014fca401fc40237','2015-09-16 16:11:30','1','2015-09-14 13:07:24','1','127.0.0.1','2'),('402809814fc9e8a5014fca401fdc023f','distinctBefore','2','0','402809814fc9e8a5014fca401fc40237','2015-09-16 16:11:30','1','2015-09-14 13:07:24','1','127.0.0.1','2'),('402809814fc9e8a5014fca401fdd0240','tipBeforeTime','2','0','402809814fc9e8a5014fca401fc40237','2015-09-16 16:11:30','1','2015-09-14 13:07:24','1','127.0.0.1','2'),('402809814fc9e8a5014fca401fde0241','howLongLimitToLock','2','1','402809814fc9e8a5014fca401fc40237','2015-09-17 11:16:15','1','2015-09-14 13:07:24','1','10.216.77.215','3'),('402809814fc9e8a5014fca401fe00242','firstLogin','1','0','402809814fc9e8a5014fca401fc40237','2015-09-16 16:11:30','1','2015-09-14 13:07:24','1','127.0.0.1','4');

/*Table structure for table `sys_password_templet_level` */

DROP TABLE IF EXISTS `sys_password_templet_level`;

CREATE TABLE `sys_password_templet_level` (
  `ID` varchar(50) NOT NULL COMMENT '唯一标识',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '应用ID',
  `KEY` varchar(100) DEFAULT NULL COMMENT '模板名称',
  `CODE` varchar(100) DEFAULT NULL COMMENT '模板编码',
  `USER_LEVEL_CODE` varchar(50) DEFAULT NULL COMMENT '人员密级\r\n关联数据字典',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='密码模板表';

/*Data for the table `sys_password_templet_level` */

insert  into `sys_password_templet_level` values ('402809814fc9e8a5014fca39717b020d','1','一般涉密人员','secret_level_3','2','2015-09-14 13:00:06','1','2015-09-14 13:00:06','1','127.0.0.1','0'),('402809814fc9e8a5014fca3acd70021b','1','重点涉密人员','secret_level_2','3','2015-09-14 13:01:35','1','2015-09-14 13:01:35','1','127.0.0.1','0'),('402809814fc9e8a5014fca3f57dd0229','1','核心涉密人员','secret_level_1','4','2016-03-08 11:12:00','1','2015-09-14 13:06:33','1','127.0.0.1','2'),('402809814fc9e8a5014fca401fc40237','1','非涉密人员','secret_level_4','1','2015-09-14 13:07:24','1','2015-09-14 13:07:24','1','127.0.0.1','0');

/*Table structure for table `sys_permission_access` */

DROP TABLE IF EXISTS `sys_permission_access`;

CREATE TABLE `sys_permission_access` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `RESOURCE_ID` varchar(50) NOT NULL COMMENT '权限资源ID',
  `TYPE` decimal(1,0) DEFAULT NULL COMMENT '权限控制类型：3，全局；2，跨部门领导；1，部门领导；0，个人',
  `ACCESS_USER` longtext COMMENT '可以访问的用户',
  `ACCESS_ROLE` longtext COMMENT '可以访问的角色',
  `ACCESS_DEPT` longtext COMMENT '可以访问的部门',
  `ACCESS_GROUP` longtext COMMENT '可以访问的群组',
  `ACCESS_POSITION` longtext COMMENT '可以访问的岗位',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ISSQL` varchar(1) DEFAULT NULL COMMENT '1：sql语句，2：sql条件',
  `PRESQL` longtext COMMENT '前置SQL',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='数据权限分配表';

/*Data for the table `sys_permission_access` */

/*Table structure for table `sys_permission_leaddept` */

DROP TABLE IF EXISTS `sys_permission_leaddept`;

CREATE TABLE `sys_permission_leaddept` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `USER_ID` varchar(50) NOT NULL COMMENT '员工id',
  `DEPT_ID` longtext COMMENT '所管部门id',
  `STATUS` varchar(1) DEFAULT NULL COMMENT '状态',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '最后修改ip',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='数据权限：领导业务部门表';

/*Data for the table `sys_permission_leaddept` */

/*Table structure for table `sys_permission_resource` */

DROP TABLE IF EXISTS `sys_permission_resource`;

CREATE TABLE `sys_permission_resource` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `PARENT_ID` varchar(50) DEFAULT NULL COMMENT '对应的菜单页面id',
  `DATAGRID` text COMMENT '菜单中datagrid控件id',
  `DATASET` text COMMENT 'datagrid对应的dataset',
  `DATATYPE` text COMMENT 'dataset中的datatype',
  `METADATA` text COMMENT 'datatype中对应dbm文件中的compositeTable的id',
  `SQL` longtext COMMENT '资源过滤前置SQL',
  `STATUS` varchar(1) DEFAULT NULL COMMENT '权限资源状态',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `IS_SECRET` varchar(1) DEFAULT NULL COMMENT '是否启用密级过滤，1：启用，0：不启用',
  `HAVE_SECRET` varchar(1) DEFAULT NULL COMMENT '是否拥有密级控制，0：没有，1：有',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统数据权限过滤资源表';

/*Data for the table `sys_permission_resource` */

/*Table structure for table `sys_portal` */

DROP TABLE IF EXISTS `sys_portal`;

CREATE TABLE `sys_portal` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `SYS_USER_ID` varchar(50) DEFAULT NULL COMMENT '当前登陆人',
  `LAYOUT_KEY` varchar(50) DEFAULT NULL COMMENT '布局key值',
  `LAYOUT_CONTENT` text COMMENT '布局内容',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` text COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` text COMMENT '扩展字段',
  `CHANNEL_ID` varchar(32) DEFAULT NULL COMMENT '频道表ID',
  `BLOCK_PROPERTY` text COMMENT '板块属性',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='portal表';

/*Data for the table `sys_portal` */

/*Table structure for table `sys_portlet_config` */

DROP TABLE IF EXISTS `sys_portlet_config`;

CREATE TABLE `sys_portlet_config` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `USERID` varchar(100) DEFAULT NULL COMMENT '用户id',
  `LAYOUT_EXTENDS` text COMMENT '角色名称，以","分割',
  `LAYOUT` varchar(50) DEFAULT NULL COMMENT '布局',
  `ORDER_BY` decimal(16,0) NOT NULL COMMENT '排序',
  `LAST_UPDATE_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` varchar(50) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `CREATED_BY` varchar(50) NOT NULL,
  `LAST_UPDATE_IP` varchar(50) NOT NULL,
  `VERSION` decimal(16,0) NOT NULL,
  `CONTENT` text,
  `NAME` varchar(50) DEFAULT NULL COMMENT '模版名称',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` text COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` text COMMENT '扩展字段',
  `ROLE_ID` text COMMENT '角色id集合，以","分割',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL,
  `USAGE_MODIFIER` varchar(1) DEFAULT NULL COMMENT '0 公有可用     1私有可用',
  `INDEX_URL` text COMMENT '首页地址',
  `INDEX_TYPE` varchar(1) DEFAULT NULL COMMENT '首页类型0系统首页1自定义首页',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sys_portlet_config` */

insert  into `sys_portlet_config` values ('8a58cd5b4d5acbde014d5bae5ddf004c','1','一般用户','layout1.xml','10','2015-05-16 15:46:00','1','2015-05-16 15:44:23','1','0:0:0:0:0:0:0:1','1',NULL,'默认首页布局模版',NULL,'layout_row_1;8a58a6b44c275bab014c2762df17001d;0:0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'8a58ab5f4be29ef7014be2d442bd01ab','1',NULL,NULL,'0');

/*Table structure for table `sys_portlet_menu` */

DROP TABLE IF EXISTS `sys_portlet_menu`;

CREATE TABLE `sys_portlet_menu` (
  `ID` varchar(32) NOT NULL,
  `PORTLET_CONFIG_ID` varchar(32) NOT NULL,
  `PARENT_ID` varchar(32) NOT NULL,
  `TEXT` varchar(100) DEFAULT NULL,
  `BEFORE_ID` varchar(32) DEFAULT NULL,
  `AFTER_ID` varchar(32) DEFAULT NULL,
  `LAST_UPDATE_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` varchar(50) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `CREATED_BY` varchar(50) NOT NULL,
  `LAST_UPDATE_IP` varchar(50) NOT NULL,
  `VERSION` decimal(16,0) NOT NULL,
  `MENU_ID` varchar(32) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='12';

/*Data for the table `sys_portlet_menu` */

/*Table structure for table `sys_position` */

DROP TABLE IF EXISTS `sys_position`;

CREATE TABLE `sys_position` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `ORG_ID` varchar(50) NOT NULL COMMENT '组织ID',
  `POSITION_CODE` varchar(50) NOT NULL COMMENT '职位代码',
  `ORDER_BY` decimal(16,0) NOT NULL COMMENT '排序',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='岗位表';

/*Data for the table `sys_position` */

insert  into `sys_position` values ('1','40288af5382c969e01382c9aea98000a','010','8','2013-07-18 09:18:13','1','2012-07-10 17:27:34','1','0:0:0:0:0:0:0:1','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

/*Table structure for table `sys_position_tl` */

DROP TABLE IF EXISTS `sys_position_tl`;

CREATE TABLE `sys_position_tl` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `SYS_POSITION_ID` varchar(50) NOT NULL COMMENT '岗位表的主键',
  `SYS_LANGUAGE_CODE` varchar(50) NOT NULL COMMENT '语言代码',
  `POSITION_NAME` varchar(100) NOT NULL COMMENT '名称',
  `POSITION_DESC` varchar(240) DEFAULT NULL COMMENT '描述',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='岗位多语言表';

/*Data for the table `sys_position_tl` */

insert  into `sys_position_tl` values ('40288af9386fe46a0138703716780007','1','zh_CN','普通员工','普通员工','2013-07-18 09:18:13','1','2012-07-10 17:27:34','1','0:0:0:0:0:0:0:1','7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

/*Table structure for table `sys_profile_option` */

DROP TABLE IF EXISTS `sys_profile_option`;

CREATE TABLE `sys_profile_option` (
  `ID` varchar(50) NOT NULL COMMENT '唯一标识',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '应用ID',
  `PROFILE_OPTION_CODE` varchar(50) DEFAULT NULL COMMENT '配置文件代码',
  `PROFILE_OPTION_NAME` varchar(100) DEFAULT NULL COMMENT '配置文件名称',
  `DESCRIPTION` varchar(240) DEFAULT NULL COMMENT '描述',
  `YN_MULTI_VALUE` varchar(1) DEFAULT NULL COMMENT '是否多值\r\nY 是 N 否',
  `USER_CHANGEABLE_FLAG` varchar(1) DEFAULT NULL COMMENT '用户可更新标识\r\nY代表可以，N代表不可以，默认为Y',
  `USER_VISIBLE_FLAG` varchar(1) DEFAULT NULL COMMENT '用户可查看标识\r\nY代表可以，N代表不可以，默认为Y',
  `SITE_ENABLED_FLAG` varchar(1) DEFAULT NULL COMMENT '地点层可见\r\nY代表可以，N代表不可以，默认为Y',
  `APP_ENABLED_FLAG` varchar(1) DEFAULT NULL COMMENT '应用程序层可见\r\nY代表可以，N代表不可以，默认为Y',
  `ROLE_ENABLED_FLAG` varchar(1) DEFAULT NULL COMMENT '角色层可见\r\nY代表可以，N代表不可以，默认为Y',
  `USER_ENABLED_FLAG` varchar(1) DEFAULT NULL COMMENT '用户层可见\r\nY代表可以，N代表不可以，默认为Y',
  `DEPT_ENABLED_FLAG` varchar(1) DEFAULT NULL COMMENT '部门启用标记\r\nY代表可以，N代表不可以，默认为Y',
  `SQL_VALIDATION` text COMMENT 'SQL校验\r\n用于配置文件选项的值列表的SQL验证',
  `VALID_FLAG` varchar(1) DEFAULT NULL COMMENT '状态\r\n1代表有效,0代表无效 默认为1',
  `SYSTEM_FLAG` varchar(1) DEFAULT NULL COMMENT '是否为系统初始\r\nY 是 N 否',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `USAGE_MODIFIER` varchar(1) DEFAULT NULL COMMENT '0 公有可用     1私有可用',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='配置管理表';

/*Data for the table `sys_profile_option` */

insert  into `sys_profile_option` values ('40288a1538e6c7750138e6c908010004','1','PLATFORM_V6_DEFALUT_URL','V6平台默认登陆的首页',NULL,'N','N','N','Y','N','N','N','N',NULL,'1','0','2012-08-02 18:02:32','1','2012-08-02 18:02:10','1','0:0:0:0:0:0:0:1','0','0'),('40288ace393216cf0139322c6abf0006','1','PLATFORM_V6_DEFAULT_ICON_IMAGE','平台V6中默认图标',NULL,'N','N','N','Y','N','N','N','N',NULL,'1','0','2012-08-17 09:22:15','1','2012-08-17 09:22:15','1','0:0:0:0:0:0:0:1','0','0'),('40288ace394ce30601394d8c1cc60008','1','PLATFORM_V6_DISPLAY_DIV_ICON','显示弹出卡片中menu的图标',NULL,'N','N','N','Y','N','N','N','N','select a.lookup_code as id, a.lookup_code as code, a.lookup_name as name  from sys_lookup_v a  where a.lookup_Type = \'PLATFORM_SYSTEM_BOOLEAN_FLAG\'','1','0','2012-08-22 16:56:31','1','2012-08-22 16:56:31','1','0:0:0:0:0:0:0:1','0','0'),('40288ace394ce30601394d8cf991000a','1','PLATFORM_V6_DISPLAY_TAB_ICON','菜单选项显示tab标签上是否用配置信息',NULL,'N','N','N','Y','N','N','N','N','select a.lookup_code as id, a.lookup_code as code, a.lookup_name as name  from sys_lookup_v a  where a.lookup_Type = \'PLATFORM_SYSTEM_BOOLEAN_FLAG\'','1','0','2012-08-23 21:13:55','1','2012-08-22 16:57:28','1','0:0:0:0:0:0:0:1','1','0'),('40288ace39538b830139538fdf270002','1','PLATFORM_V6_PMO_FIRST_TITLE_ICON','多项目弹出层中顶层菜单图标路径',NULL,'N','N','N','Y','N','N','N','N',NULL,'1','0','2012-08-23 20:58:21','1','2012-08-23 20:58:21','1','0:0:0:0:0:0:0:1','0','0'),('40288ace39538b8301395390c9510004','1','PLATFORM_V6_PMO_SECONDE_TITLE_ICON','多项目弹出层中第二层菜单图标路径',NULL,'N','N','N','Y','N','N','N','N',NULL,'1','0','2012-08-23 20:59:40','1','2012-08-23 20:59:21','1','0:0:0:0:0:0:0:1','0','0'),('40288ad4394e30c501394e9fd8f4000c','1','PLATFORM_V6_MESSAGE_REQUEST_INTERVAL','平台V6消息请求时间间隔配置',NULL,'N','N','N','Y','Y','N','N','N',NULL,'1','0','2013-06-08 08:35:31','1','2012-08-22 21:57:42','1','0:0:0:0:0:0:0:1','0','0'),('40288ad6398c30f301398c3683b00016','1','PLATFORM_V6_DISPLAY_SEARCH','V6平台是否显示搜索框',NULL,'N','N','N','Y','N','N','N','N','select a.lookup_code as id, a.lookup_code as code, a.lookup_name as name  from sys_lookup_v a  where a.lookup_Type = \'PLATFORM_SYSTEM_BOOLEAN_FLAG\'','1','0','2012-09-03 21:08:39','1','2012-09-03 20:59:06','1','0:0:0:0:0:0:0:1','0','0'),('40288ae2390e428601390e6a07550006','1','PLATFORM_V6_DISPLAY_ICON_DESC','V6平台控制菜单的描述信息是否显示',NULL,'N','N','N','Y','N','N','N','N','select a.lookup_code as id, a.lookup_code as code, a.lookup_name as name  from sys_lookup_v a  where a.lookup_Type = \'PLATFORM_SYSTEM_BOOLEAN_FLAG\'','1','0','2012-08-16 19:30:08','1','2012-08-10 10:43:13','1','fe80:0:0:0:f8d9:ad14:a9ba:1957','2','0'),('40288ae2390e8b1701390f2b4de50016','1','PLATFORM_V6_DISPLAY_ICON_TIPS','V6平台控制弹出式选项卡的提示信息',NULL,'N','N','N','Y','N','N','N','N','select a.lookup_code as id, a.lookup_code as code, a.lookup_name as name  from sys_lookup_v a  where a.lookup_Type = \'PLATFORM_SYSTEM_BOOLEAN_FLAG\'','1','0','2012-08-10 14:14:19','1','2012-08-10 14:14:19','1','0:0:0:0:0:0:0:1','1','0'),('8a58ab2e3e5ea5ca013e5eb02ec70003','1','PLATFORM_V6_DEFAULT_PASSWORD','V6平台系统默认密码',NULL,'N','N','N','Y','N','N','N','N',NULL,'1','0','2013-05-01 14:03:24','1','2013-05-01 14:03:24','1','127.0.0.1','0','0'),('8a58ab3940339fcb014033ad70980003','1','PLATFORM_V6_REGISTER_ENABLED','V6平台是否支持注册功能',NULL,'N','N','N','Y','N','N','N','N','select a.lookup_code as id, a.lookup_code as code, a.lookup_name as name  from sys_lookup_v a  where a.lookup_Type = \'PLATFORM_SYSTEM_BOOLEAN_FLAG\' order by id','1','0','2013-07-31 15:48:54','1','2013-07-31 15:42:19','1','0:0:0:0:0:0:0:1','0','0'),('8a58ab4d4c45da24014c45e4e9c7008e','1','PLATFORM_V6_DEFAULT_SKIN','优先皮肤',NULL,'Y',NULL,NULL,'Y','N','N','N','N','select a.lookup_code as id, a.lookup_code as code, a.lookup_name as name  from sys_lookup_v a  where a.lookup_Type = \'PLATFORM_SYSTEM_SKIN\' order by id','1','0','2015-03-23 17:09:32','1','2015-03-23 17:09:32','1','127.0.0.1','2','0'),('8a58ab574c96918e014c9697bad00006','1','PLATFORM_V6_DEFAULT_SKIN_SWITCH','优先皮肤是否可换肤开关',NULL,'Y',NULL,NULL,'Y','N','N','N','N','select a.lookup_code as id, a.lookup_code as code, a.lookup_name as name  from sys_lookup_v a where a.lookup_Type = \'PLATFORM_SYSTEM_BOOLEAN_FLAG\'','1','0','2015-04-08 09:14:28','1','2015-04-08 09:14:28','1','127.0.0.1','0','0'),('8a58abb23bb26986013bb285af640030','1','PLATFORM_V6_MESSAGE_DIALOG_SHOW','V6平台消息弹出框控制显隐',NULL,'N','N','N','Y','N','N','N','N','select a.lookup_code as id, a.lookup_code as code, a.lookup_name as name  from sys_lookup_v a  where a.lookup_Type = \'PLATFORM_SYSTEM_BOOLEAN_FLAG\'','1','0','2012-12-19 17:37:04','1','2012-12-19 17:36:43','1','0:0:0:0:0:0:0:1','0','0'),('8a58abf94521bf0c014521c6bc330003','1','PLATFORM_V6_LOGINCHECK_CONTROL','平台三员控制开关',NULL,'N','N','N','Y','N','N','N','N','select a.lookup_code as id, a.lookup_code as code, a.lookup_name as name  from sys_lookup_v a  where a.lookup_Type = \'PLATFORM_SYSTEM_BOOLEAN_FLAG\'','1','0','2014-04-02 17:30:43','1','2014-04-02 17:30:43','1','0:0:0:0:0:0:0:1','1','0'),('8a58cd5750119bff015011ab1b33004c','1','PLATFORM_V6_COPYRIGHT','首页版权内容',NULL,'Y',NULL,NULL,'Y','N','N','N','N',NULL,'1','0','2015-09-28 09:57:17','1','2015-09-28 09:57:17','1','127.0.0.1','0','0'),('8a58cd575353d8f5015353ddc9080054','1','PLATFORM_SYSLOG_THRESHOLD','系统日志记录阈值(单位万条)',NULL,'Y',NULL,NULL,'Y','N','N','N','N',NULL,'1','0','2016-03-08 09:35:57','1','2016-03-08 09:35:57','1','127.0.0.1','1','0'),('8a58cd5b4d45c71e014d45d80804000e','1','PLATFORM_V6_FINE_REPORT_URL','软帆报表服务URL',NULL,'Y',NULL,NULL,'Y','N','N','N','N',NULL,'1','0','2015-05-12 09:58:15','1','2015-05-12 09:58:15','1','0:0:0:0:0:0:0:1','0','0');

/*Table structure for table `sys_profile_option_value` */

DROP TABLE IF EXISTS `sys_profile_option_value`;

CREATE TABLE `sys_profile_option_value` (
  `ID` varchar(50) NOT NULL COMMENT '唯一标识',
  `SYS_PROFILE_OPTIONS_ID` varchar(50) DEFAULT NULL COMMENT '配置文件ID\r\n从SYS_PROFILE_OPTIONS表中获得ID的值',
  `PROFILE_LEVEL_CODE` varchar(1) DEFAULT NULL COMMENT '级别编号\r\n1、地点 2、应用 3、角色 4、用户 5、组织',
  `LEVEL_VALUE` varchar(50) DEFAULT NULL COMMENT '级别值\r\n地点ID、应用ID、角色ID、用户ID、组织ID',
  `PROFILE_OPTION_VALUE` text COMMENT '配置文件选项值\r\n对应PROFILE比表SQL的ID',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='配置文件选项表';

/*Data for the table `sys_profile_option_value` */

insert  into `sys_profile_option_value` values ('402809814d56710c014d5674e240000c','8a58ab574c96918e014c9697bad00006','1','1','true','2016-04-05 10:17:34','1','2015-05-15 15:23:30','1','127.0.0.1','8'),('402809814d56bbe0014d56c33e450007','8a58cd5b4d45c71e014d45d80804000e','1','1','http://localhost:8075/WebReport','2015-05-15 16:49:05','1','2015-05-15 16:49:05','1','127.0.0.1','0'),('40288a1538e6c7750138e6c9322f0007','40288a1538e6c7750138e6c908010004','1','1','avicit/platform6/modules/system/sysdashboard/index.jsp','2015-10-14 18:10:44','1','2012-08-02 18:02:21','1','0:0:0:0:0:0:0:1','5'),('40288ace393216cf0139322cb5660009','40288ace393216cf0139322c6abf0006','1','1','static/css/platform/themes/default/index/style/images/folder_lightbulb.png','2015-03-10 11:04:32','1','2012-08-17 09:22:34','1','127.0.0.1','0'),('40288ace394ce30601394d8d2259000d','40288ace394ce30601394d8cf991000a','1','1','true','2016-03-10 14:55:16','1','2012-08-22 16:57:38','1','127.0.0.1','8'),('40288ace394ce30601394d8ea0170010','40288ace394ce30601394d8c1cc60008','1','1','true','2016-03-10 14:55:20','1','2012-08-22 16:59:16','1','127.0.0.1','4'),('40288ace395109ff013951a068de0003','40288ae2390e8b1701390f2b4de50016','1','1','false','2016-03-11 16:44:58','1','2012-08-23 11:57:10','1','127.0.0.1','1'),('40288ace39538b8301395391c9c90008','40288ace39538b8301395390c9510004','1','1','static/images/platform/sysmenu/arrowIcon.png','2015-03-07 14:38:03','1','2012-08-23 21:00:26','1','127.0.0.1','0'),('40288ace39538b8301395391ffc5000b','40288ace39538b830139538fdf270002','1','1','static/images/platform/sysmenu/barIcon.png','2015-04-03 15:10:05','1','2012-08-23 21:00:40','1','127.0.0.1','1'),('40288ad4394e30c501394ea179b5000f','40288ad4394e30c501394e9fd8f4000c','1','2','30000','2013-06-07 10:17:53','1','2012-08-22 21:59:28','1','0:0:0:0:0:0:0:1','0'),('40288ad6398c30f301398c370d4c001a','40288ad6398c30f301398c3683b00016','1','1','false','2016-03-08 14:34:15','1','2012-09-03 20:59:41','1','127.0.0.1','1'),('40288ae2390e428601390e6a3f610009','40288ae2390e428601390e6a07550006','1','1','false','2016-03-11 16:45:13','1','2012-08-10 10:43:27','1','127.0.0.1','1'),('8a58a6b44bf22019014bfd0dfd74092e','8a58abf94521bf0c014521c6bc330003','1','1','false','2016-03-14 11:09:47','1','2015-03-09 13:42:07','1','127.0.0.1','2'),('8a58ab2e3e5eeeb0013e5ef02d3c0004','8a58ab2e3e5ea5ca013e5eb02ec70003','1','1','cape','2014-11-20 16:46:46','1','2013-05-01 15:13:18','1','127.0.0.1','0'),('8a58ab3940339fcb014033addf1a0007','8a58ab3940339fcb014033ad70980003','1','1','false','2013-07-31 15:42:47','1','2013-07-31 15:42:47','1','0:0:0:0:0:0:0:1','0'),('8a58ab4d4c45da24014c45e526c50090','8a58ab4d4c45da24014c45e4e9c7008e','1','1','azure','2016-03-14 10:43:31','1','2015-03-23 17:09:47','1','127.0.0.1','3'),('8a58abb23bb26986013bb2862c5f0034','8a58abb23bb26986013bb285af640030','1','1','false','2013-06-07 13:46:00','1','2012-12-19 17:37:15','1','0:0:0:0:0:0:0:1','0'),('8a58cd57535417350153541c9c58004a','8a58cd575353d8f5015353ddc9080054','1','1','90','2016-03-08 10:47:16','1','2016-03-08 10:44:34','1','127.0.0.1','1');

/*Table structure for table `sys_resource` */

DROP TABLE IF EXISTS `sys_resource`;

CREATE TABLE `sys_resource` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `KEY` varchar(200) DEFAULT NULL COMMENT '资源名称',
  `VALUE` text COMMENT '资源值',
  `TYPE` varchar(50) DEFAULT NULL COMMENT '是全局表单还是节点表单，global，activity',
  `RESOURCE_DESC` text COMMENT '描述',
  `PARENT_ID` varchar(50) DEFAULT NULL COMMENT '父资源ID',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '应用ID',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统资源，用于对资源进行权限控制';

/*Data for the table `sys_resource` */

insert  into `sys_resource` values ('402809814db30afe014db30c4e18008e','集中管控',NULL,'MENU',NULL,'1','1','2016-03-14 13:23:05','1','2015-06-02 14:53:00','1','127.0.0.1','12',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('402809814dff7814014dff92ebb900d6','用户集中管理','platform/cc/sysuser/sysuserinfo','MENU',NULL,'8a58cd574df6657e014df670084400d0','1','2015-09-29 16:02:51','1','2015-06-17 11:32:00','1','127.0.0.1','5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('402809814dfff8d6014dfffa122d00cd','组织集中管理','platform/cc/sysorg/sysorginfo','MENU',NULL,'8a58cd574df6657e014df670084400d0','1','2015-09-29 16:02:32','1','2015-06-17 00:00:00','1','127.0.0.1','9',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('402809814dfff8d6014dfffad0c600d2','岗位集中管理','platform/cc/sysposition/syspositioninfo','MENU',NULL,'8a58cd574df6657e014df670084400d0','1','2015-09-29 16:02:44','1','2015-06-17 13:25:00','1','127.0.0.1','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('402809814dfff8d6014dfffc115900dd','群组集中管理','platform/cc/sysgroup/sysgroupinfo','MENU',NULL,'8a58cd574df6657e014df670084400d0','1','2015-09-29 16:03:03','1','2015-06-17 13:26:00','1','127.0.0.1','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('402809814dfff8d6014dfffc8d2300e2','角色集中管理','platform/cc/sysrole/sysroleinfo','MENU',NULL,'8a58cd574df6657e014df670084400d0','1','2015-09-29 16:03:10','1','2015-06-17 13:27:00','1','127.0.0.1','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('402809814dfff8d6014dffffee5200ea','系统配置集中管理',NULL,'MENU',NULL,'402809814db30afe014db30c4e18008e','1','2015-09-29 16:02:21','1','2015-06-17 13:31:00','1','127.0.0.1','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('402809814dfff8d6014e000128e800f2','菜单集中管理','platform/cc/sysmenu/sysmenuinfo','MENU',NULL,'402809814dfff8d6014dffffee5200ea','1','2015-09-29 15:55:53','1','2015-06-17 13:32:00','1','127.0.0.1','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('402809814dfff8d6014e00026efb00f7','系统参数集中管理','platform/cc/sysprofile/sysprofileinfo','MENU',NULL,'402809814dfff8d6014dffffee5200ea','1','2015-09-29 16:06:48','1','2015-06-17 13:33:00','1','127.0.0.1','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('402809814e0065ed014e006a7fae00cd','用户关系集中管理','platform/cc/userrelation/userrelationinfo','MENU',NULL,'8a58cd574df6657e014df670084400d0','1','2015-09-29 16:02:57','1','2015-06-17 15:27:00','1','127.0.0.1','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('402809814e0464bd014e0468318700ce','多应用集中管理','platform/cc/sysapp/sysappinfo','MENU',NULL,'402809814dfff8d6014dffffee5200ea','1','2015-09-29 16:07:14','1','2015-06-18 10:03:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('402809814e1f2ee8014e1f3223a200c6','多应用权限管理','platform/cc/sysapprole/sysapproleinfo','MENU',NULL,'402809814dfff8d6014dffffee5200ea','1','2015-09-29 16:07:06','1','2015-06-23 14:54:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('402809814e472359014e4727572e00ca','数据权限集中管理','platform/cc/permissionresource/permissionresourceinfo','MENU',NULL,'8a58cd5b4e3ce0ac014e3ce2bb1500ca','1','2015-09-29 16:03:37','1','2015-07-01 09:07:00','1','127.0.0.1','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('402809814e51ecf1014e51f268c800cc','跨部门领导管理','platform/cc/crossdept/crossdeptinfo','MENU',NULL,'8a58cd5b4e3ce0ac014e3ce2bb1500ca','1','2015-09-29 16:06:12','1','2015-07-03 11:25:00','1','127.0.0.1','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('402809814f2a5144014f2ab7c74d0050','编码管理','avicit/platform6/modules/system/syscodingrule/sysCodingRuleManager.jsp','MENU',NULL,'8a58c8434d468f93014d469b1dca001c','1','2015-08-14 16:44:28','1','2015-08-14 13:38:51','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('402809814f2a5144014f2ab893490055','多维通用代码','avicit/platform6/modules/system/syslookuphibearchy/sysLookupHibearchyManager.jsp','MENU',NULL,'8a58c8434d468f93014d469b1dca001c','1','2015-08-14 13:39:43','1','2015-08-14 13:39:43','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('40283f874f25ed9f014f2607b02200dc','编码集中管理','avicit/platform6/centralcontrol/syscodingrule/sysCodingRuleManager.jsp','MENU',NULL,'402809814dfff8d6014dffffee5200ea','1','2015-09-29 16:08:06','1','2015-08-13 15:48:00','1','127.0.0.1','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c275bab014c275fdd42000e','门户小页',NULL,'MENU',NULL,'1','1','2015-03-17 18:55:36','1','2015-03-17 18:55:36','1','10.216.43.205','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c275bab014c2762df17001d','我的待办事务','avicit/platform6/bpmclient/bpm/Todo.jsp','MENU',NULL,'8a58a6b44c275bab014c275fdd42000e','1','2015-03-17 18:58:53','1','2015-03-17 18:58:53','1','10.216.43.205','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c275bab014c27648454002c','系统首页','avicit/platform6/modules/system/sysdashboard/indexPortlet.jsp','MENU',NULL,'1','1','2015-03-17 19:00:41','1','2015-03-17 19:00:41','1','10.216.43.205','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c275bab014c2765ee040031','个人事务',NULL,'MENU',NULL,'1','1','2016-03-10 16:16:41','1','2015-03-17 19:02:13','1','127.0.0.1','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c275bab014c27675b0c0036','我的流程','avicit/platform6/bpmclient/bpm/MyProcessInstanceList.jsp','MENU',NULL,'8a58a6b44c275bab014c2765ee040031','1','2015-03-17 19:03:47','1','2015-03-17 19:03:47','1','10.216.43.205','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c275bab014c2767bd9c003b','我的工作','avicit/platform6/bpmclient/bpm/ProcessWork.jsp','MENU',NULL,'8a58a6b44c275bab014c2765ee040031','1','2015-03-17 19:04:12','1','2015-03-17 19:04:12','1','10.216.43.205','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c275bab014c2768570b0040','工作移交','avicit/platform6/bpmclient/workhand/workhandlist.jsp','MENU',NULL,'8a58a6b44c275bab014c2765ee040031','1','2015-03-17 19:04:51','1','2015-03-17 19:04:51','1','10.216.43.205','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c276b708c0003','系统管理',NULL,'MENU',NULL,'1','1','2016-03-14 13:22:57','1','2015-03-17 19:08:14','1','127.0.0.1','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c276bcc2d0008','组织机构管理',NULL,'MENU',NULL,'8a58a6b44c276a3f014c276b708c0003','1','2015-05-12 13:46:23','1','2015-03-17 19:08:38','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c276e44d00018','组织管理','platform/sysorg/sysOrgController/toSysOrgList','MENU',NULL,'8a58a6b44c276a3f014c276bcc2d0008','1','2015-04-10 15:37:02','1','2015-03-17 19:11:20','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c276ea970001d','部门用户管理','platform//sysdept/sysDeptController/sysDeptInfo','MENU',NULL,'8a58a6b44c276a3f014c276bcc2d0008','1','2015-04-10 15:40:57','1','2015-03-17 19:11:46','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c276f21ee0022','岗位管理','platform/sysposition/sysPositionController/positionlistinfo','MENU',NULL,'8a58a6b44c276a3f014c276bcc2d0008','1','2015-03-17 19:12:16','1','2015-03-17 19:12:16','1','10.216.43.205','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c276f9f1a0027','用户管理','platform/sysuser/userlistinfo','MENU',NULL,'8a58a6b44c276a3f014c276bcc2d0008','1','2015-05-12 13:21:22','1','2015-03-17 19:12:48','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c2a5b2a320040','个人设置','platform/syscustomed/sysCustomedController/toSyscustomed','MENU',NULL,'8a58a6b44c276a3f014c276b708c0003','1','2015-05-12 14:12:09','1','2015-03-18 08:49:19','1','127.0.0.1','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c2a5f00fc0057','授权管理',NULL,'MENU',NULL,'8a58a6b44c276a3f014c276b708c0003','1','2015-05-12 14:13:23','1','2015-03-18 08:53:31','1','127.0.0.1','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c2a6076d10061','菜单授权管理','platform/sysAccessControlController/menuAuthManager','MENU',NULL,'8a58a6b44c276a3f014c2a5f00fc0057','1','2015-05-12 13:48:23','1','2015-03-18 08:55:07','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c2a616bc70066','集中授权管理','platform/securityControlController/toauthManager','MENU',NULL,'8a58a6b44c276a3f014c2a5f00fc0057','1','2015-05-12 13:48:29','1','2015-03-18 08:56:09','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c2a63ee62007a','系统安全管理',NULL,'MENU',NULL,'8a58a6b44c276a3f014c276b708c0003','1','2015-05-12 14:27:27','1','2015-03-18 08:58:54','1','127.0.0.1','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c2a645456007f','日志与审计','platform/syslog/sysloginfo','MENU',NULL,'8a58a6b44c276a3f014c2a63ee62007a','1','2015-08-14 13:54:52','1','2015-03-18 08:59:20','1','127.0.0.1','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c2a652dd80089','密码模版配置','avicit/platform6/modules/system/syspasswordconfigure/syspasswordconfigure.jsp','MENU',NULL,'8a58a6b44c276a3f014c2a63ee62007a','1','2015-05-12 13:51:22','1','2015-03-18 09:00:16','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c2a6579c6008e','IP限制管理','avicit/platform6/modules/system/sysuserlimitip/sysuserlimitip.jsp','MENU',NULL,'8a58a6b44c276a3f014c2a63ee62007a','1','2015-05-12 13:51:31','1','2015-03-18 09:00:35','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c2a66d819009b','业务流程管理',NULL,'MENU',NULL,'8a58a6b44c276a3f014c276b708c0003','1','2015-05-12 14:27:18','1','2015-03-18 09:02:05','1','127.0.0.1','5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c2a692d0800a0','流程目录管理','avicit/platform6/bpmconsole/publish/ProcessCatalogManage.jsp','MENU',NULL,'8a58a6b44c276a3f014c2a66d819009b','1','2015-05-12 13:59:00','1','2015-03-18 09:04:38','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c2a69888500a5','流程表单管理','avicit/platform6/bpmconsole/publish/ProcessFormManage.jsp','MENU',NULL,'8a58a6b44c276a3f014c2a66d819009b','1','2015-05-12 13:59:07','1','2015-03-18 09:05:01','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c2a69e00100aa','正文模板管理','avicit/platform6/bpmconsole/word/WordTempletManager.jsp','MENU',NULL,'8a58a6b44c276a3f014c2a66d819009b','1','2015-05-12 13:59:13','1','2015-03-18 09:05:24','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c2a6ac60200af','流程模板配置','avicit/platform6/bpmconsole/publish/ProcessPublishManage.jsp','MENU',NULL,'8a58a6b44c276a3f014c2a66d819009b','1','2015-05-12 13:59:30','1','2015-03-18 09:06:22','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c2a6b0c9500b4','流程实例监控','avicit/platform6/bpmconsole/entry/ProcessEntryList.jsp','MENU',NULL,'8a58a6b44c276a3f014c2a66d819009b','1','2015-05-12 13:59:45','1','2015-03-18 09:06:40','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c2a73dfb700de','服务管理',NULL,'MENU',NULL,'8a58a6b44c276a3f014c276b708c0003','1','2015-05-12 14:27:35','1','2015-03-18 09:16:19','1','127.0.0.1','5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c2a7433c200e3','单位注册管理','platform/restmanage/org/index','MENU',NULL,'8a58a6b44c276a3f014c2a73dfb700de','1','2015-05-12 13:54:11','1','2015-03-18 09:16:40','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c2a750edf00ee','系统注册管理','platform/restmanage/system/index','MENU',NULL,'8a58a6b44c276a3f014c2a73dfb700de','1','2015-05-12 13:54:51','1','2015-03-18 09:17:36','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c2a76550f00fd','服务资源管理','platform/restmanage/resources/index','MENU',NULL,'8a58a6b44c276a3f014c2a73dfb700de','1','2015-05-12 13:55:29','1','2015-03-18 09:19:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c2a76a9a90102','服务授权配置','platform/restmanage/auth/index','MENU',NULL,'8a58a6b44c276a3f014c2a73dfb700de','1','2015-05-12 13:56:06','1','2015-03-18 09:19:22','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c2a7e187b0107','搜索配置管理',NULL,'MENU',NULL,'8a58a6b44c276a3f014c276b708c0003','1','2015-05-12 14:27:42','1','2015-03-18 09:27:29','1','127.0.0.1','5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c2a7f2b2f010f','数据源配置','platform/search/connection/index.html','MENU',NULL,'8a58a6b44c276a3f014c2a7e187b0107','1','2015-05-12 13:57:42','1','2015-03-18 09:28:39','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b44c276a3f014c2a7fb1100117','搜索索引配置','platform/search/index.html','MENU',NULL,'8a58a6b44c276a3f014c2a7e187b0107','1','2015-05-12 13:58:05','1','2015-03-18 09:29:13','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b54f2b3339014f2b40c2680074','密码模版配置','avicit/platform6/modules/system/syspasswordconfigure/syspasswordconfigure.jsp','MENU',NULL,'8a58cd574e90f106014e90f1f69900da','1','2015-08-14 16:08:28','1','2015-08-14 16:08:28','1','10.216.77.215','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b54f2b3339014f2b45d2c50079','IP限制管理','avicit/platform6/modules/system/sysuserlimitip/sysuserlimitip.jsp','MENU',NULL,'8a58cd574e90f106014e90f1f69900da','1','2015-08-14 16:14:00','1','2015-08-14 16:14:00','1','10.216.77.215','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58a6b54f4f35af014f4f38bdb9007c','缓存集中管理','avicit/platform6/modules/system/sysdashboard/reLoadCache.jsp','MENU',NULL,'402809814dfff8d6014dffffee5200ea','1','2015-09-29 16:11:41','1','2015-08-21 15:46:02','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58ab574c7d0e6c014c7d103ec70004','消息','platform/sysmessage/sysMessageController/toSysMessage','MENU',NULL,'8a58a6b44c276a3f014c276b708c0003','1','2015-05-12 14:06:06','1','2015-04-03 10:15:58','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58c8434d468f93014d4696701d0009','用户关系管理','platform/sysUserRelationController/toUserRelation','MENU',NULL,'8a58a6b44c276a3f014c276bcc2d0008','1','2015-05-12 13:26:13','1','2015-05-12 13:26:13','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58c8434d468f93014d4698ca290012','群组管理','platform/sysgroup/sysgroupinfo','MENU',NULL,'8a58a6b44c276a3f014c276bcc2d0008','1','2015-05-12 13:28:47','1','2015-05-12 13:28:47','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58c8434d468f93014d4699721b0017','角色管理','platform/sysrole/sysroleinfo','MENU',NULL,'8a58a6b44c276a3f014c276bcc2d0008','1','2015-05-12 13:29:30','1','2015-05-12 13:29:30','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58c8434d468f93014d469b1dca001c','系统配置管理',NULL,'MENU',NULL,'8a58a6b44c276a3f014c276b708c0003','1','2015-05-12 14:16:10','1','2015-05-12 13:31:20','1','127.0.0.1','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58c8434d468f93014d469d824e0026','菜单管理','platform/sysmenu/sysmenuinfo','MENU',NULL,'8a58c8434d468f93014d469b1dca001c','1','2015-05-12 13:33:57','1','2015-05-12 13:33:57','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58c8434d468f93014d46a40e83003b','门户布局管理','avicit/platform6/modules/system/sysportal/portletconfig.jsp','MENU',NULL,'8a58c8434d468f93014d469b1dca001c','1','2015-05-12 13:41:06','1','2015-05-12 13:41:06','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58c8434d468f93014d46a4bdf50040','系统参数配置','platform/sysprofile/sysProfileInfo','MENU',NULL,'8a58c8434d468f93014d469b1dca001c','1','2015-05-12 13:41:51','1','2015-05-12 13:41:51','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58c8434d468f93014d46a533990045','通用代码管理','platform/syslookuptype/sysLookupTypeInfo','MENU',NULL,'8a58c8434d468f93014d469b1dca001c','1','2015-05-12 13:42:21','1','2015-05-12 13:42:21','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58c8434d468f93014d46a5ae9a004a','多应用管理','platform/sysApps/sysAppsInfo','MENU',NULL,'8a58c8434d468f93014d469b1dca001c','1','2015-05-12 13:42:52','1','2015-05-12 13:42:52','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58c8434d468f93014d46a62877004f','在线用户','avicit/platform6/modules/system/onlineuser/onlineuser.jsp','MENU',NULL,'8a58c8434d468f93014d469b1dca001c','1','2015-05-12 13:43:24','1','2015-05-12 13:43:24','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58c8434d468f93014d46a6a33c0054','缓存管理','avicit/platform6/modules/system/sysdashboard/reLoadCache.jsp','MENU',NULL,'8a58c8434d468f93014d469b1dca001c','1','2015-05-12 13:43:55','1','2015-05-12 13:43:55','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58c8434d468f93014d46a71c050059','单点配置管理','platform/ssoUpdate/casConfig','MENU',NULL,'8a58c8434d468f93014d469b1dca001c','1','2015-05-12 13:44:26','1','2015-05-12 13:44:26','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58c8434d468f93014d46a7b7c2005e','定时任务管理','avicit/platform6/modules/system/quartz/jobMaintainManager.jsp','MENU',NULL,'8a58c8434d468f93014d469b1dca001c','1','2015-05-12 13:45:06','1','2015-05-12 13:45:06','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58c8434d468f93014d46aa7ba90072','数据权限配置','avicit/platform6/modules/system/sysdatapermission/SysPermissionResource.jsp','MENU',NULL,'8a58a6b44c276a3f014c2a5f00fc0057','1','2015-05-12 13:48:34','1','2015-05-12 13:48:07','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58c8434d468f93014d46ab685b0080','跨部门领导配置','platform/sysPermissionLeaddeptController/leaddept','MENU',NULL,'8a58a6b44c276a3f014c2a5f00fc0057','1','2015-05-12 13:49:08','1','2015-05-12 13:49:08','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58c8434d468f93014d46b7c03f00c8','流程维度分析','avicit/platform6/bpmconsole/analysis/ProcessDurationAnalysis.jsp','MENU',NULL,'8a58a6b44c276a3f014c2a66d819009b','1','2015-05-12 14:02:37','1','2015-05-12 14:02:37','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58c8434d468f93014d46b85ae600cd','部门维度分析','avicit/platform6/bpmconsole/analysis/ProcessDeptAnalysis.jsp','MENU',NULL,'8a58a6b44c276a3f014c2a66d819009b','1','2015-05-12 14:03:16','1','2015-05-12 14:03:16','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58c8434d468f93014d46b8ce1d00d2','岗位维度分析','avicit/platform6/bpmconsole/analysis/ProcessPositionAnalysis.jsp','MENU',NULL,'8a58a6b44c276a3f014c2a66d819009b','1','2015-05-12 14:03:46','1','2015-05-12 14:03:46','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58c8434d468f93014d46b92d0800d7','用户维度分析','avicit/platform6/bpmconsole/analysis/ProcessUserAnalysis.jsp','MENU',NULL,'8a58a6b44c276a3f014c2a66d819009b','1','2015-05-12 14:04:10','1','2015-05-12 14:04:10','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd434fb53c16014fb53f01a5004d','密级关系管理','platform/syssecret/toSecretManager','MENU',NULL,'8a58c8434d468f93014d469b1dca001c','1','2015-09-10 11:14:09','1','2015-09-10 11:14:09','1','0:0:0:0:0:0:0:1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd574df6657e014df670084400d0','组织结构集中管理',NULL,'MENU',NULL,'402809814db30afe014db30c4e18008e','1','2015-09-29 16:02:01','1','2015-06-15 16:57:00','1','127.0.0.1','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd574df6657e014df673fdb400d5','部门用户集中管理','platform/cc/sysdept/sysdeptinfo','MENU',NULL,'8a58cd574df6657e014df670084400d0','1','2015-09-29 16:02:38','1','2015-06-15 17:01:00','1','127.0.0.1','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd574e75cfbe014e75d560cc00d8','在线用户集中管理','platform/cc/onlineuser/onlineuserinfo','MENU',NULL,'402809814dfff8d6014dffffee5200ea','1','2015-09-29 16:07:21','1','2015-07-10 10:39:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd574e75cfbe014e75d7db2300de','单点配置集中管理','platform/cc/ssoconfig/ssoconfiginfo/null','MENU',NULL,'402809814dfff8d6014dffffee5200ea','1','2015-09-29 16:07:30','1','2015-07-10 10:42:00','1','127.0.0.1','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd574e90f106014e90f1f69900da','系统安全集中管理',NULL,'MENU',NULL,'402809814db30afe014db30c4e18008e','1','2015-09-29 16:02:14','1','2015-07-15 17:00:00','1','127.0.0.1','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd574e90f106014e90f2ba3300df','日志审计集中管理','platform/syslog/sysloginfo','MENU',NULL,'8a58cd574e90f106014e90f1f69900da','1','2015-09-29 16:06:22','1','2015-07-15 17:01:00','1','127.0.0.1','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd574eb461d7014eb469fcf700f5','服务管理',NULL,'MENU',NULL,'402809814db30afe014db30c4e18008e','1','2015-09-28 10:46:11','1','2015-07-22 14:18:00','1','127.0.0.1','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd574eb48823014eb49026ac00db','单位注册管理','platform/restmanage/org/index','MENU',NULL,'8a58cd574eb461d7014eb469fcf700f5','1','2015-07-22 15:00:00','1','2015-07-22 15:00:00','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd574eb48823014eb4926b4000e0','系统注册管理','platform/restmanage/system/index','MENU',NULL,'8a58cd574eb461d7014eb469fcf700f5','1','2015-07-22 15:02:00','1','2015-07-22 15:02:00','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd574eb48823014eb493161f00e5','服务资源管理','platform/restmanage/resources/index','MENU',NULL,'8a58cd574eb461d7014eb469fcf700f5','1','2015-07-22 15:03:00','1','2015-07-22 15:03:00','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd574eb48823014eb493fc3200ea','服务授权配置','platform/restmanage/auth/index','MENU',NULL,'8a58cd574eb461d7014eb469fcf700f5','1','2015-07-22 15:04:00','1','2015-07-22 15:04:00','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd574eb48823014eb49503b700ef','搜索配置管理',NULL,'MENU',NULL,'402809814db30afe014db30c4e18008e','1','2015-09-28 10:46:06','1','2015-07-22 15:05:00','1','127.0.0.1','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd574eb48823014eb495b51800f4','数据源配置','platform/search/connection/index.html','MENU',NULL,'8a58cd574eb48823014eb49503b700ef','1','2015-07-22 15:06:00','1','2015-07-22 15:06:00','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd574eb48823014eb4965d0700f9','搜索索引配置','platform/search/index.html','MENU',NULL,'8a58cd574eb48823014eb49503b700ef','1','2015-07-22 15:07:00','1','2015-07-22 15:07:00','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd575016ab70015016af29f60052','关注工作','avicit/platform6/bpmclient/bpm/FocusedTask.jsp','MENU',NULL,'8a58a6b44c275bab014c2765ee040031','1','2015-09-29 09:19:49','1','2015-09-29 09:19:49','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57501c05fb01501c1337ab006e','正文目录管理','avicit/platform6/bpmconsole/publish/WordCatalogManage.jsp','MENU',NULL,'8a58a6b44c276a3f014c2a66d819009b','1','2015-09-30 10:27:12','1','2015-09-30 10:27:12','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57504b2a3201504b2b74190096','添加','sysuser_toolbar_insertUser','COMPONENT',NULL,'8a58a6b44c276a3f014c276f9f1a0027','1','2015-10-09 13:55:50','1','2015-10-09 13:55:50','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57504b2a3201504b2b74190097','编辑','sysuser_toolbar_editUser','COMPONENT',NULL,'8a58a6b44c276a3f014c276f9f1a0027','1','2015-10-09 13:55:50','1','2015-10-09 13:55:50','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57504b2a3201504b2b74190098','恢复密码','sysuser_toolbar_resetPassword','COMPONENT',NULL,'8a58a6b44c276a3f014c276f9f1a0027','1','2015-10-09 13:55:50','1','2015-10-09 13:55:50','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57504b2a3201504b2b74190099','有效设置','sysuser_toolbar_setValidFlag','COMPONENT',NULL,'8a58a6b44c276a3f014c276f9f1a0027','1','2015-10-09 13:55:50','1','2015-10-09 13:55:50','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57504b2a3201504b2b7419009a','解锁','sysuser_toolbar_doUnLockSysUser','COMPONENT',NULL,'8a58a6b44c276a3f014c276f9f1a0027','1','2015-10-09 13:55:50','1','2015-10-09 13:55:50','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57504b2a3201504b2b7419009b','导入用户','sysuser_toolbar_importUser','COMPONENT',NULL,'8a58a6b44c276a3f014c276f9f1a0027','1','2015-10-09 13:55:50','1','2015-10-09 13:55:50','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57504b2a3201504b2b7419009c','导出用户','sysuser_toolbar_exportUser','COMPONENT',NULL,'8a58a6b44c276a3f014c276f9f1a0027','1','2015-10-09 13:55:50','1','2015-10-09 13:55:50','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57504b2a3201504b2b7419009d','删除','sysuser_toolbar_deleteUser','COMPONENT',NULL,'8a58a6b44c276a3f014c276f9f1a0027','1','2015-10-09 13:55:50','1','2015-10-09 13:55:50','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57504b2a3201504b2b7419009e','查询','sysuser_toolbar_searchOpen','COMPONENT',NULL,'8a58a6b44c276a3f014c276f9f1a0027','1','2015-10-09 13:55:50','1','2015-10-09 13:55:50','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57504b2a3201504b2b94fa00a8','添加角色','sysRole_tabPower_button_btAddRole','COMPONENT',NULL,'8a58c8434d468f93014d4699721b0017','1','2015-10-09 13:55:58','1','2015-10-09 13:55:58','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57504b2a3201504b2b94fa00a9','保存角色','sysRole_tabPower_button_btSaveRole','COMPONENT',NULL,'8a58c8434d468f93014d4699721b0017','1','2015-10-09 13:55:58','1','2015-10-09 13:55:58','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57504b2a3201504b2b94fa00aa','导入角色','sysRole_tabPower_button_btImportRole','COMPONENT',NULL,'8a58c8434d468f93014d4699721b0017','1','2015-10-09 13:55:59','1','2015-10-09 13:55:59','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57504b2a3201504b2b94fa00ab','导出角色','sysRole_tabPower_button_btExportRole','COMPONENT',NULL,'8a58c8434d468f93014d4699721b0017','1','2015-10-09 13:55:59','1','2015-10-09 13:55:59','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57504b2a3201504b2b94fa00ac','删除角色','sysRole_tabPower_button_btDeleteRole','COMPONENT',NULL,'8a58c8434d468f93014d4699721b0017','1','2015-10-09 13:55:59','1','2015-10-09 13:55:59','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57504b2a3201504b2b94fa00ad','查询角色','sysRole_tabPower_button_btSearchRole','COMPONENT',NULL,'8a58c8434d468f93014d4699721b0017','1','2015-10-09 13:55:59','1','2015-10-09 13:55:59','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57504b2a3201504b2b94fa00ae','添加用户','sysRole_tabPower_button_btAddUser','COMPONENT',NULL,'8a58c8434d468f93014d4699721b0017','1','2015-10-09 13:55:59','1','2015-10-09 13:55:59','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57504b2a3201504b2b94fa00af','删除用户','sysRole_tabPower_button_btDeleteUser','COMPONENT',NULL,'8a58c8434d468f93014d4699721b0017','1','2015-10-09 13:55:59','1','2015-10-09 13:55:59','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57504b2a3201504b2b94fa00b0','查询用户','sysRole_tabPower_button_btSearchUser','COMPONENT',NULL,'8a58c8434d468f93014d4699721b0017','1','2015-10-09 13:55:59','1','2015-10-09 13:55:59','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd57535417350153543765620072','系统语言维护','platform/syslanguage/mgr','MENU',NULL,'8a58c8434d468f93014d469b1dca001c','1','2016-03-08 11:14:01','1','2016-03-08 11:13:49','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd5b4d5acbde014d5ae7db420045','报表模版授权管理','platform/fineReportAuthorityController/fineReportInfo','MENU',NULL,'8a58a6b44c276a3f014c2a5f00fc0057','1','2015-05-16 12:07:34','1','2015-05-16 12:07:34','1','0:0:0:0:0:0:0:1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd5b4e042750014e045b413900dc','门户布局集中管理','platform/cc/sysportal/sysportalinfo','MENU',NULL,'402809814dfff8d6014dffffee5200ea','1','2015-09-29 16:06:57','1','2015-06-18 09:49:00','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd5b4e042750014e045c584000e1','通用代码集中管理','platform/cc/syslookup/syslookupinfo','MENU',NULL,'402809814dfff8d6014dffffee5200ea','1','2015-09-29 15:56:07','1','2015-06-18 09:50:00','1','127.0.0.1','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd5b4e3ce0ac014e3ce2bb1500ca','授权集中管理',NULL,'MENU',NULL,'402809814db30afe014db30c4e18008e','1','2015-09-29 16:02:08','1','2015-06-29 09:16:00','1','127.0.0.1','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd5b4e3ce0ac014e3d61a41500eb','菜单授权集中管理','platform/cc/menuaccesscontrol/menuaccesscontrolinfo','MENU',NULL,'8a58cd5b4e3ce0ac014e3ce2bb1500ca','1','2015-09-29 16:03:56','1','2015-06-29 11:34:00','1','127.0.0.1','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd5b4e706483014e706c730c00cb','授权集中管理','platform/cc/securitycontrol/securitycontrolinfo','MENU',NULL,'8a58cd5b4e3ce0ac014e3ce2bb1500ca','1','2015-09-29 16:03:46','1','2015-07-09 09:27:00','1','127.0.0.1','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58cd604e7156df014e71749f67010c','流程设计器','platform/bpm/bpmdesigner/bpmWebDesigner/index','MENU',NULL,'8a58a6b44c276a3f014c2a66d819009b','1','2015-07-09 14:15:45','1','2015-07-09 14:15:45','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

/*Table structure for table `sys_role` */

DROP TABLE IF EXISTS `sys_role`;

CREATE TABLE `sys_role` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `ROLE_NAME` varchar(50) NOT NULL COMMENT '角色名称',
  `ROLE_CODE` varchar(50) NOT NULL COMMENT '角色代码',
  `ROLE_GROUP` varchar(50) DEFAULT NULL COMMENT '角色组，标示字段，用于区分不同的角色组，便于查询和分类',
  `ROLE_TYPE` varchar(1) NOT NULL COMMENT '角色类型，0代表系统内置角色，不能删除\r\n1代表由用户添加的角色',
  `SYS_APPLICATION_ID` varchar(50) NOT NULL COMMENT '应用ID',
  `ROLE_DEPT_ID` varchar(50) DEFAULT NULL COMMENT '角色所属的部门，可选。用来表示该角色只在该部门内生效\r\n这是一个标示属性，进行权限判断时不会按照这个字段进行判断\r\n比如：生产管理部下的生产计划员',
  `ROLE_DESC` varchar(240) DEFAULT NULL COMMENT '描述',
  `VALID_FLAG` varchar(1) NOT NULL COMMENT '设置角色是否有效，1-有效，0-无效',
  `ORDER_BY` decimal(16,0) DEFAULT NULL COMMENT '排序',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `USAGE_MODIFIER` varchar(1) DEFAULT NULL COMMENT '0 公有可用     1私有可用',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统角色表';

/*Data for the table `sys_role` */

insert  into `sys_role` values ('40288a46384feb2101384fef8ba80005','安全管理员','safety_manager',NULL,'0','1',NULL,'三员角色之安全管理员','1','2','2012-02-25 10:11:55','1','2012-07-04 11:01:35','1','0:0:0:0:0:0:0:1','6','0'),('40288a46384feb2101384ff0efc20006','安全审计员','safety_auditor',NULL,'0','1',NULL,'三员角色之安全审计员','1','3','2012-10-26 15:50:03','1','2012-07-04 11:03:06','1','0:0:0:0:0:0:0:1','10','0'),('40288a46384feb2101384ff1ce8e0007','平台管理员','platform_manager',NULL,'0','1',NULL,'初始化系统用','1','0','2012-07-10 13:37:07','1','2012-07-04 11:04:03','1','127.0.0.1','4','0'),('8a58ab4d4c207cca014c207ffff7034c','系统管理员','system_manager',NULL,'0','1',NULL,'三员角色之系统管理员','1','1','2015-03-16 10:53:21','1','2015-03-16 10:53:21','1','127.0.0.1','2','0'),('8a58ab5f4be29ef7014be2d442bd01ab','一般用户','comm_user',NULL,'0','1',NULL,'新增用户默认角色','1','4','2015-03-04 11:28:56','1','2015-03-04 11:28:56','1','127.0.0.1','1','0');

/*Table structure for table `sys_secret_relation` */

DROP TABLE IF EXISTS `sys_secret_relation`;

CREATE TABLE `sys_secret_relation` (
  `ID` varchar(50) NOT NULL COMMENT '主键ID',
  `WORD_SECRET` varchar(10) NOT NULL COMMENT '文档密级',
  `USER_SECRET` varchar(10) NOT NULL COMMENT '人员密级',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(32) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(32) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(20) NOT NULL COMMENT '最后更新IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='文档密级与人员密级关系表';

/*Data for the table `sys_secret_relation` */

insert  into `sys_secret_relation` values ('8a58cd435644dd46015644e02c35005e','1','1','2016-08-01 14:52:37','1','2016-08-01 14:52:37','1','0:0:0:0:0:0:0:1','0'),('8a58cd575373da94015373db54c20062','2','2','2016-03-14 14:41:07','1','2016-03-14 14:41:07','1','127.0.0.1','0'),('8a58cd575373da94015373db56a80063','1','2','2016-03-14 14:41:07','1','2016-03-14 14:41:07','1','127.0.0.1','0'),('8a58cd575373da94015373db6a950064','1','3','2016-03-14 14:41:12','1','2016-03-14 14:41:12','1','127.0.0.1','0'),('8a58cd575373da94015373db6cba0065','2','3','2016-03-14 14:41:13','1','2016-03-14 14:41:13','1','127.0.0.1','0'),('8a58cd575373da94015373db738c0066','3','3','2016-03-14 14:41:15','1','2016-03-14 14:41:15','1','127.0.0.1','0'),('8a58cd575373da94015373db7ce80067','1','4','2016-03-14 14:41:17','1','2016-03-14 14:41:17','1','127.0.0.1','0'),('8a58cd575373da94015373db7f6b0068','2','4','2016-03-14 14:41:18','1','2016-03-14 14:41:18','1','127.0.0.1','0'),('8a58cd575373da94015373db81190069','3','4','2016-03-14 14:41:18','1','2016-03-14 14:41:18','1','127.0.0.1','0'),('8a58cd575373da94015373db8493006a','4','4','2016-03-14 14:41:19','1','2016-03-14 14:41:19','1','127.0.0.1','0');

/*Table structure for table `sys_sso_config` */

DROP TABLE IF EXISTS `sys_sso_config`;

CREATE TABLE `sys_sso_config` (
  `ID` varchar(32) NOT NULL,
  `SSO_TYPE` varchar(30) DEFAULT NULL COMMENT '单点类型，如cas',
  `SSO_CONFIG` text COMMENT '单点配置，xml格式',
  `SSO_ENABLE_FLG` varchar(1) DEFAULT NULL COMMENT '单点启用标志，1 启用',
  `VERSION` decimal(16,0) DEFAULT NULL,
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '应用ID',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sys_sso_config` */

insert  into `sys_sso_config` values ('8a58ab564c065b8e014c06732a4602f7','cas','<sso-params><ssoParam><key>cas.service.url</key><value>http://localhost:8080/avicit-platform6-main/login/login_sso_cas.jsp</value></ssoParam><ssoParam><key>cas.validate.url</key><value></value></ssoParam><ssoParam><key>cas.server.name</key><value>http://localhost:8080</value></ssoParam><ssoParam><key>cas.login.url</key><value>http://localhost:8081/cas3/login</value></ssoParam><ssoParam><key>cas.auth.enabled</key><value>true</value></ssoParam><ssoParam><key>cas.logout.url</key><value>http://localhost:8081/cas3/logout</value></ssoParam><ssoParam><key>cas.server.url</key><value>http://localhost:8081/cas3</value></ssoParam></sso-params>','1','1','1');

/*Table structure for table `sys_user` */

DROP TABLE IF EXISTS `sys_user`;

CREATE TABLE `sys_user` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `NAME` varchar(50) NOT NULL COMMENT '姓名',
  `NAME_EN` varchar(50) DEFAULT NULL COMMENT '英文名',
  `NO` varchar(50) NOT NULL COMMENT '用户编号',
  `LOGIN_NAME` varchar(50) NOT NULL COMMENT '登录名',
  `LOGIN_PASSWORD` varchar(50) NOT NULL COMMENT '登录密码',
  `SECRET_LEVEL` varchar(50) NOT NULL COMMENT '密级',
  `BIRTHDAY` datetime DEFAULT NULL COMMENT '生日',
  `SEX` varchar(2) DEFAULT NULL COMMENT '性别',
  `NATION` varchar(100) DEFAULT NULL COMMENT '民族',
  `BIRTH_ADDRESS` varchar(100) DEFAULT NULL COMMENT '籍贯',
  `POLITY` varchar(50) DEFAULT NULL COMMENT '政治面貌',
  `WORK_DATE` datetime DEFAULT NULL COMMENT '工作日期',
  `TITLE` varchar(100) DEFAULT NULL COMMENT '职称',
  `DEGREE` varchar(50) DEFAULT NULL COMMENT '学历',
  `EDUCATION` varchar(100) DEFAULT NULL COMMENT '毕业院校',
  `MOBILE` varchar(50) DEFAULT NULL COMMENT '手机',
  `OFFICE_TEL` varchar(50) DEFAULT NULL COMMENT '办公电话',
  `FAX` varchar(50) DEFAULT NULL COMMENT '传真',
  `EMAIL` varchar(50) DEFAULT NULL COMMENT '邮件',
  `WORK_SPACE` varchar(100) DEFAULT NULL COMMENT '工作地点',
  `ROOM_NO` varchar(50) DEFAULT NULL COMMENT '房间号',
  `HOME_ADDRESS` varchar(100) DEFAULT NULL COMMENT '家庭地址',
  `HOME_ZIP` varchar(50) DEFAULT NULL COMMENT '家庭邮编',
  `HOME_TEL` varchar(50) DEFAULT NULL COMMENT '家庭电话',
  `ORDER_BY` decimal(16,0) DEFAULT NULL COMMENT '排序',
  `TYPE` varchar(1) DEFAULT NULL COMMENT '类型',
  `STATUS` varchar(2) DEFAULT NULL COMMENT '1:正常的用户状态3:无效用户状态',
  `REMARK` varchar(240) DEFAULT NULL COMMENT '描述',
  `LANGUAGE_CODE` varchar(50) DEFAULT NULL COMMENT '默认语言',
  `LAST_LOGIN_DEPT_ID` varchar(50) DEFAULT NULL COMMENT '上次登录部门',
  `LAST_PASSWORD_DATE` datetime DEFAULT NULL COMMENT '上次修改密码时间',
  `LAST_LOGIN_DATE` datetime DEFAULT NULL COMMENT '上次登录时间',
  `PASSWORD_DAYS` decimal(16,0) DEFAULT NULL COMMENT '密码有效天数',
  `LOGIN_FAIL_TIMES` decimal(16,0) DEFAULT NULL COMMENT '密码登录失败次数',
  `USER_LOCKED` varchar(1) DEFAULT NULL COMMENT '0:没有锁定 1：密码超时没修改锁定2：输错次数过多被锁定，超时自动解锁3：完全锁定',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `LOGIN_FAIL_FIRST_TIME` datetime DEFAULT NULL COMMENT '第一次登录失败时间',
  `UNIT_CODE` varchar(255) DEFAULT NULL COMMENT '集团统一编码',
  `PHOTO` longblob COMMENT '照片',
  `SIGN` longblob COMMENT '签名',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统用户标';

/*Data for the table `sys_user` */

insert  into `sys_user` values ('1','平台管理员','管理员','admin','admin','a40546cc4fd6a12572828bb803380888ad1bfdab','1','2012-08-26 08:00:00','2','1','中国','1','2012-08-28 08:00:00',NULL,'001',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','1',NULL,'zh_CN','40288af9389423a50138946acf67001f',NULL,'2015-04-07 15:43:24',NULL,'0','0','2015-04-07 15:43:24','1','2012-11-27 00:00:00','1','127.0.0.1','47','19878888',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'zhgy-010-4679',NULL,NULL),('8a58a6b44c275dce014c275dced90000','系统管理员',NULL,'sysadmin','sysadmin','7df428346fba1548d6d66c85bd88321e972022a0','1',NULL,'1','1',NULL,'1',NULL,NULL,'001',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','0','1',NULL,'zh_CN',NULL,NULL,'2015-04-03 15:07:02',NULL,'0','0','2015-04-03 15:07:02','8a58a6b44c275dce014c275dced90000','2015-03-17 18:54:05','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58ab4d4c25bd67014c25bdc1980001','安全管理员',NULL,'safeadmin','safeadmin','1eae9a21247a75fc10bcf245b21fa592ee58dbfd','1',NULL,'1','1',NULL,'1',NULL,NULL,'001',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','0','1',NULL,'zh_CN',NULL,NULL,'2015-04-03 15:07:19',NULL,'0','0','2015-04-03 15:07:19','8a58ab4d4c25bd67014c25bdc1980001','2015-03-17 11:19:39','1','127.0.0.1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a58ab4d4c25bd67014c25beb8780002','安全审计员',NULL,'safeaudi','safeaudi','1a8edddcaa8bd116ac302d20dae63eb6c5f8c536','1',NULL,'1','1',NULL,'1',NULL,NULL,'001',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','0','1',NULL,'zh_CN',NULL,NULL,NULL,NULL,NULL,'0','2015-03-17 11:20:56','1','2015-03-17 11:20:56','1','127.0.0.1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

/*Table structure for table `sys_user_dept_position` */

DROP TABLE IF EXISTS `sys_user_dept_position`;

CREATE TABLE `sys_user_dept_position` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `USER_ID` varchar(50) NOT NULL COMMENT '用户ID',
  `DEPT_ID` varchar(50) NOT NULL COMMENT '部门ID',
  `POSITION_ID` varchar(50) NOT NULL COMMENT '职位ID',
  `IS_CHIEF_DEPT` varchar(1) NOT NULL COMMENT '是否是主部门',
  `IS_MANAGER` varchar(1) DEFAULT NULL COMMENT '是否是部门主管',
  `ORDER_BY` decimal(16,0) DEFAULT NULL COMMENT '排序',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户部门岗位关系表';

/*Data for the table `sys_user_dept_position` */

insert  into `sys_user_dept_position` values ('8a58a6b44c275bab014c275e7aa30009','8a58a6b44c275dce014c275dced90000','8a58ab4d4c2141fd014c217cdc5102b6','1','1','0',NULL,'2015-03-17 18:54:05','1','2015-03-17 18:54:05','1','10.216.43.205','0'),('8a58ab4d4c25bcb6014c25be6f0c0310','8a58ab4d4c25bd67014c25bdc1980001','8a58ab4d4c2141fd014c217cdc5102b6','1','1','0',NULL,'2015-03-17 11:19:39','1','2015-03-17 11:19:39','1','127.0.0.1','0'),('8a58ab4d4c25bcb6014c25bf9b6a0315','8a58ab4d4c25bd67014c25beb8780002','8a58ab4d4c2141fd014c217cdc5102b6','1','1','0',NULL,'2015-03-17 11:20:56','1','2015-03-17 11:20:56','1','127.0.0.1','0'),('8a58abf94471d213014471d63c930001','1','8a58ab4d4c2141fd014c217cdc5102b6','1','1','1',NULL,'2015-03-17 11:30:25','1','2014-02-27 13:34:42','1','127.0.0.1','0');

/*Table structure for table `sys_user_group` */

DROP TABLE IF EXISTS `sys_user_group`;

CREATE TABLE `sys_user_group` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `GROUP_ID` varchar(50) NOT NULL COMMENT '群组ID',
  `USER_ID` varchar(50) NOT NULL COMMENT '用户ID',
  `ORDER_BY` decimal(16,0) DEFAULT NULL COMMENT '排序',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户群组关系表';

/*Data for the table `sys_user_group` */

/*Table structure for table `sys_user_limit_ip` */

DROP TABLE IF EXISTS `sys_user_limit_ip`;

CREATE TABLE `sys_user_limit_ip` (
  `ID` varchar(32) NOT NULL COMMENT '主键',
  `USER_LIMIT_USER_ID` varchar(32) DEFAULT NULL COMMENT '受到限人ID',
  `LIMIT_TYPE_IP_TYPE` varchar(32) NOT NULL COMMENT '0：IP点，1：IP段',
  `LIMIT_USER_TYPE` varchar(32) NOT NULL COMMENT '分为用户不能访问；用户只能访问',
  `USER_LIMIT_IP_FROM` varchar(50) NOT NULL COMMENT '开始IP',
  `USER_LIMIT_IP_END` varchar(50) DEFAULT NULL COMMENT '结束IP',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='限制用户登陆IP';

/*Data for the table `sys_user_limit_ip` */

/*Table structure for table `sys_user_lock_log` */

DROP TABLE IF EXISTS `sys_user_lock_log`;

CREATE TABLE `sys_user_lock_log` (
  `ID` varchar(50) NOT NULL,
  `SYS_USER_NAME` varchar(50) NOT NULL,
  `LOCK_IP` varchar(50) DEFAULT NULL,
  `LOCK_DATE` datetime DEFAULT NULL,
  `LOCK_CONTENT` text,
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL,
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL,
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL,
  `LAST_UPDATE_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` varchar(50) DEFAULT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `CREATED_BY` varchar(50) DEFAULT NULL,
  `LAST_UPDATE_IP` varchar(50) DEFAULT NULL,
  `VERSION` decimal(16,0) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sys_user_lock_log` */

/*Table structure for table `sys_user_old_password` */

DROP TABLE IF EXISTS `sys_user_old_password`;

CREATE TABLE `sys_user_old_password` (
  `ID` varchar(32) NOT NULL COMMENT '主键',
  `USER_ID` varchar(32) NOT NULL COMMENT '用户ID',
  `USER_PASSWORD` varchar(255) NOT NULL COMMENT '用户密码',
  `USER_MODIFY_DATE` datetime NOT NULL COMMENT '分为用户不能访问；用户只能访问',
  `MANAGER_FLAG` varchar(50) NOT NULL COMMENT '用户修改日期',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户历史密码表，保存用户以前的密码';

/*Data for the table `sys_user_old_password` */

/*Table structure for table `sys_user_relation` */

DROP TABLE IF EXISTS `sys_user_relation`;

CREATE TABLE `sys_user_relation` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `USER1_ID` varchar(50) NOT NULL COMMENT '用户ID',
  `USER2_ID` varchar(50) NOT NULL COMMENT '用户ID',
  `RELATION` varchar(50) NOT NULL COMMENT '关系',
  `ORG_ID` varchar(50) NOT NULL COMMENT '组织ID',
  `VALID_FLAG` varchar(1) NOT NULL COMMENT '关系是否有效，1-有效，0-无效',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户关系表';

/*Data for the table `sys_user_relation` */

/*Table structure for table `sys_user_role` */

DROP TABLE IF EXISTS `sys_user_role`;

CREATE TABLE `sys_user_role` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `SYS_ROLE_ID` varchar(50) NOT NULL COMMENT '角色ID',
  `SYS_USER_ID` varchar(50) NOT NULL COMMENT '用户ID',
  `ORDER_BY` decimal(16,0) DEFAULT NULL COMMENT '排序',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL COMMENT '应用ID',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户角色关系表';

/*Data for the table `sys_user_role` */

insert  into `sys_user_role` values ('4028814b4a52768b014a5277cf970005','40288a1239b4afd50139b4cc50050004','4028814b4a52768b014a5277089d0002',NULL,'1','2014-12-16 17:39:51','1','2014-12-16 17:39:51','1','0:0:0:0:0:0:0:1','0'),('40288ade39b599b70139b5aed68e0010','40288a1239b4afd50139b4cc50050004','40288af938989073013898b6d3410009','0','1','2012-09-11 22:14:57','1','2012-09-11 22:14:57','1','0:0:0:0:0:0:0:1','0'),('40288af938b6d2910138b6f18fbc0003','40288a46384feb2101384ff1ce8e0007','1',NULL,'1','2014-07-01 11:04:40','1','2014-07-01 11:04:40','1','0:0:0:0:0:0:0:1','0'),('8a58a6b44c275bab014c275e7ab3000b','8a58ab4d4c207cca014c207ffff7034c','8a58a6b44c275dce014c275dced90000',NULL,'1','2015-03-17 18:54:05','1','2015-03-17 18:54:05','1','10.216.43.205','0'),('8a58ab4d4c25bcb6014c25be6f1a0312','40288a46384feb2101384fef8ba80005','8a58ab4d4c25bd67014c25bdc1980001',NULL,'1','2015-03-17 11:19:39','1','2015-03-17 11:19:39','1','127.0.0.1','0'),('8a58ab4d4c25bcb6014c25bf9b750317','40288a46384feb2101384ff0efc20006','8a58ab4d4c25bd67014c25beb8780002',NULL,'1','2015-03-17 11:20:56','1','2015-03-17 11:20:56','1','127.0.0.1','0'),('8a58abf9439f061401439f0ca5d50006','40288a1239b4afd50139b4cc50050004','8a58abf9439f061401439f0ca4d50003',NULL,'1','2014-01-17 15:14:02','1','2014-01-17 15:14:02','1','0:0:0:0:0:0:0:1','0'),('8a58abf9449131b40144915e6a860010','40288a1239b4afd50139b4cc50050004','1','0','1','2014-03-05 16:31:27','1','2014-03-05 16:31:27','1','0:0:0:0:0:0:0:1','0');

/*Table structure for table `sys_word` */

DROP TABLE IF EXISTS `sys_word`;

CREATE TABLE `sys_word` (
  `ID` varchar(50) NOT NULL COMMENT '主键ID',
  `WORD_CODE` text NOT NULL COMMENT '正文代码',
  `WORD_NAME` text NOT NULL COMMENT '正文名称',
  `WORD_TYPE` varchar(10) NOT NULL COMMENT '正文类型',
  `WORD_BODY` longblob NOT NULL COMMENT '正文',
  `WORD_BAK` longblob COMMENT '正文副本',
  `WORD_STATE` varchar(10) NOT NULL COMMENT '正文状态',
  `WORD_LOCK_USER` varchar(50) DEFAULT NULL COMMENT '正文锁定用户',
  `WORD_LOCK_TIME` datetime DEFAULT NULL COMMENT '正文锁定时间',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(32) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(32) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(20) NOT NULL COMMENT '最后更新IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='正文表';

/*Data for the table `sys_word` */

/*Table structure for table `sys_word_seal` */

DROP TABLE IF EXISTS `sys_word_seal`;

CREATE TABLE `sys_word_seal` (
  `ID` varchar(50) NOT NULL COMMENT '主键ID',
  `SEAL_NAME` text NOT NULL COMMENT '印章名称',
  `SEAL_BODY` longblob COMMENT '印章文件',
  `SEAL_ADMINS` text COMMENT '访问印章的角色，以逗号分隔',
  `REMARK` text COMMENT '印章描述',
  `ORDER_BY` decimal(16,0) DEFAULT NULL COMMENT '排序',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '最后更新IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='印章表';

/*Data for the table `sys_word_seal` */

/*Table structure for table `sys_word_templet` */

DROP TABLE IF EXISTS `sys_word_templet`;

CREATE TABLE `sys_word_templet` (
  `ID` varchar(50) NOT NULL COMMENT '主键ID',
  `TEMPLET_NAME` text NOT NULL COMMENT '模板名称',
  `TEMPLET_BODY` longblob COMMENT '模板',
  `TEMPLET_TYPE` varchar(10) NOT NULL COMMENT '模板类型:1为正文模板，2为红头模板',
  `TEMPLET_VERSION` decimal(16,0) DEFAULT NULL COMMENT '模板版本',
  `TEMPLET_STATE` varchar(10) NOT NULL COMMENT '是否有效',
  `ORDER_BY` decimal(16,0) DEFAULT NULL COMMENT '模板排序',
  `FLOW_KEY` text COMMENT '所属流程KEY',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(32) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(32) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(20) NOT NULL COMMENT '最后更新IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='正文模板表';

/*Data for the table `sys_word_templet` */

/*Table structure for table `sys_word_templet_detail` */

DROP TABLE IF EXISTS `sys_word_templet_detail`;

CREATE TABLE `sys_word_templet_detail` (
  `ID` varchar(50) NOT NULL COMMENT '主键ID',
  `TEMPLET_ID` varchar(50) NOT NULL COMMENT '模板ID',
  `TEMPLET_TABLE` varchar(100) NOT NULL COMMENT '模板对应表',
  `TEMPLET_COLUMN` varchar(100) NOT NULL COMMENT '模板字段',
  `TEMPLET_COLUMN_TYPE` varchar(100) NOT NULL COMMENT '模板字段类型',
  `TEMPLET_COLUMN_NAME` text NOT NULL COMMENT '模板字段名称',
  `TEMPLET_COLUMN_NOTE` text COMMENT '模板字段备注',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(32) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(32) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(20) NOT NULL COMMENT '最后更新IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='正文模板同步域表';

/*Data for the table `sys_word_templet_detail` */

/*Table structure for table `sys_work_calendar` */

DROP TABLE IF EXISTS `sys_work_calendar`;

CREATE TABLE `sys_work_calendar` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `CALENDAR_NAME` varchar(100) DEFAULT NULL COMMENT '名称',
  `CALENDAR_DEFINE` longtext COMMENT '定义文件',
  `CALENDAR_DESC` varchar(240) DEFAULT NULL COMMENT '描述',
  `LAST_UPDATE_DATE` datetime NOT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) NOT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime NOT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) NOT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) NOT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) NOT NULL COMMENT '版本',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='工作日历表';

/*Data for the table `sys_work_calendar` */

/*Table structure for table `sys_work_hand` */

DROP TABLE IF EXISTS `sys_work_hand`;

CREATE TABLE `sys_work_hand` (
  `ID` varchar(50) NOT NULL COMMENT '主键ID',
  `HAND_REGISTER_USER_ID` varchar(50) DEFAULT NULL COMMENT '登记人',
  `HAND_REGISTER_DEPT_ID` varchar(50) DEFAULT NULL COMMENT '登记人部门',
  `HAND_REGISTER_ORG_ID` varchar(50) DEFAULT NULL COMMENT '登记人组织',
  `WORK_OWNER_ID` varchar(50) DEFAULT NULL COMMENT '移交人',
  `WORK_OWNER_DEPT_ID` varchar(50) DEFAULT NULL COMMENT '移交人部门',
  `WORK_OWNER_ORG_ID` varchar(50) DEFAULT NULL COMMENT '移交人组织',
  `RECEPT_USER_ID` varchar(50) DEFAULT NULL COMMENT '接收人',
  `RECEPT_DEPT_ID` varchar(50) DEFAULT NULL COMMENT '接收人部门',
  `RECEPT_ORG_ID` varchar(50) DEFAULT NULL COMMENT '接受人组织',
  `HAND_REASON` text COMMENT '移交原因',
  `HAND_DATE` datetime DEFAULT NULL COMMENT '登记日期',
  `BACK_DATE` datetime DEFAULT NULL COMMENT '预计返回日期',
  `HAND_EFFECTIVE_DATE` datetime DEFAULT NULL COMMENT '生效日期',
  `VALID_FLAG` varchar(2) DEFAULT NULL COMMENT '是否有效',
  `LAST_UPDATE_DATE` datetime DEFAULT NULL COMMENT '最后修改时间',
  `LAST_UPDATED_BY` varchar(50) DEFAULT NULL COMMENT '最后修改人',
  `CREATION_DATE` datetime DEFAULT NULL COMMENT '创建时间',
  `CREATED_BY` varchar(50) DEFAULT NULL COMMENT '创建人',
  `LAST_UPDATE_IP` varchar(50) DEFAULT NULL COMMENT '修改IP',
  `VERSION` decimal(16,0) DEFAULT NULL COMMENT '版本',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='工作移交表';

/*Data for the table `sys_work_hand` */

/*Table structure for table `sys_workbench_menu` */

DROP TABLE IF EXISTS `sys_workbench_menu`;

CREATE TABLE `sys_workbench_menu` (
  `ID` varchar(50) NOT NULL,
  `SYSUSERID` varchar(200) DEFAULT NULL,
  `SYSMENUID` varchar(200) DEFAULT NULL,
  `ALIASMENUNAME` varchar(200) DEFAULT NULL,
  `ICONCLASS` varchar(200) DEFAULT NULL,
  `SORT` decimal(65,30) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sys_workbench_menu` */

/*Table structure for table `sys_workbench_portlet_config` */

DROP TABLE IF EXISTS `sys_workbench_portlet_config`;

CREATE TABLE `sys_workbench_portlet_config` (
  `ID` varchar(50) NOT NULL COMMENT '主键',
  `USERID` varchar(100) DEFAULT NULL COMMENT '用户id',
  `LAYOUT_EXTENDS` text COMMENT '角色名称，以","分割',
  `LAYOUT` varchar(50) DEFAULT NULL COMMENT '布局',
  `ORDER_BY` decimal(16,0) DEFAULT NULL COMMENT '排序',
  `LAST_UPDATE_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` varchar(50) DEFAULT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `CREATED_BY` varchar(50) DEFAULT NULL,
  `LAST_UPDATE_IP` varchar(50) DEFAULT NULL,
  `VERSION` decimal(16,0) DEFAULT NULL,
  `NAME` varchar(50) DEFAULT NULL COMMENT '模版名称',
  `ATTRIBUTE_01` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_02` text COMMENT '扩展字段',
  `ATTRIBUTE_03` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_04` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_05` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_06` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_07` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_08` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_09` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `ATTRIBUTE_10` text COMMENT '扩展字段',
  `ROLE_ID` text COMMENT '角色id集合，以","分割',
  `SYS_APPLICATION_ID` varchar(50) DEFAULT NULL,
  `INDEX_URL` text COMMENT '首页地址',
  `INDEX_TYPE` varchar(1) DEFAULT NULL COMMENT '首页类型0系统首页1自定义首页',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sys_workbench_portlet_config` */

/*Table structure for table `t_document` */

DROP TABLE IF EXISTS `t_document`;

CREATE TABLE `t_document` (
  `ID` text NOT NULL,
  `LASTMODIFIED` datetime DEFAULT NULL,
  `FORMNAME` text,
  `OWNER` text,
  `AUDITDATE` datetime DEFAULT NULL,
  `AUTHOR` text,
  `AUTHOR_DEPT_INDEX` text,
  `CREATED` datetime DEFAULT NULL,
  `ISSUBDOC` decimal(1,0) DEFAULT NULL,
  `FORMID` text,
  `ISTMP` decimal(1,0) DEFAULT NULL,
  `VERSIONS` decimal(10,0) DEFAULT NULL,
  `SORTID` text,
  `APPLICATIONID` text,
  `STATELABEL` text,
  `INITIATOR` text,
  `AUDITUSER` text,
  `AUDITORNAMES` longtext,
  `LASTFLOWOPERATION` text,
  `PARENT` text,
  `STATE` text,
  `STATEINT` decimal(10,0) DEFAULT NULL,
  `LASTMODIFIER` text,
  `DOMAINID` text,
  `AUDITORLIST` longtext,
  `MAPPINGID` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_document` */

/*Table structure for table `t_upload` */

DROP TABLE IF EXISTS `t_upload`;

CREATE TABLE `t_upload` (
  `ID` text,
  `NAME` text,
  `IMGBINARY` longblob,
  `FIELDID` text,
  `TYPE` text,
  `FILESIZE` decimal(10,0) DEFAULT NULL,
  `USERID` text,
  `MODIFYDATE` text,
  `PATH` text,
  `FOLDERPATH` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_upload` */

/*Table structure for table `bpm_actinst_console_v` */

DROP TABLE IF EXISTS `bpm_actinst_console_v`;

/*!50001 DROP VIEW IF EXISTS `bpm_actinst_console_v` */;
/*!50001 DROP TABLE IF EXISTS `bpm_actinst_console_v` */;

/*!50001 CREATE TABLE  `bpm_actinst_console_v`(
 `dbId` varchar(50) ,
 `pdId` varchar(255) ,
 `entryId` varchar(50) ,
 `TYPE` varchar(255) ,
 `executionId` varchar(255) ,
 `activityName` varchar(255) ,
 `startTime` datetime ,
 `endTime` datetime ,
 `duration` decimal(19,0) ,
 `activityAlias` varchar(255) 
)*/;

/*Table structure for table `bpm_client_hist_procinst_v` */

DROP TABLE IF EXISTS `bpm_client_hist_procinst_v`;

/*!50001 DROP VIEW IF EXISTS `bpm_client_hist_procinst_v` */;
/*!50001 DROP TABLE IF EXISTS `bpm_client_hist_procinst_v` */;

/*!50001 CREATE TABLE  `bpm_client_hist_procinst_v`(
 `DBID_` varchar(50) ,
 `ID_` varchar(255) ,
 `PROCDEFID_` varchar(255) ,
 `START_` datetime ,
 `END_` datetime ,
 `STATE_` varchar(255) ,
 `FORMID_` varchar(50) ,
 `TITLE_` varchar(255) ,
 `USERID_` varchar(255) ,
 `DEPTID_` varchar(255) ,
 `BUSINESSSTATE_` varchar(255) ,
 `ACTIVITYALIAS_` text ,
 `LAST_UPDATE_DATE_` datetime 
)*/;

/*Table structure for table `bpm_client_hist_task_v` */

DROP TABLE IF EXISTS `bpm_client_hist_task_v`;

/*!50001 DROP VIEW IF EXISTS `bpm_client_hist_task_v` */;
/*!50001 DROP TABLE IF EXISTS `bpm_client_hist_task_v` */;

/*!50001 CREATE TABLE  `bpm_client_hist_task_v`(
 `DBID_` varchar(50) ,
 `EXECUTION_` varchar(255) ,
 `OUTCOME_` varchar(255) ,
 `ASSIGNEE_` varchar(255) ,
 `STATE_` varchar(255) ,
 `CREATE_` datetime ,
 `END_` datetime ,
 `TASK_ORDER_` varchar(255) ,
 `OPEN_` datetime ,
 `TAKE_STATE_` varchar(255) ,
 `PROCINST_` varchar(50) ,
 `TASK_TYPE_` varchar(255) ,
 `TASK_B_ID_` varchar(255) ,
 `TASK_TITLE_` varchar(255) ,
 `TASK_SENDUSER_` varchar(255) ,
 `TASK_SENDDEPT_` varchar(255) ,
 `FORM_` varchar(255) ,
 `PROCESS_DEF_NAME_` varchar(255) ,
 `TASK_FINISHED_` varchar(255) ,
 `TASK_STATE_` varchar(255) ,
 `TASK_NAME_` varchar(255) ,
 `HISACTINST_` varchar(50) ,
 `WORKHAND_TYPE_` varchar(255) ,
 `WORKHAND_USER_` varchar(255) ,
 `APP_ID_` varchar(255) ,
 `ASSIGNEE_DEPT_` varchar(255) ,
 `LAST_UPDATE_DATE_` datetime 
)*/;

/*Table structure for table `bpm_def_dept_v` */

DROP TABLE IF EXISTS `bpm_def_dept_v`;

/*!50001 DROP VIEW IF EXISTS `bpm_def_dept_v` */;
/*!50001 DROP TABLE IF EXISTS `bpm_def_dept_v` */;

/*!50001 CREATE TABLE  `bpm_def_dept_v`(
 `id` varchar(50) ,
 `dept_code` varchar(100) ,
 `dept_name` varchar(100) ,
 `parent_dept_id` varchar(50) ,
 `org_id` varchar(50) ,
 `order_by` decimal(16,0) 
)*/;

/*Table structure for table `bpm_def_group_v` */

DROP TABLE IF EXISTS `bpm_def_group_v`;

/*!50001 DROP VIEW IF EXISTS `bpm_def_group_v` */;
/*!50001 DROP TABLE IF EXISTS `bpm_def_group_v` */;

/*!50001 CREATE TABLE  `bpm_def_group_v`(
 `id` varchar(50) ,
 `group_name` varchar(100) ,
 `group_parent_id` varchar(50) ,
 `type` varchar(1) ,
 `org_id` varchar(50) ,
 `order_by` decimal(16,0) 
)*/;

/*Table structure for table `bpm_def_org_v` */

DROP TABLE IF EXISTS `bpm_def_org_v`;

/*!50001 DROP VIEW IF EXISTS `bpm_def_org_v` */;
/*!50001 DROP TABLE IF EXISTS `bpm_def_org_v` */;

/*!50001 CREATE TABLE  `bpm_def_org_v`(
 `id` varchar(50) ,
 `org_code` varchar(100) ,
 `org_name` varchar(100) ,
 `parent_org_id` varchar(100) ,
 `order_by` decimal(16,0) 
)*/;

/*Table structure for table `bpm_def_position_v` */

DROP TABLE IF EXISTS `bpm_def_position_v`;

/*!50001 DROP VIEW IF EXISTS `bpm_def_position_v` */;
/*!50001 DROP TABLE IF EXISTS `bpm_def_position_v` */;

/*!50001 CREATE TABLE  `bpm_def_position_v`(
 `id` varchar(50) ,
 `position_code` varchar(50) ,
 `position_name` varchar(100) ,
 `org_id` varchar(50) ,
 `order_by` decimal(16,0) 
)*/;

/*Table structure for table `bpm_def_role_v` */

DROP TABLE IF EXISTS `bpm_def_role_v`;

/*!50001 DROP VIEW IF EXISTS `bpm_def_role_v` */;
/*!50001 DROP TABLE IF EXISTS `bpm_def_role_v` */;

/*!50001 CREATE TABLE  `bpm_def_role_v`(
 `id` varchar(50) ,
 `role_code` varchar(50) ,
 `role_name` varchar(50) ,
 `role_group` varchar(50) ,
 `role_type` varchar(1) ,
 `order_by` decimal(16,0) 
)*/;

/*Table structure for table `bpm_def_user_dept_position_v` */

DROP TABLE IF EXISTS `bpm_def_user_dept_position_v`;

/*!50001 DROP VIEW IF EXISTS `bpm_def_user_dept_position_v` */;
/*!50001 DROP TABLE IF EXISTS `bpm_def_user_dept_position_v` */;

/*!50001 CREATE TABLE  `bpm_def_user_dept_position_v`(
 `id` varchar(50) ,
 `user_id` varchar(50) ,
 `dept_id` varchar(50) ,
 `position_id` varchar(50) ,
 `is_chief_dept` varchar(1) ,
 `is_manager` varchar(1) ,
 `order_by` decimal(16,0) 
)*/;

/*Table structure for table `bpm_def_user_v` */

DROP TABLE IF EXISTS `bpm_def_user_v`;

/*!50001 DROP VIEW IF EXISTS `bpm_def_user_v` */;
/*!50001 DROP TABLE IF EXISTS `bpm_def_user_v` */;

/*!50001 CREATE TABLE  `bpm_def_user_v`(
 `id` varchar(50) ,
 `name` varchar(50) ,
 `login_name` varchar(50) ,
 `login_password` varchar(50) ,
 `status` varchar(2) ,
 `order_by` decimal(16,0) 
)*/;

/*Table structure for table `bpm_entry_console_v` */

DROP TABLE IF EXISTS `bpm_entry_console_v`;

/*!50001 DROP VIEW IF EXISTS `bpm_entry_console_v` */;
/*!50001 DROP TABLE IF EXISTS `bpm_entry_console_v` */;

/*!50001 CREATE TABLE  `bpm_entry_console_v`(
 `entryId` varchar(50) ,
 `entryName` varchar(255) ,
 `defineName` varchar(255) ,
 `state` varchar(255) ,
 `userId` varchar(255) ,
 `deptId` varchar(255) ,
 `startDate` datetime ,
 `endDate` datetime ,
 `keyone` varchar(255) ,
 `deployment` varchar(50) ,
 `executionId` varchar(255) ,
 `pdId` varchar(255) ,
 `duration` decimal(19,0) ,
 `formId` varchar(50) ,
 `LOCKED_STATUS_` varchar(30) 
)*/;

/*Table structure for table `bpm_entry_v` */

DROP TABLE IF EXISTS `bpm_entry_v`;

/*!50001 DROP VIEW IF EXISTS `bpm_entry_v` */;
/*!50001 DROP TABLE IF EXISTS `bpm_entry_v` */;

/*!50001 CREATE TABLE  `bpm_entry_v`(
 `DBID_` varchar(50) ,
 `DBVERSION_` decimal(10,0) ,
 `ID_` varchar(255) ,
 `PROCDEFID_` varchar(255) ,
 `KEY_` varchar(255) ,
 `START_` datetime ,
 `END_` datetime ,
 `DURATION_` decimal(19,0) ,
 `STATE_` varchar(255) ,
 `ENDACTIVITY_` varchar(255) ,
 `NEXTIDX_` decimal(10,0) ,
 `FORMID_` varchar(50) ,
 `USERID_` varchar(255) ,
 `DEPTID_` varchar(255) ,
 `activityname_` varchar(255) ,
 `activityalias_` varchar(255) ,
 `businessstate_` varchar(255) 
)*/;

/*Table structure for table `bpm_hist_procinst_v` */

DROP TABLE IF EXISTS `bpm_hist_procinst_v`;

/*!50001 DROP VIEW IF EXISTS `bpm_hist_procinst_v` */;
/*!50001 DROP TABLE IF EXISTS `bpm_hist_procinst_v` */;

/*!50001 CREATE TABLE  `bpm_hist_procinst_v`(
 `DBID_` varchar(50) ,
 `DBVERSION_` decimal(10,0) ,
 `ID_` varchar(255) ,
 `PROCDEFID_` varchar(255) ,
 `KEY_` varchar(255) ,
 `START_` datetime ,
 `END_` datetime ,
 `DURATION_` decimal(19,0) ,
 `STATE_` varchar(255) ,
 `ENDACTIVITY_` varchar(255) ,
 `NEXTIDX_` decimal(10,0) ,
 `FORMID_` varchar(50) ,
 `TITLE_` varchar(255) ,
 `USERID_` varchar(255) ,
 `DEPTID_` varchar(255) ,
 `POSITIONID_` varchar(50) 
)*/;

/*Table structure for table `bpm_hist_task_analys_v` */

DROP TABLE IF EXISTS `bpm_hist_task_analys_v`;

/*!50001 DROP VIEW IF EXISTS `bpm_hist_task_analys_v` */;
/*!50001 DROP TABLE IF EXISTS `bpm_hist_task_analys_v` */;

/*!50001 CREATE TABLE  `bpm_hist_task_analys_v`(
 `DBID_` varchar(50) ,
 `DBVERSION_` decimal(10,0) ,
 `EXECUTION_` varchar(255) ,
 `OUTCOME_` varchar(255) ,
 `ASSIGNEE_` varchar(255) ,
 `PRIORITY_` decimal(10,0) ,
 `STATE_` varchar(255) ,
 `CREATE_` datetime ,
 `END_` datetime ,
 `DURATION_` decimal(19,0) ,
 `NEXTIDX_` decimal(10,0) ,
 `SUPERTASK_` varchar(50) ,
 `TASK_ORDER_` varchar(255) ,
 `OPEN_` datetime ,
 `TAKE_STATE_` varchar(255) ,
 `PROCINST_` varchar(50) ,
 `DESCR_` longtext ,
 `SUSPHISTSTATE_` varchar(255) ,
 `TASK_TYPE_` varchar(255) ,
 `TASK_B_ID_` varchar(255) ,
 `TASK_TITLE_` varchar(255) ,
 `TASK_SENDUSER_` varchar(255) ,
 `TASK_SENDDEPT_` varchar(255) ,
 `FORM_` varchar(255) ,
 `PROCESS_DEF_NAME_` varchar(255) ,
 `TASK_FINISHED_` varchar(255) ,
 `TASK_STATE_` varchar(255) ,
 `TASK_NAME_` varchar(255) ,
 `HISACTINST_` varchar(50) ,
 `WORKHAND_TYPE_` varchar(255) ,
 `WORKHAND_USER_` varchar(255) ,
 `APP_ID_` varchar(255) ,
 `ASSIGNEE_DEPT_` varchar(255) ,
 `ASSIGNEE_POSITION_` varchar(50) 
)*/;

/*Table structure for table `bpm_hist_task_v` */

DROP TABLE IF EXISTS `bpm_hist_task_v`;

/*!50001 DROP VIEW IF EXISTS `bpm_hist_task_v` */;
/*!50001 DROP TABLE IF EXISTS `bpm_hist_task_v` */;

/*!50001 CREATE TABLE  `bpm_hist_task_v`(
 `DBID_` varchar(50) ,
 `DBVERSION_` decimal(10,0) ,
 `EXECUTION_` varchar(255) ,
 `OUTCOME_` varchar(255) ,
 `ASSIGNEE_` varchar(255) ,
 `PRIORITY_` decimal(10,0) ,
 `STATE_` varchar(255) ,
 `CREATE_` datetime ,
 `END_` datetime ,
 `DURATION_` decimal(19,0) ,
 `NEXTIDX_` decimal(10,0) ,
 `SUPERTASK_` varchar(50) ,
 `TASK_ORDER_` varchar(255) ,
 `OPEN_` datetime ,
 `TAKE_STATE_` varchar(255) ,
 `PROCINST_` varchar(50) ,
 `DESCR_` longtext ,
 `SUSPHISTSTATE_` varchar(255) ,
 `TASK_TYPE_` varchar(255) ,
 `TASK_B_ID_` varchar(255) ,
 `TASK_TITLE_` varchar(255) ,
 `TASK_SENDUSER_` varchar(255) ,
 `TASK_SENDDEPT_` varchar(255) ,
 `FORM_` varchar(255) ,
 `PROCESS_DEF_NAME_` varchar(255) ,
 `TASK_FINISHED_` varchar(255) ,
 `TASK_STATE_` varchar(255) ,
 `TASK_NAME_` varchar(255) ,
 `HISACTINST_` varchar(50) ,
 `WORKHAND_TYPE_` varchar(255) ,
 `WORKHAND_USER_` varchar(255) ,
 `APP_ID_` varchar(255) ,
 `ASSIGNEE_DEPT_` varchar(255) ,
 `LOCKED_STATUS_` varchar(30) ,
 `ASSIGNEE_POSITION_` varchar(50) 
)*/;

/*Table structure for table `bpm_process_deploy_v` */

DROP TABLE IF EXISTS `bpm_process_deploy_v`;

/*!50001 DROP VIEW IF EXISTS `bpm_process_deploy_v` */;
/*!50001 DROP TABLE IF EXISTS `bpm_process_deploy_v` */;

/*!50001 CREATE TABLE  `bpm_process_deploy_v`(
 `DBID_` varchar(32) ,
 `KEY_` varchar(100) ,
 `NAME_` varchar(100) ,
 `DESC_` text ,
 `APP_` varchar(100) ,
 `DEF_ID_` varchar(50) ,
 `DEF_TYPE_` varchar(1) ,
 `XML_` longblob ,
 `VERSION_` decimal(19,0) 
)*/;

/*Table structure for table `sys_dept_org_position_v` */

DROP TABLE IF EXISTS `sys_dept_org_position_v`;

/*!50001 DROP VIEW IF EXISTS `sys_dept_org_position_v` */;
/*!50001 DROP TABLE IF EXISTS `sys_dept_org_position_v` */;

/*!50001 CREATE TABLE  `sys_dept_org_position_v`(
 `id` varchar(50) ,
 `user_id` varchar(50) ,
 `user_name` varchar(50) ,
 `dept_id` varchar(50) ,
 `dept_name` varchar(100) ,
 `org_id` varchar(50) ,
 `position_id` varchar(50) ,
 `position_name` varchar(100) ,
 `is_chief_dept` varchar(1) 
)*/;

/*Table structure for table `sys_dept_v` */

DROP TABLE IF EXISTS `sys_dept_v`;

/*!50001 DROP VIEW IF EXISTS `sys_dept_v` */;
/*!50001 DROP TABLE IF EXISTS `sys_dept_v` */;

/*!50001 CREATE TABLE  `sys_dept_v`(
 `id` varchar(50) ,
 `dept_code` varchar(100) ,
 `parent_dept_id` varchar(50) ,
 `org_id` varchar(50) ,
 `order_by` decimal(16,0) ,
 `post` varchar(50) ,
 `tel` varchar(50) ,
 `fax` varchar(50) ,
 `email` varchar(50) ,
 `dept_alias` varchar(50) ,
 `valid_flag` varchar(1) ,
 `work_calendar_id` varchar(50) ,
 `dept_name` varchar(100) ,
 `dept_desc` varchar(240) ,
 `dept_place` varchar(100) 
)*/;

/*Table structure for table `sys_lookup_v` */

DROP TABLE IF EXISTS `sys_lookup_v`;

/*!50001 DROP VIEW IF EXISTS `sys_lookup_v` */;
/*!50001 DROP TABLE IF EXISTS `sys_lookup_v` */;

/*!50001 CREATE TABLE  `sys_lookup_v`(
 `id` varchar(50) ,
 `lookup_type` varchar(50) ,
 `sys_application_id` varchar(50) ,
 `lookup_type_name` varchar(100) ,
 `lookup_code` text ,
 `lookup_id` varchar(50) ,
 `lookup_name` varchar(100) 
)*/;

/*Table structure for table `sys_org_v` */

DROP TABLE IF EXISTS `sys_org_v`;

/*!50001 DROP VIEW IF EXISTS `sys_org_v` */;
/*!50001 DROP TABLE IF EXISTS `sys_org_v` */;

/*!50001 CREATE TABLE  `sys_org_v`(
 `ID` varchar(50) ,
 `ORG_CODE` varchar(100) ,
 `PARENT_ORG_ID` varchar(100) ,
 `ORDER_BY` decimal(16,0) ,
 `POST` varchar(50) ,
 `TEL` varchar(50) ,
 `FAX` varchar(50) ,
 `EMAIL` varchar(50) ,
 `WORK_CALENDAR_ID` varchar(50) ,
 `VALID_FLAG` varchar(1) ,
 `responsible_dept_id` varchar(50) ,
 `org_name` varchar(100) ,
 `org_desc` varchar(240) ,
 `org_place` varchar(100) 
)*/;

/*Table structure for table `sys_position_v` */

DROP TABLE IF EXISTS `sys_position_v`;

/*!50001 DROP VIEW IF EXISTS `sys_position_v` */;
/*!50001 DROP TABLE IF EXISTS `sys_position_v` */;

/*!50001 CREATE TABLE  `sys_position_v`(
 `ID` varchar(50) ,
 `ORG_ID` varchar(50) ,
 `POSITION_CODE` varchar(50) ,
 `ORDER_BY` decimal(16,0) ,
 `LAST_UPDATE_DATE` datetime ,
 `LAST_UPDATED_BY` varchar(50) ,
 `CREATION_DATE` datetime ,
 `CREATED_BY` varchar(50) ,
 `LAST_UPDATE_IP` varchar(50) ,
 `VERSION` decimal(16,0) ,
 `ATTRIBUTE_01` varchar(255) ,
 `ATTRIBUTE_02` varchar(255) ,
 `ATTRIBUTE_03` varchar(255) ,
 `ATTRIBUTE_04` varchar(255) ,
 `ATTRIBUTE_05` varchar(255) ,
 `ATTRIBUTE_06` varchar(255) ,
 `ATTRIBUTE_07` varchar(255) ,
 `ATTRIBUTE_08` varchar(255) ,
 `ATTRIBUTE_09` varchar(255) ,
 `ATTRIBUTE_10` varchar(255) ,
 `position_name` varchar(100) ,
 `position_desc` varchar(240) 
)*/;

/*View structure for view bpm_actinst_console_v */

/*!50001 DROP TABLE IF EXISTS `bpm_actinst_console_v` */;
/*!50001 DROP VIEW IF EXISTS `bpm_actinst_console_v` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bpm_actinst_console_v` AS select `t2`.`DBID_` AS `dbId`,`t1`.`PROCDEFID_` AS `pdId`,`t2`.`HPROCI_` AS `entryId`,`t2`.`TYPE_` AS `TYPE`,`t2`.`EXECUTION_` AS `executionId`,`t2`.`ACTIVITY_NAME_` AS `activityName`,`t2`.`START_` AS `startTime`,`t2`.`END_` AS `endTime`,`t2`.`DURATION_` AS `duration`,`t2`.`ALIAS_` AS `activityAlias` from (`bpm_hist_procinst` `t1` left join `bpm_hist_actinst` `t2` on((`t1`.`DBID_` = `t2`.`HPROCI_`))) union all select `t2`.`DBID_` AS `dbId`,`t1`.`PROCDEFID_` AS `pdId`,`t2`.`HPROCI_` AS `entryId`,`t2`.`TYPE_` AS `TYPE`,`t2`.`EXECUTION_` AS `executionId`,`t2`.`ACTIVITY_NAME_` AS `activityName`,`t2`.`START_` AS `startTime`,`t2`.`END_` AS `endTime`,`t2`.`DURATION_` AS `duration`,`t2`.`ALIAS_` AS `activityAlias` from (`bpm_hist_procinst` `t1` left join `bpm_hist_actinst_ext1` `t2` on((`t1`.`DBID_` = `t2`.`HPROCI_`))) union all select `t2`.`DBID_` AS `dbId`,`t1`.`PROCDEFID_` AS `pdId`,`t2`.`HPROCI_` AS `entryId`,`t2`.`TYPE_` AS `TYPE`,`t2`.`EXECUTION_` AS `executionId`,`t2`.`ACTIVITY_NAME_` AS `activityName`,`t2`.`START_` AS `startTime`,`t2`.`END_` AS `endTime`,`t2`.`DURATION_` AS `duration`,`t2`.`ALIAS_` AS `activityAlias` from (`bpm_hist_procinst` `t1` left join `bpm_hist_actinst_ext2` `t2` on((`t1`.`DBID_` = `t2`.`HPROCI_`))) union all select `t2`.`DBID_` AS `dbId`,`t1`.`PROCDEFID_` AS `pdId`,`t2`.`HPROCI_` AS `entryId`,`t2`.`TYPE_` AS `TYPE`,`t2`.`EXECUTION_` AS `executionId`,`t2`.`ACTIVITY_NAME_` AS `activityName`,`t2`.`START_` AS `startTime`,`t2`.`END_` AS `endTime`,`t2`.`DURATION_` AS `duration`,`t2`.`ALIAS_` AS `activityAlias` from (`bpm_hist_procinst` `t1` left join `bpm_hist_actinst_ext3` `t2` on((`t1`.`DBID_` = `t2`.`HPROCI_`))) union all select `t2`.`DBID_` AS `dbId`,`t1`.`PROCDEFID_` AS `pdId`,`t2`.`HPROCI_` AS `entryId`,`t2`.`TYPE_` AS `TYPE`,`t2`.`EXECUTION_` AS `executionId`,`t2`.`ACTIVITY_NAME_` AS `activityName`,`t2`.`START_` AS `startTime`,`t2`.`END_` AS `endTime`,`t2`.`DURATION_` AS `duration`,`t2`.`ALIAS_` AS `activityAlias` from (`bpm_hist_procinst` `t1` left join `bpm_hist_actinst_ext4` `t2` on((`t1`.`DBID_` = `t2`.`HPROCI_`))) union all select `t2`.`DBID_` AS `dbId`,`t1`.`PROCDEFID_` AS `pdId`,`t2`.`HPROCI_` AS `entryId`,`t2`.`TYPE_` AS `TYPE`,`t2`.`EXECUTION_` AS `executionId`,`t2`.`ACTIVITY_NAME_` AS `activityName`,`t2`.`START_` AS `startTime`,`t2`.`END_` AS `endTime`,`t2`.`DURATION_` AS `duration`,`t2`.`ALIAS_` AS `activityAlias` from (`bpm_hist_procinst` `t1` left join `bpm_hist_actinst_ext5` `t2` on((`t1`.`DBID_` = `t2`.`HPROCI_`))) union all select `t2`.`DBID_` AS `dbId`,`t1`.`PROCDEFID_` AS `pdId`,`t2`.`HPROCI_` AS `entryId`,`t2`.`TYPE_` AS `TYPE`,`t2`.`EXECUTION_` AS `executionId`,`t2`.`ACTIVITY_NAME_` AS `activityName`,`t2`.`START_` AS `startTime`,`t2`.`END_` AS `endTime`,`t2`.`DURATION_` AS `duration`,`t2`.`ALIAS_` AS `activityAlias` from (`bpm_hist_procinst` `t1` left join `bpm_hist_actinst_ext6` `t2` on((`t1`.`DBID_` = `t2`.`HPROCI_`))) union all select `t2`.`DBID_` AS `dbId`,`t1`.`PROCDEFID_` AS `pdId`,`t2`.`HPROCI_` AS `entryId`,`t2`.`TYPE_` AS `TYPE`,`t2`.`EXECUTION_` AS `executionId`,`t2`.`ACTIVITY_NAME_` AS `activityName`,`t2`.`START_` AS `startTime`,`t2`.`END_` AS `endTime`,`t2`.`DURATION_` AS `duration`,`t2`.`ALIAS_` AS `activityAlias` from (`bpm_hist_procinst` `t1` left join `bpm_hist_actinst_ext7` `t2` on((`t1`.`DBID_` = `t2`.`HPROCI_`))) union all select `t2`.`DBID_` AS `dbId`,`t1`.`PROCDEFID_` AS `pdId`,`t2`.`HPROCI_` AS `entryId`,`t2`.`TYPE_` AS `TYPE`,`t2`.`EXECUTION_` AS `executionId`,`t2`.`ACTIVITY_NAME_` AS `activityName`,`t2`.`START_` AS `startTime`,`t2`.`END_` AS `endTime`,`t2`.`DURATION_` AS `duration`,`t2`.`ALIAS_` AS `activityAlias` from (`bpm_hist_procinst` `t1` left join `bpm_hist_actinst_ext8` `t2` on((`t1`.`DBID_` = `t2`.`HPROCI_`))) */;

/*View structure for view bpm_client_hist_procinst_v */

/*!50001 DROP TABLE IF EXISTS `bpm_client_hist_procinst_v` */;
/*!50001 DROP VIEW IF EXISTS `bpm_client_hist_procinst_v` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bpm_client_hist_procinst_v` AS select `sys_bpm_hist_procinst`.`DBID_` AS `DBID_`,`sys_bpm_hist_procinst`.`ID_` AS `ID_`,`sys_bpm_hist_procinst`.`PROCDEFID_` AS `PROCDEFID_`,`sys_bpm_hist_procinst`.`START_` AS `START_`,`sys_bpm_hist_procinst`.`END_` AS `END_`,`sys_bpm_hist_procinst`.`STATE_` AS `STATE_`,`sys_bpm_hist_procinst`.`FORMID_` AS `FORMID_`,`sys_bpm_hist_procinst`.`TITLE_` AS `TITLE_`,`sys_bpm_hist_procinst`.`USERID_` AS `USERID_`,`sys_bpm_hist_procinst`.`DEPTID_` AS `DEPTID_`,`sys_bpm_hist_procinst`.`BUSINESSSTATE_` AS `BUSINESSSTATE_`,`sys_bpm_hist_procinst`.`ACTIVITYALIAS_` AS `ACTIVITYALIAS_`,`sys_bpm_hist_procinst`.`LAST_UPDATE_DATE_` AS `LAST_UPDATE_DATE_` from `sys_bpm_hist_procinst` */;

/*View structure for view bpm_client_hist_task_v */

/*!50001 DROP TABLE IF EXISTS `bpm_client_hist_task_v` */;
/*!50001 DROP VIEW IF EXISTS `bpm_client_hist_task_v` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bpm_client_hist_task_v` AS select `sys_bpm_hist_task`.`DBID_` AS `DBID_`,`sys_bpm_hist_task`.`EXECUTION_` AS `EXECUTION_`,`sys_bpm_hist_task`.`OUTCOME_` AS `OUTCOME_`,`sys_bpm_hist_task`.`ASSIGNEE_` AS `ASSIGNEE_`,`sys_bpm_hist_task`.`STATE_` AS `STATE_`,`sys_bpm_hist_task`.`CREATE_` AS `CREATE_`,`sys_bpm_hist_task`.`END_` AS `END_`,`sys_bpm_hist_task`.`TASK_ORDER_` AS `TASK_ORDER_`,`sys_bpm_hist_task`.`OPEN_` AS `OPEN_`,`sys_bpm_hist_task`.`TAKE_STATE_` AS `TAKE_STATE_`,`sys_bpm_hist_task`.`PROCINST_` AS `PROCINST_`,`sys_bpm_hist_task`.`TASK_TYPE_` AS `TASK_TYPE_`,`sys_bpm_hist_task`.`TASK_B_ID_` AS `TASK_B_ID_`,`sys_bpm_hist_task`.`TASK_TITLE_` AS `TASK_TITLE_`,`sys_bpm_hist_task`.`TASK_SENDUSER_` AS `TASK_SENDUSER_`,`sys_bpm_hist_task`.`TASK_SENDDEPT_` AS `TASK_SENDDEPT_`,`sys_bpm_hist_task`.`FORM_` AS `FORM_`,`sys_bpm_hist_task`.`PROCESS_DEF_NAME_` AS `PROCESS_DEF_NAME_`,`sys_bpm_hist_task`.`TASK_FINISHED_` AS `TASK_FINISHED_`,`sys_bpm_hist_task`.`TASK_STATE_` AS `TASK_STATE_`,`sys_bpm_hist_task`.`TASK_NAME_` AS `TASK_NAME_`,`sys_bpm_hist_task`.`HISACTINST_` AS `HISACTINST_`,`sys_bpm_hist_task`.`WORKHAND_TYPE_` AS `WORKHAND_TYPE_`,`sys_bpm_hist_task`.`WORKHAND_USER_` AS `WORKHAND_USER_`,`sys_bpm_hist_task`.`APP_ID_` AS `APP_ID_`,`sys_bpm_hist_task`.`ASSIGNEE_DEPT_` AS `ASSIGNEE_DEPT_`,`sys_bpm_hist_task`.`LAST_UPDATE_DATE_` AS `LAST_UPDATE_DATE_` from `sys_bpm_hist_task` */;

/*View structure for view bpm_def_dept_v */

/*!50001 DROP TABLE IF EXISTS `bpm_def_dept_v` */;
/*!50001 DROP VIEW IF EXISTS `bpm_def_dept_v` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bpm_def_dept_v` AS select `t`.`ID` AS `id`,`t`.`DEPT_CODE` AS `dept_code`,`tl`.`DEPT_NAME` AS `dept_name`,`t`.`PARENT_DEPT_ID` AS `parent_dept_id`,`t`.`ORG_ID` AS `org_id`,`t`.`ORDER_BY` AS `order_by` from (`sys_dept` `t` left join `sys_dept_tl` `tl` on((`t`.`ID` = `tl`.`SYS_DEPT_ID`))) where ((`t`.`VALID_FLAG` = '1') and (`tl`.`SYS_LANGUAGE_CODE` = 'zh_CN')) */;

/*View structure for view bpm_def_group_v */

/*!50001 DROP TABLE IF EXISTS `bpm_def_group_v` */;
/*!50001 DROP VIEW IF EXISTS `bpm_def_group_v` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bpm_def_group_v` AS select `t`.`ID` AS `id`,`tl`.`GROUP_NAME` AS `group_name`,`t`.`GROUP_PARENT_ID` AS `group_parent_id`,`t`.`TYPE` AS `type`,`t`.`ORG_ID` AS `org_id`,`t`.`ORDER_BY` AS `order_by` from (`sys_group` `t` left join `sys_group_tl` `tl` on((`t`.`ID` = `tl`.`SYS_GROUP_ID`))) where ((`t`.`VALID_FLAG` = '1') and (`tl`.`SYS_LANGUAGE_CODE` = 'zh_CN')) */;

/*View structure for view bpm_def_org_v */

/*!50001 DROP TABLE IF EXISTS `bpm_def_org_v` */;
/*!50001 DROP VIEW IF EXISTS `bpm_def_org_v` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bpm_def_org_v` AS select `t`.`ID` AS `id`,`t`.`ORG_CODE` AS `org_code`,`tl`.`ORG_NAME` AS `org_name`,`t`.`PARENT_ORG_ID` AS `parent_org_id`,`t`.`ORDER_BY` AS `order_by` from (`sys_org` `t` left join `sys_org_tl` `tl` on((`t`.`ID` = `tl`.`SYS_ORG_ID`))) where ((`t`.`VALID_FLAG` = '1') and (`tl`.`SYS_LANGUAGE_CODE` = 'zh_CN')) */;

/*View structure for view bpm_def_position_v */

/*!50001 DROP TABLE IF EXISTS `bpm_def_position_v` */;
/*!50001 DROP VIEW IF EXISTS `bpm_def_position_v` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bpm_def_position_v` AS select `t`.`ID` AS `id`,`t`.`POSITION_CODE` AS `position_code`,`tl`.`POSITION_NAME` AS `position_name`,`t`.`ORG_ID` AS `org_id`,`t`.`ORDER_BY` AS `order_by` from (`sys_position` `t` left join `sys_position_tl` `tl` on((`t`.`ID` = `tl`.`SYS_POSITION_ID`))) where (`tl`.`SYS_LANGUAGE_CODE` = 'zh_CN') */;

/*View structure for view bpm_def_role_v */

/*!50001 DROP TABLE IF EXISTS `bpm_def_role_v` */;
/*!50001 DROP VIEW IF EXISTS `bpm_def_role_v` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bpm_def_role_v` AS select `t`.`ID` AS `id`,`t`.`ROLE_CODE` AS `role_code`,`t`.`ROLE_NAME` AS `role_name`,`t`.`ROLE_GROUP` AS `role_group`,`t`.`ROLE_TYPE` AS `role_type`,`t`.`ORDER_BY` AS `order_by` from `sys_role` `t` where (`t`.`VALID_FLAG` = '1') */;

/*View structure for view bpm_def_user_dept_position_v */

/*!50001 DROP TABLE IF EXISTS `bpm_def_user_dept_position_v` */;
/*!50001 DROP VIEW IF EXISTS `bpm_def_user_dept_position_v` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bpm_def_user_dept_position_v` AS select `t`.`ID` AS `id`,`t`.`USER_ID` AS `user_id`,`t`.`DEPT_ID` AS `dept_id`,`t`.`POSITION_ID` AS `position_id`,`t`.`IS_CHIEF_DEPT` AS `is_chief_dept`,`t`.`IS_MANAGER` AS `is_manager`,`t`.`ORDER_BY` AS `order_by` from `sys_user_dept_position` `t` */;

/*View structure for view bpm_def_user_v */

/*!50001 DROP TABLE IF EXISTS `bpm_def_user_v` */;
/*!50001 DROP VIEW IF EXISTS `bpm_def_user_v` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bpm_def_user_v` AS select `t`.`ID` AS `id`,`t`.`NAME` AS `name`,`t`.`LOGIN_NAME` AS `login_name`,`t`.`LOGIN_PASSWORD` AS `login_password`,`t`.`STATUS` AS `status`,`t`.`ORDER_BY` AS `order_by` from `sys_user` `t` */;

/*View structure for view bpm_entry_console_v */

/*!50001 DROP TABLE IF EXISTS `bpm_entry_console_v` */;
/*!50001 DROP VIEW IF EXISTS `bpm_entry_console_v` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bpm_entry_console_v` AS select `b`.`DBID_` AS `entryId`,`b`.`TITLE_` AS `entryName`,`p`.`OBJNAME_` AS `defineName`,`b`.`STATE_` AS `state`,`b`.`USERID_` AS `userId`,`b`.`DEPTID_` AS `deptId`,`b`.`START_` AS `startDate`,`b`.`END_` AS `endDate`,`p`.`KEY_` AS `keyone`,`p`.`DEPLOYMENT_` AS `deployment`,`b`.`ID_` AS `executionId`,`p`.`STRINGVAL_` AS `pdId`,`b`.`DURATION_` AS `duration`,`b`.`FORMID_` AS `formId`,(select `n`.`STATUS_` from `bpm_cross_net_instance` `n` where (`n`.`ID_` = `b`.`DBID_`)) AS `LOCKED_STATUS_` from (`bpm_hist_procinst` `b` left join `bpm_deployprop` `p` on((`b`.`PROCDEFID_` = `p`.`STRINGVAL_`))) */;

/*View structure for view bpm_entry_v */

/*!50001 DROP TABLE IF EXISTS `bpm_entry_v` */;
/*!50001 DROP VIEW IF EXISTS `bpm_entry_v` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bpm_entry_v` AS select `t1`.`DBID_` AS `DBID_`,`t1`.`DBVERSION_` AS `DBVERSION_`,`t1`.`ID_` AS `ID_`,`t1`.`PROCDEFID_` AS `PROCDEFID_`,`t1`.`KEY_` AS `KEY_`,`t1`.`START_` AS `START_`,`t1`.`END_` AS `END_`,`t1`.`DURATION_` AS `DURATION_`,`t1`.`STATE_` AS `STATE_`,`t1`.`ENDACTIVITY_` AS `ENDACTIVITY_`,`t1`.`NEXTIDX_` AS `NEXTIDX_`,`t1`.`FORMID_` AS `FORMID_`,`t1`.`USERID_` AS `USERID_`,`t1`.`DEPTID_` AS `DEPTID_`,`t2`.`ACTIVITYNAME_` AS `activityname_`,`t2`.`ACTIVITYALIAS_` AS `activityalias_`,`t1`.`BUSINESSSTATE_` AS `businessstate_` from (`bpm_hist_procinst` `t1` left join `bpm_execution` `t2` on((`t1`.`DBID_` = `t2`.`INSTANCE_`))) */;

/*View structure for view bpm_hist_procinst_v */

/*!50001 DROP TABLE IF EXISTS `bpm_hist_procinst_v` */;
/*!50001 DROP VIEW IF EXISTS `bpm_hist_procinst_v` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bpm_hist_procinst_v` AS select `t`.`DBID_` AS `DBID_`,`t`.`DBVERSION_` AS `DBVERSION_`,`t`.`ID_` AS `ID_`,`t`.`PROCDEFID_` AS `PROCDEFID_`,`t`.`KEY_` AS `KEY_`,`t`.`START_` AS `START_`,`t`.`END_` AS `END_`,`t`.`DURATION_` AS `DURATION_`,`t`.`STATE_` AS `STATE_`,`t`.`ENDACTIVITY_` AS `ENDACTIVITY_`,`t`.`NEXTIDX_` AS `NEXTIDX_`,`t`.`FORMID_` AS `FORMID_`,`t`.`TITLE_` AS `TITLE_`,`t`.`USERID_` AS `USERID_`,`t`.`DEPTID_` AS `DEPTID_`,(select `s`.`POSITION_ID` from `sys_user_dept_position` `s` where ((`s`.`USER_ID` = `t`.`USERID_`) and (`s`.`DEPT_ID` = `t`.`DEPTID_`))) AS `POSITIONID_` from `bpm_hist_procinst` `t` */;

/*View structure for view bpm_hist_task_analys_v */

/*!50001 DROP TABLE IF EXISTS `bpm_hist_task_analys_v` */;
/*!50001 DROP VIEW IF EXISTS `bpm_hist_task_analys_v` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bpm_hist_task_analys_v` AS select `t`.`DBID_` AS `DBID_`,`t`.`DBVERSION_` AS `DBVERSION_`,`t`.`EXECUTION_` AS `EXECUTION_`,`t`.`OUTCOME_` AS `OUTCOME_`,`t`.`ASSIGNEE_` AS `ASSIGNEE_`,`t`.`PRIORITY_` AS `PRIORITY_`,`t`.`STATE_` AS `STATE_`,`t`.`CREATE_` AS `CREATE_`,`t`.`END_` AS `END_`,`t`.`DURATION_` AS `DURATION_`,`t`.`NEXTIDX_` AS `NEXTIDX_`,`t`.`SUPERTASK_` AS `SUPERTASK_`,`t`.`TASK_ORDER_` AS `TASK_ORDER_`,`t`.`OPEN_` AS `OPEN_`,`t`.`TAKE_STATE_` AS `TAKE_STATE_`,`t`.`PROCINST_` AS `PROCINST_`,`t`.`DESCR_` AS `DESCR_`,`t`.`SUSPHISTSTATE_` AS `SUSPHISTSTATE_`,`t`.`TASK_TYPE_` AS `TASK_TYPE_`,`t`.`TASK_B_ID_` AS `TASK_B_ID_`,`t`.`TASK_TITLE_` AS `TASK_TITLE_`,`t`.`TASK_SENDUSER_` AS `TASK_SENDUSER_`,`t`.`TASK_SENDDEPT_` AS `TASK_SENDDEPT_`,`t`.`FORM_` AS `FORM_`,`t`.`PROCESS_DEF_NAME_` AS `PROCESS_DEF_NAME_`,`t`.`TASK_FINISHED_` AS `TASK_FINISHED_`,`t`.`TASK_STATE_` AS `TASK_STATE_`,`t`.`TASK_NAME_` AS `TASK_NAME_`,`t`.`HISACTINST_` AS `HISACTINST_`,`t`.`WORKHAND_TYPE_` AS `WORKHAND_TYPE_`,`t`.`WORKHAND_USER_` AS `WORKHAND_USER_`,`t`.`APP_ID_` AS `APP_ID_`,`t`.`ASSIGNEE_DEPT_` AS `ASSIGNEE_DEPT_`,(select `s`.`POSITION_ID` from `sys_user_dept_position` `s` where ((`s`.`USER_ID` = `t`.`ASSIGNEE_`) and (`s`.`DEPT_ID` = `t`.`ASSIGNEE_DEPT_`))) AS `ASSIGNEE_POSITION_` from `bpm_hist_task` `t` union all select `t`.`DBID_` AS `DBID_`,`t`.`DBVERSION_` AS `DBVERSION_`,`t`.`EXECUTION_` AS `EXECUTION_`,`t`.`OUTCOME_` AS `OUTCOME_`,`t`.`ASSIGNEE_` AS `ASSIGNEE_`,`t`.`PRIORITY_` AS `PRIORITY_`,`t`.`STATE_` AS `STATE_`,`t`.`CREATE_` AS `CREATE_`,`t`.`END_` AS `END_`,`t`.`DURATION_` AS `DURATION_`,`t`.`NEXTIDX_` AS `NEXTIDX_`,`t`.`SUPERTASK_` AS `SUPERTASK_`,`t`.`TASK_ORDER_` AS `TASK_ORDER_`,`t`.`OPEN_` AS `OPEN_`,`t`.`TAKE_STATE_` AS `TAKE_STATE_`,`t`.`PROCINST_` AS `PROCINST_`,`t`.`DESCR_` AS `DESCR_`,`t`.`SUSPHISTSTATE_` AS `SUSPHISTSTATE_`,`t`.`TASK_TYPE_` AS `TASK_TYPE_`,`t`.`TASK_B_ID_` AS `TASK_B_ID_`,`t`.`TASK_TITLE_` AS `TASK_TITLE_`,`t`.`TASK_SENDUSER_` AS `TASK_SENDUSER_`,`t`.`TASK_SENDDEPT_` AS `TASK_SENDDEPT_`,`t`.`FORM_` AS `FORM_`,`t`.`PROCESS_DEF_NAME_` AS `PROCESS_DEF_NAME_`,`t`.`TASK_FINISHED_` AS `TASK_FINISHED_`,`t`.`TASK_STATE_` AS `TASK_STATE_`,`t`.`TASK_NAME_` AS `TASK_NAME_`,`t`.`HISACTINST_` AS `HISACTINST_`,`t`.`WORKHAND_TYPE_` AS `WORKHAND_TYPE_`,`t`.`WORKHAND_USER_` AS `WORKHAND_USER_`,`t`.`APP_ID_` AS `APP_ID_`,`t`.`ASSIGNEE_DEPT_` AS `ASSIGNEE_DEPT_`,(select `s`.`POSITION_ID` from `sys_user_dept_position` `s` where ((`s`.`USER_ID` = `t`.`ASSIGNEE_`) and (`s`.`DEPT_ID` = `t`.`ASSIGNEE_DEPT_`))) AS `ASSIGNEE_POSITION_` from `bpm_hist_task_ext1` `t` union all select `t`.`DBID_` AS `DBID_`,`t`.`DBVERSION_` AS `DBVERSION_`,`t`.`EXECUTION_` AS `EXECUTION_`,`t`.`OUTCOME_` AS `OUTCOME_`,`t`.`ASSIGNEE_` AS `ASSIGNEE_`,`t`.`PRIORITY_` AS `PRIORITY_`,`t`.`STATE_` AS `STATE_`,`t`.`CREATE_` AS `CREATE_`,`t`.`END_` AS `END_`,`t`.`DURATION_` AS `DURATION_`,`t`.`NEXTIDX_` AS `NEXTIDX_`,`t`.`SUPERTASK_` AS `SUPERTASK_`,`t`.`TASK_ORDER_` AS `TASK_ORDER_`,`t`.`OPEN_` AS `OPEN_`,`t`.`TAKE_STATE_` AS `TAKE_STATE_`,`t`.`PROCINST_` AS `PROCINST_`,`t`.`DESCR_` AS `DESCR_`,`t`.`SUSPHISTSTATE_` AS `SUSPHISTSTATE_`,`t`.`TASK_TYPE_` AS `TASK_TYPE_`,`t`.`TASK_B_ID_` AS `TASK_B_ID_`,`t`.`TASK_TITLE_` AS `TASK_TITLE_`,`t`.`TASK_SENDUSER_` AS `TASK_SENDUSER_`,`t`.`TASK_SENDDEPT_` AS `TASK_SENDDEPT_`,`t`.`FORM_` AS `FORM_`,`t`.`PROCESS_DEF_NAME_` AS `PROCESS_DEF_NAME_`,`t`.`TASK_FINISHED_` AS `TASK_FINISHED_`,`t`.`TASK_STATE_` AS `TASK_STATE_`,`t`.`TASK_NAME_` AS `TASK_NAME_`,`t`.`HISACTINST_` AS `HISACTINST_`,`t`.`WORKHAND_TYPE_` AS `WORKHAND_TYPE_`,`t`.`WORKHAND_USER_` AS `WORKHAND_USER_`,`t`.`APP_ID_` AS `APP_ID_`,`t`.`ASSIGNEE_DEPT_` AS `ASSIGNEE_DEPT_`,(select `s`.`POSITION_ID` from `sys_user_dept_position` `s` where ((`s`.`USER_ID` = `t`.`ASSIGNEE_`) and (`s`.`DEPT_ID` = `t`.`ASSIGNEE_DEPT_`))) AS `ASSIGNEE_POSITION_` from `bpm_hist_task_ext2` `t` union all select `t`.`DBID_` AS `DBID_`,`t`.`DBVERSION_` AS `DBVERSION_`,`t`.`EXECUTION_` AS `EXECUTION_`,`t`.`OUTCOME_` AS `OUTCOME_`,`t`.`ASSIGNEE_` AS `ASSIGNEE_`,`t`.`PRIORITY_` AS `PRIORITY_`,`t`.`STATE_` AS `STATE_`,`t`.`CREATE_` AS `CREATE_`,`t`.`END_` AS `END_`,`t`.`DURATION_` AS `DURATION_`,`t`.`NEXTIDX_` AS `NEXTIDX_`,`t`.`SUPERTASK_` AS `SUPERTASK_`,`t`.`TASK_ORDER_` AS `TASK_ORDER_`,`t`.`OPEN_` AS `OPEN_`,`t`.`TAKE_STATE_` AS `TAKE_STATE_`,`t`.`PROCINST_` AS `PROCINST_`,`t`.`DESCR_` AS `DESCR_`,`t`.`SUSPHISTSTATE_` AS `SUSPHISTSTATE_`,`t`.`TASK_TYPE_` AS `TASK_TYPE_`,`t`.`TASK_B_ID_` AS `TASK_B_ID_`,`t`.`TASK_TITLE_` AS `TASK_TITLE_`,`t`.`TASK_SENDUSER_` AS `TASK_SENDUSER_`,`t`.`TASK_SENDDEPT_` AS `TASK_SENDDEPT_`,`t`.`FORM_` AS `FORM_`,`t`.`PROCESS_DEF_NAME_` AS `PROCESS_DEF_NAME_`,`t`.`TASK_FINISHED_` AS `TASK_FINISHED_`,`t`.`TASK_STATE_` AS `TASK_STATE_`,`t`.`TASK_NAME_` AS `TASK_NAME_`,`t`.`HISACTINST_` AS `HISACTINST_`,`t`.`WORKHAND_TYPE_` AS `WORKHAND_TYPE_`,`t`.`WORKHAND_USER_` AS `WORKHAND_USER_`,`t`.`APP_ID_` AS `APP_ID_`,`t`.`ASSIGNEE_DEPT_` AS `ASSIGNEE_DEPT_`,(select `s`.`POSITION_ID` from `sys_user_dept_position` `s` where ((`s`.`USER_ID` = `t`.`ASSIGNEE_`) and (`s`.`DEPT_ID` = `t`.`ASSIGNEE_DEPT_`))) AS `ASSIGNEE_POSITION_` from `bpm_hist_task_ext3` `t` union all select `t`.`DBID_` AS `DBID_`,`t`.`DBVERSION_` AS `DBVERSION_`,`t`.`EXECUTION_` AS `EXECUTION_`,`t`.`OUTCOME_` AS `OUTCOME_`,`t`.`ASSIGNEE_` AS `ASSIGNEE_`,`t`.`PRIORITY_` AS `PRIORITY_`,`t`.`STATE_` AS `STATE_`,`t`.`CREATE_` AS `CREATE_`,`t`.`END_` AS `END_`,`t`.`DURATION_` AS `DURATION_`,`t`.`NEXTIDX_` AS `NEXTIDX_`,`t`.`SUPERTASK_` AS `SUPERTASK_`,`t`.`TASK_ORDER_` AS `TASK_ORDER_`,`t`.`OPEN_` AS `OPEN_`,`t`.`TAKE_STATE_` AS `TAKE_STATE_`,`t`.`PROCINST_` AS `PROCINST_`,`t`.`DESCR_` AS `DESCR_`,`t`.`SUSPHISTSTATE_` AS `SUSPHISTSTATE_`,`t`.`TASK_TYPE_` AS `TASK_TYPE_`,`t`.`TASK_B_ID_` AS `TASK_B_ID_`,`t`.`TASK_TITLE_` AS `TASK_TITLE_`,`t`.`TASK_SENDUSER_` AS `TASK_SENDUSER_`,`t`.`TASK_SENDDEPT_` AS `TASK_SENDDEPT_`,`t`.`FORM_` AS `FORM_`,`t`.`PROCESS_DEF_NAME_` AS `PROCESS_DEF_NAME_`,`t`.`TASK_FINISHED_` AS `TASK_FINISHED_`,`t`.`TASK_STATE_` AS `TASK_STATE_`,`t`.`TASK_NAME_` AS `TASK_NAME_`,`t`.`HISACTINST_` AS `HISACTINST_`,`t`.`WORKHAND_TYPE_` AS `WORKHAND_TYPE_`,`t`.`WORKHAND_USER_` AS `WORKHAND_USER_`,`t`.`APP_ID_` AS `APP_ID_`,`t`.`ASSIGNEE_DEPT_` AS `ASSIGNEE_DEPT_`,(select `s`.`POSITION_ID` from `sys_user_dept_position` `s` where ((`s`.`USER_ID` = `t`.`ASSIGNEE_`) and (`s`.`DEPT_ID` = `t`.`ASSIGNEE_DEPT_`))) AS `ASSIGNEE_POSITION_` from `bpm_hist_task_ext4` `t` union all select `t`.`DBID_` AS `DBID_`,`t`.`DBVERSION_` AS `DBVERSION_`,`t`.`EXECUTION_` AS `EXECUTION_`,`t`.`OUTCOME_` AS `OUTCOME_`,`t`.`ASSIGNEE_` AS `ASSIGNEE_`,`t`.`PRIORITY_` AS `PRIORITY_`,`t`.`STATE_` AS `STATE_`,`t`.`CREATE_` AS `CREATE_`,`t`.`END_` AS `END_`,`t`.`DURATION_` AS `DURATION_`,`t`.`NEXTIDX_` AS `NEXTIDX_`,`t`.`SUPERTASK_` AS `SUPERTASK_`,`t`.`TASK_ORDER_` AS `TASK_ORDER_`,`t`.`OPEN_` AS `OPEN_`,`t`.`TAKE_STATE_` AS `TAKE_STATE_`,`t`.`PROCINST_` AS `PROCINST_`,`t`.`DESCR_` AS `DESCR_`,`t`.`SUSPHISTSTATE_` AS `SUSPHISTSTATE_`,`t`.`TASK_TYPE_` AS `TASK_TYPE_`,`t`.`TASK_B_ID_` AS `TASK_B_ID_`,`t`.`TASK_TITLE_` AS `TASK_TITLE_`,`t`.`TASK_SENDUSER_` AS `TASK_SENDUSER_`,`t`.`TASK_SENDDEPT_` AS `TASK_SENDDEPT_`,`t`.`FORM_` AS `FORM_`,`t`.`PROCESS_DEF_NAME_` AS `PROCESS_DEF_NAME_`,`t`.`TASK_FINISHED_` AS `TASK_FINISHED_`,`t`.`TASK_STATE_` AS `TASK_STATE_`,`t`.`TASK_NAME_` AS `TASK_NAME_`,`t`.`HISACTINST_` AS `HISACTINST_`,`t`.`WORKHAND_TYPE_` AS `WORKHAND_TYPE_`,`t`.`WORKHAND_USER_` AS `WORKHAND_USER_`,`t`.`APP_ID_` AS `APP_ID_`,`t`.`ASSIGNEE_DEPT_` AS `ASSIGNEE_DEPT_`,(select `s`.`POSITION_ID` from `sys_user_dept_position` `s` where ((`s`.`USER_ID` = `t`.`ASSIGNEE_`) and (`s`.`DEPT_ID` = `t`.`ASSIGNEE_DEPT_`))) AS `ASSIGNEE_POSITION_` from `bpm_hist_task_ext5` `t` union all select `t`.`DBID_` AS `DBID_`,`t`.`DBVERSION_` AS `DBVERSION_`,`t`.`EXECUTION_` AS `EXECUTION_`,`t`.`OUTCOME_` AS `OUTCOME_`,`t`.`ASSIGNEE_` AS `ASSIGNEE_`,`t`.`PRIORITY_` AS `PRIORITY_`,`t`.`STATE_` AS `STATE_`,`t`.`CREATE_` AS `CREATE_`,`t`.`END_` AS `END_`,`t`.`DURATION_` AS `DURATION_`,`t`.`NEXTIDX_` AS `NEXTIDX_`,`t`.`SUPERTASK_` AS `SUPERTASK_`,`t`.`TASK_ORDER_` AS `TASK_ORDER_`,`t`.`OPEN_` AS `OPEN_`,`t`.`TAKE_STATE_` AS `TAKE_STATE_`,`t`.`PROCINST_` AS `PROCINST_`,`t`.`DESCR_` AS `DESCR_`,`t`.`SUSPHISTSTATE_` AS `SUSPHISTSTATE_`,`t`.`TASK_TYPE_` AS `TASK_TYPE_`,`t`.`TASK_B_ID_` AS `TASK_B_ID_`,`t`.`TASK_TITLE_` AS `TASK_TITLE_`,`t`.`TASK_SENDUSER_` AS `TASK_SENDUSER_`,`t`.`TASK_SENDDEPT_` AS `TASK_SENDDEPT_`,`t`.`FORM_` AS `FORM_`,`t`.`PROCESS_DEF_NAME_` AS `PROCESS_DEF_NAME_`,`t`.`TASK_FINISHED_` AS `TASK_FINISHED_`,`t`.`TASK_STATE_` AS `TASK_STATE_`,`t`.`TASK_NAME_` AS `TASK_NAME_`,`t`.`HISACTINST_` AS `HISACTINST_`,`t`.`WORKHAND_TYPE_` AS `WORKHAND_TYPE_`,`t`.`WORKHAND_USER_` AS `WORKHAND_USER_`,`t`.`APP_ID_` AS `APP_ID_`,`t`.`ASSIGNEE_DEPT_` AS `ASSIGNEE_DEPT_`,(select `s`.`POSITION_ID` from `sys_user_dept_position` `s` where ((`s`.`USER_ID` = `t`.`ASSIGNEE_`) and (`s`.`DEPT_ID` = `t`.`ASSIGNEE_DEPT_`))) AS `ASSIGNEE_POSITION_` from `bpm_hist_task_ext6` `t` union all select `t`.`DBID_` AS `DBID_`,`t`.`DBVERSION_` AS `DBVERSION_`,`t`.`EXECUTION_` AS `EXECUTION_`,`t`.`OUTCOME_` AS `OUTCOME_`,`t`.`ASSIGNEE_` AS `ASSIGNEE_`,`t`.`PRIORITY_` AS `PRIORITY_`,`t`.`STATE_` AS `STATE_`,`t`.`CREATE_` AS `CREATE_`,`t`.`END_` AS `END_`,`t`.`DURATION_` AS `DURATION_`,`t`.`NEXTIDX_` AS `NEXTIDX_`,`t`.`SUPERTASK_` AS `SUPERTASK_`,`t`.`TASK_ORDER_` AS `TASK_ORDER_`,`t`.`OPEN_` AS `OPEN_`,`t`.`TAKE_STATE_` AS `TAKE_STATE_`,`t`.`PROCINST_` AS `PROCINST_`,`t`.`DESCR_` AS `DESCR_`,`t`.`SUSPHISTSTATE_` AS `SUSPHISTSTATE_`,`t`.`TASK_TYPE_` AS `TASK_TYPE_`,`t`.`TASK_B_ID_` AS `TASK_B_ID_`,`t`.`TASK_TITLE_` AS `TASK_TITLE_`,`t`.`TASK_SENDUSER_` AS `TASK_SENDUSER_`,`t`.`TASK_SENDDEPT_` AS `TASK_SENDDEPT_`,`t`.`FORM_` AS `FORM_`,`t`.`PROCESS_DEF_NAME_` AS `PROCESS_DEF_NAME_`,`t`.`TASK_FINISHED_` AS `TASK_FINISHED_`,`t`.`TASK_STATE_` AS `TASK_STATE_`,`t`.`TASK_NAME_` AS `TASK_NAME_`,`t`.`HISACTINST_` AS `HISACTINST_`,`t`.`WORKHAND_TYPE_` AS `WORKHAND_TYPE_`,`t`.`WORKHAND_USER_` AS `WORKHAND_USER_`,`t`.`APP_ID_` AS `APP_ID_`,`t`.`ASSIGNEE_DEPT_` AS `ASSIGNEE_DEPT_`,(select `s`.`POSITION_ID` from `sys_user_dept_position` `s` where ((`s`.`USER_ID` = `t`.`ASSIGNEE_`) and (`s`.`DEPT_ID` = `t`.`ASSIGNEE_DEPT_`))) AS `ASSIGNEE_POSITION_` from `bpm_hist_task_ext7` `t` union all select `t`.`DBID_` AS `DBID_`,`t`.`DBVERSION_` AS `DBVERSION_`,`t`.`EXECUTION_` AS `EXECUTION_`,`t`.`OUTCOME_` AS `OUTCOME_`,`t`.`ASSIGNEE_` AS `ASSIGNEE_`,`t`.`PRIORITY_` AS `PRIORITY_`,`t`.`STATE_` AS `STATE_`,`t`.`CREATE_` AS `CREATE_`,`t`.`END_` AS `END_`,`t`.`DURATION_` AS `DURATION_`,`t`.`NEXTIDX_` AS `NEXTIDX_`,`t`.`SUPERTASK_` AS `SUPERTASK_`,`t`.`TASK_ORDER_` AS `TASK_ORDER_`,`t`.`OPEN_` AS `OPEN_`,`t`.`TAKE_STATE_` AS `TAKE_STATE_`,`t`.`PROCINST_` AS `PROCINST_`,`t`.`DESCR_` AS `DESCR_`,`t`.`SUSPHISTSTATE_` AS `SUSPHISTSTATE_`,`t`.`TASK_TYPE_` AS `TASK_TYPE_`,`t`.`TASK_B_ID_` AS `TASK_B_ID_`,`t`.`TASK_TITLE_` AS `TASK_TITLE_`,`t`.`TASK_SENDUSER_` AS `TASK_SENDUSER_`,`t`.`TASK_SENDDEPT_` AS `TASK_SENDDEPT_`,`t`.`FORM_` AS `FORM_`,`t`.`PROCESS_DEF_NAME_` AS `PROCESS_DEF_NAME_`,`t`.`TASK_FINISHED_` AS `TASK_FINISHED_`,`t`.`TASK_STATE_` AS `TASK_STATE_`,`t`.`TASK_NAME_` AS `TASK_NAME_`,`t`.`HISACTINST_` AS `HISACTINST_`,`t`.`WORKHAND_TYPE_` AS `WORKHAND_TYPE_`,`t`.`WORKHAND_USER_` AS `WORKHAND_USER_`,`t`.`APP_ID_` AS `APP_ID_`,`t`.`ASSIGNEE_DEPT_` AS `ASSIGNEE_DEPT_`,(select `s`.`POSITION_ID` from `sys_user_dept_position` `s` where ((`s`.`USER_ID` = `t`.`ASSIGNEE_`) and (`s`.`DEPT_ID` = `t`.`ASSIGNEE_DEPT_`))) AS `ASSIGNEE_POSITION_` from `bpm_hist_task_ext8` `t` */;

/*View structure for view bpm_hist_task_v */

/*!50001 DROP TABLE IF EXISTS `bpm_hist_task_v` */;
/*!50001 DROP VIEW IF EXISTS `bpm_hist_task_v` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bpm_hist_task_v` AS select `task`.`DBID_` AS `DBID_`,`task`.`DBVERSION_` AS `DBVERSION_`,`task`.`EXECUTION_` AS `EXECUTION_`,`task`.`OUTCOME_` AS `OUTCOME_`,`task`.`ASSIGNEE_` AS `ASSIGNEE_`,`task`.`PRIORITY_` AS `PRIORITY_`,`task`.`STATE_` AS `STATE_`,`task`.`CREATE_` AS `CREATE_`,`task`.`END_` AS `END_`,`task`.`DURATION_` AS `DURATION_`,`task`.`NEXTIDX_` AS `NEXTIDX_`,`task`.`SUPERTASK_` AS `SUPERTASK_`,`task`.`TASK_ORDER_` AS `TASK_ORDER_`,`task`.`OPEN_` AS `OPEN_`,`task`.`TAKE_STATE_` AS `TAKE_STATE_`,`task`.`PROCINST_` AS `PROCINST_`,`task`.`DESCR_` AS `DESCR_`,`task`.`SUSPHISTSTATE_` AS `SUSPHISTSTATE_`,`task`.`TASK_TYPE_` AS `TASK_TYPE_`,`task`.`TASK_B_ID_` AS `TASK_B_ID_`,`task`.`TASK_TITLE_` AS `TASK_TITLE_`,`task`.`TASK_SENDUSER_` AS `TASK_SENDUSER_`,`task`.`TASK_SENDDEPT_` AS `TASK_SENDDEPT_`,`task`.`FORM_` AS `FORM_`,`task`.`PROCESS_DEF_NAME_` AS `PROCESS_DEF_NAME_`,`task`.`TASK_FINISHED_` AS `TASK_FINISHED_`,`task`.`TASK_STATE_` AS `TASK_STATE_`,`task`.`TASK_NAME_` AS `TASK_NAME_`,`task`.`HISACTINST_` AS `HISACTINST_`,`task`.`WORKHAND_TYPE_` AS `WORKHAND_TYPE_`,`task`.`WORKHAND_USER_` AS `WORKHAND_USER_`,`task`.`APP_ID_` AS `APP_ID_`,`task`.`ASSIGNEE_DEPT_` AS `ASSIGNEE_DEPT_`,(select `n`.`STATUS_` from `bpm_cross_net_instance` `n` where (`n`.`ID_` = `task`.`PROCINST_`)) AS `LOCKED_STATUS_`,(select `s`.`POSITION_ID` from `sys_user_dept_position` `s` where ((`s`.`USER_ID` = `task`.`ASSIGNEE_`) and (`s`.`DEPT_ID` = `task`.`ASSIGNEE_DEPT_`))) AS `ASSIGNEE_POSITION_` from `bpm_hist_task` `task` where (not(exists(select 1 from `bpm_hist_procinst` `procinst` where ((`procinst`.`STATE_` = 'suspended') and (`task`.`PROCINST_` = `procinst`.`DBID_`))))) union all select `task1`.`DBID_` AS `DBID_`,`task1`.`DBVERSION_` AS `DBVERSION_`,`task1`.`EXECUTION_` AS `EXECUTION_`,`task1`.`OUTCOME_` AS `OUTCOME_`,`task1`.`ASSIGNEE_` AS `ASSIGNEE_`,`task1`.`PRIORITY_` AS `PRIORITY_`,`task1`.`STATE_` AS `STATE_`,`task1`.`CREATE_` AS `CREATE_`,`task1`.`END_` AS `END_`,`task1`.`DURATION_` AS `DURATION_`,`task1`.`NEXTIDX_` AS `NEXTIDX_`,`task1`.`SUPERTASK_` AS `SUPERTASK_`,`task1`.`TASK_ORDER_` AS `TASK_ORDER_`,`task1`.`OPEN_` AS `OPEN_`,`task1`.`TAKE_STATE_` AS `TAKE_STATE_`,`task1`.`PROCINST_` AS `PROCINST_`,`task1`.`DESCR_` AS `DESCR_`,`task1`.`SUSPHISTSTATE_` AS `SUSPHISTSTATE_`,`task1`.`TASK_TYPE_` AS `TASK_TYPE_`,`task1`.`TASK_B_ID_` AS `TASK_B_ID_`,`task1`.`TASK_TITLE_` AS `TASK_TITLE_`,`task1`.`TASK_SENDUSER_` AS `TASK_SENDUSER_`,`task1`.`TASK_SENDDEPT_` AS `TASK_SENDDEPT_`,`task1`.`FORM_` AS `FORM_`,`task1`.`PROCESS_DEF_NAME_` AS `PROCESS_DEF_NAME_`,`task1`.`TASK_FINISHED_` AS `TASK_FINISHED_`,`task1`.`TASK_STATE_` AS `TASK_STATE_`,`task1`.`TASK_NAME_` AS `TASK_NAME_`,`task1`.`HISACTINST_` AS `HISACTINST_`,`task1`.`WORKHAND_TYPE_` AS `WORKHAND_TYPE_`,`task1`.`WORKHAND_USER_` AS `WORKHAND_USER_`,`task1`.`APP_ID_` AS `APP_ID_`,`task1`.`ASSIGNEE_DEPT_` AS `ASSIGNEE_DEPT_`,(select `n`.`STATUS_` from `bpm_cross_net_instance` `n` where (`n`.`ID_` = `task1`.`PROCINST_`)) AS `LOCKED_STATUS_`,(select `s`.`POSITION_ID` from `sys_user_dept_position` `s` where ((`s`.`USER_ID` = `task1`.`ASSIGNEE_`) and (`s`.`DEPT_ID` = `task1`.`ASSIGNEE_DEPT_`))) AS `ASSIGNEE_POSITION_` from `bpm_hist_task_ext1` `task1` where (not(exists(select 1 from `bpm_hist_procinst` `procinst` where ((`procinst`.`STATE_` = 'suspended') and (`task1`.`PROCINST_` = `procinst`.`DBID_`))))) union all select `task3`.`DBID_` AS `DBID_`,`task3`.`DBVERSION_` AS `DBVERSION_`,`task3`.`EXECUTION_` AS `EXECUTION_`,`task3`.`OUTCOME_` AS `OUTCOME_`,`task3`.`ASSIGNEE_` AS `ASSIGNEE_`,`task3`.`PRIORITY_` AS `PRIORITY_`,`task3`.`STATE_` AS `STATE_`,`task3`.`CREATE_` AS `CREATE_`,`task3`.`END_` AS `END_`,`task3`.`DURATION_` AS `DURATION_`,`task3`.`NEXTIDX_` AS `NEXTIDX_`,`task3`.`SUPERTASK_` AS `SUPERTASK_`,`task3`.`TASK_ORDER_` AS `TASK_ORDER_`,`task3`.`OPEN_` AS `OPEN_`,`task3`.`TAKE_STATE_` AS `TAKE_STATE_`,`task3`.`PROCINST_` AS `PROCINST_`,`task3`.`DESCR_` AS `DESCR_`,`task3`.`SUSPHISTSTATE_` AS `SUSPHISTSTATE_`,`task3`.`TASK_TYPE_` AS `TASK_TYPE_`,`task3`.`TASK_B_ID_` AS `TASK_B_ID_`,`task3`.`TASK_TITLE_` AS `TASK_TITLE_`,`task3`.`TASK_SENDUSER_` AS `TASK_SENDUSER_`,`task3`.`TASK_SENDDEPT_` AS `TASK_SENDDEPT_`,`task3`.`FORM_` AS `FORM_`,`task3`.`PROCESS_DEF_NAME_` AS `PROCESS_DEF_NAME_`,`task3`.`TASK_FINISHED_` AS `TASK_FINISHED_`,`task3`.`TASK_STATE_` AS `TASK_STATE_`,`task3`.`TASK_NAME_` AS `TASK_NAME_`,`task3`.`HISACTINST_` AS `HISACTINST_`,`task3`.`WORKHAND_TYPE_` AS `WORKHAND_TYPE_`,`task3`.`WORKHAND_USER_` AS `WORKHAND_USER_`,`task3`.`APP_ID_` AS `APP_ID_`,`task3`.`ASSIGNEE_DEPT_` AS `ASSIGNEE_DEPT_`,(select `n`.`STATUS_` from `bpm_cross_net_instance` `n` where (`n`.`ID_` = `task3`.`PROCINST_`)) AS `LOCKED_STATUS_`,(select `s`.`POSITION_ID` from `sys_user_dept_position` `s` where ((`s`.`USER_ID` = `task3`.`ASSIGNEE_`) and (`s`.`DEPT_ID` = `task3`.`ASSIGNEE_DEPT_`))) AS `ASSIGNEE_POSITION_` from `bpm_hist_task_ext3` `task3` where (not(exists(select 1 from `bpm_hist_procinst` `procinst` where ((`procinst`.`STATE_` = 'suspended') and (`task3`.`PROCINST_` = `procinst`.`DBID_`))))) union all select `task4`.`DBID_` AS `DBID_`,`task4`.`DBVERSION_` AS `DBVERSION_`,`task4`.`EXECUTION_` AS `EXECUTION_`,`task4`.`OUTCOME_` AS `OUTCOME_`,`task4`.`ASSIGNEE_` AS `ASSIGNEE_`,`task4`.`PRIORITY_` AS `PRIORITY_`,`task4`.`STATE_` AS `STATE_`,`task4`.`CREATE_` AS `CREATE_`,`task4`.`END_` AS `END_`,`task4`.`DURATION_` AS `DURATION_`,`task4`.`NEXTIDX_` AS `NEXTIDX_`,`task4`.`SUPERTASK_` AS `SUPERTASK_`,`task4`.`TASK_ORDER_` AS `TASK_ORDER_`,`task4`.`OPEN_` AS `OPEN_`,`task4`.`TAKE_STATE_` AS `TAKE_STATE_`,`task4`.`PROCINST_` AS `PROCINST_`,`task4`.`DESCR_` AS `DESCR_`,`task4`.`SUSPHISTSTATE_` AS `SUSPHISTSTATE_`,`task4`.`TASK_TYPE_` AS `TASK_TYPE_`,`task4`.`TASK_B_ID_` AS `TASK_B_ID_`,`task4`.`TASK_TITLE_` AS `TASK_TITLE_`,`task4`.`TASK_SENDUSER_` AS `TASK_SENDUSER_`,`task4`.`TASK_SENDDEPT_` AS `TASK_SENDDEPT_`,`task4`.`FORM_` AS `FORM_`,`task4`.`PROCESS_DEF_NAME_` AS `PROCESS_DEF_NAME_`,`task4`.`TASK_FINISHED_` AS `TASK_FINISHED_`,`task4`.`TASK_STATE_` AS `TASK_STATE_`,`task4`.`TASK_NAME_` AS `TASK_NAME_`,`task4`.`HISACTINST_` AS `HISACTINST_`,`task4`.`WORKHAND_TYPE_` AS `WORKHAND_TYPE_`,`task4`.`WORKHAND_USER_` AS `WORKHAND_USER_`,`task4`.`APP_ID_` AS `APP_ID_`,`task4`.`ASSIGNEE_DEPT_` AS `ASSIGNEE_DEPT_`,(select `n`.`STATUS_` from `bpm_cross_net_instance` `n` where (`n`.`ID_` = `task4`.`PROCINST_`)) AS `LOCKED_STATUS_`,(select `s`.`POSITION_ID` from `sys_user_dept_position` `s` where ((`s`.`USER_ID` = `task4`.`ASSIGNEE_`) and (`s`.`DEPT_ID` = `task4`.`ASSIGNEE_DEPT_`))) AS `ASSIGNEE_POSITION_` from `bpm_hist_task_ext4` `task4` where (not(exists(select 1 from `bpm_hist_procinst` `procinst` where ((`procinst`.`STATE_` = 'suspended') and (`task4`.`PROCINST_` = `procinst`.`DBID_`))))) union all select `task5`.`DBID_` AS `DBID_`,`task5`.`DBVERSION_` AS `DBVERSION_`,`task5`.`EXECUTION_` AS `EXECUTION_`,`task5`.`OUTCOME_` AS `OUTCOME_`,`task5`.`ASSIGNEE_` AS `ASSIGNEE_`,`task5`.`PRIORITY_` AS `PRIORITY_`,`task5`.`STATE_` AS `STATE_`,`task5`.`CREATE_` AS `CREATE_`,`task5`.`END_` AS `END_`,`task5`.`DURATION_` AS `DURATION_`,`task5`.`NEXTIDX_` AS `NEXTIDX_`,`task5`.`SUPERTASK_` AS `SUPERTASK_`,`task5`.`TASK_ORDER_` AS `TASK_ORDER_`,`task5`.`OPEN_` AS `OPEN_`,`task5`.`TAKE_STATE_` AS `TAKE_STATE_`,`task5`.`PROCINST_` AS `PROCINST_`,`task5`.`DESCR_` AS `DESCR_`,`task5`.`SUSPHISTSTATE_` AS `SUSPHISTSTATE_`,`task5`.`TASK_TYPE_` AS `TASK_TYPE_`,`task5`.`TASK_B_ID_` AS `TASK_B_ID_`,`task5`.`TASK_TITLE_` AS `TASK_TITLE_`,`task5`.`TASK_SENDUSER_` AS `TASK_SENDUSER_`,`task5`.`TASK_SENDDEPT_` AS `TASK_SENDDEPT_`,`task5`.`FORM_` AS `FORM_`,`task5`.`PROCESS_DEF_NAME_` AS `PROCESS_DEF_NAME_`,`task5`.`TASK_FINISHED_` AS `TASK_FINISHED_`,`task5`.`TASK_STATE_` AS `TASK_STATE_`,`task5`.`TASK_NAME_` AS `TASK_NAME_`,`task5`.`HISACTINST_` AS `HISACTINST_`,`task5`.`WORKHAND_TYPE_` AS `WORKHAND_TYPE_`,`task5`.`WORKHAND_USER_` AS `WORKHAND_USER_`,`task5`.`APP_ID_` AS `APP_ID_`,`task5`.`ASSIGNEE_DEPT_` AS `ASSIGNEE_DEPT_`,(select `n`.`STATUS_` from `bpm_cross_net_instance` `n` where (`n`.`ID_` = `task5`.`PROCINST_`)) AS `LOCKED_STATUS_`,(select `s`.`POSITION_ID` from `sys_user_dept_position` `s` where ((`s`.`USER_ID` = `task5`.`ASSIGNEE_`) and (`s`.`DEPT_ID` = `task5`.`ASSIGNEE_DEPT_`))) AS `ASSIGNEE_POSITION_` from `bpm_hist_task_ext5` `task5` where (not(exists(select 1 from `bpm_hist_procinst` `procinst` where ((`procinst`.`STATE_` = 'suspended') and (`task5`.`PROCINST_` = `procinst`.`DBID_`))))) union all select `task6`.`DBID_` AS `DBID_`,`task6`.`DBVERSION_` AS `DBVERSION_`,`task6`.`EXECUTION_` AS `EXECUTION_`,`task6`.`OUTCOME_` AS `OUTCOME_`,`task6`.`ASSIGNEE_` AS `ASSIGNEE_`,`task6`.`PRIORITY_` AS `PRIORITY_`,`task6`.`STATE_` AS `STATE_`,`task6`.`CREATE_` AS `CREATE_`,`task6`.`END_` AS `END_`,`task6`.`DURATION_` AS `DURATION_`,`task6`.`NEXTIDX_` AS `NEXTIDX_`,`task6`.`SUPERTASK_` AS `SUPERTASK_`,`task6`.`TASK_ORDER_` AS `TASK_ORDER_`,`task6`.`OPEN_` AS `OPEN_`,`task6`.`TAKE_STATE_` AS `TAKE_STATE_`,`task6`.`PROCINST_` AS `PROCINST_`,`task6`.`DESCR_` AS `DESCR_`,`task6`.`SUSPHISTSTATE_` AS `SUSPHISTSTATE_`,`task6`.`TASK_TYPE_` AS `TASK_TYPE_`,`task6`.`TASK_B_ID_` AS `TASK_B_ID_`,`task6`.`TASK_TITLE_` AS `TASK_TITLE_`,`task6`.`TASK_SENDUSER_` AS `TASK_SENDUSER_`,`task6`.`TASK_SENDDEPT_` AS `TASK_SENDDEPT_`,`task6`.`FORM_` AS `FORM_`,`task6`.`PROCESS_DEF_NAME_` AS `PROCESS_DEF_NAME_`,`task6`.`TASK_FINISHED_` AS `TASK_FINISHED_`,`task6`.`TASK_STATE_` AS `TASK_STATE_`,`task6`.`TASK_NAME_` AS `TASK_NAME_`,`task6`.`HISACTINST_` AS `HISACTINST_`,`task6`.`WORKHAND_TYPE_` AS `WORKHAND_TYPE_`,`task6`.`WORKHAND_USER_` AS `WORKHAND_USER_`,`task6`.`APP_ID_` AS `APP_ID_`,`task6`.`ASSIGNEE_DEPT_` AS `ASSIGNEE_DEPT_`,(select `n`.`STATUS_` from `bpm_cross_net_instance` `n` where (`n`.`ID_` = `task6`.`PROCINST_`)) AS `LOCKED_STATUS_`,(select `s`.`POSITION_ID` from `sys_user_dept_position` `s` where ((`s`.`USER_ID` = `task6`.`ASSIGNEE_`) and (`s`.`DEPT_ID` = `task6`.`ASSIGNEE_DEPT_`))) AS `ASSIGNEE_POSITION_` from `bpm_hist_task_ext6` `task6` where (not(exists(select 1 from `bpm_hist_procinst` `procinst` where ((`procinst`.`STATE_` = 'suspended') and (`task6`.`PROCINST_` = `procinst`.`DBID_`))))) union all select `task7`.`DBID_` AS `DBID_`,`task7`.`DBVERSION_` AS `DBVERSION_`,`task7`.`EXECUTION_` AS `EXECUTION_`,`task7`.`OUTCOME_` AS `OUTCOME_`,`task7`.`ASSIGNEE_` AS `ASSIGNEE_`,`task7`.`PRIORITY_` AS `PRIORITY_`,`task7`.`STATE_` AS `STATE_`,`task7`.`CREATE_` AS `CREATE_`,`task7`.`END_` AS `END_`,`task7`.`DURATION_` AS `DURATION_`,`task7`.`NEXTIDX_` AS `NEXTIDX_`,`task7`.`SUPERTASK_` AS `SUPERTASK_`,`task7`.`TASK_ORDER_` AS `TASK_ORDER_`,`task7`.`OPEN_` AS `OPEN_`,`task7`.`TAKE_STATE_` AS `TAKE_STATE_`,`task7`.`PROCINST_` AS `PROCINST_`,`task7`.`DESCR_` AS `DESCR_`,`task7`.`SUSPHISTSTATE_` AS `SUSPHISTSTATE_`,`task7`.`TASK_TYPE_` AS `TASK_TYPE_`,`task7`.`TASK_B_ID_` AS `TASK_B_ID_`,`task7`.`TASK_TITLE_` AS `TASK_TITLE_`,`task7`.`TASK_SENDUSER_` AS `TASK_SENDUSER_`,`task7`.`TASK_SENDDEPT_` AS `TASK_SENDDEPT_`,`task7`.`FORM_` AS `FORM_`,`task7`.`PROCESS_DEF_NAME_` AS `PROCESS_DEF_NAME_`,`task7`.`TASK_FINISHED_` AS `TASK_FINISHED_`,`task7`.`TASK_STATE_` AS `TASK_STATE_`,`task7`.`TASK_NAME_` AS `TASK_NAME_`,`task7`.`HISACTINST_` AS `HISACTINST_`,`task7`.`WORKHAND_TYPE_` AS `WORKHAND_TYPE_`,`task7`.`WORKHAND_USER_` AS `WORKHAND_USER_`,`task7`.`APP_ID_` AS `APP_ID_`,`task7`.`ASSIGNEE_DEPT_` AS `ASSIGNEE_DEPT_`,(select `n`.`STATUS_` from `bpm_cross_net_instance` `n` where (`n`.`ID_` = `task7`.`PROCINST_`)) AS `LOCKED_STATUS_`,(select `s`.`POSITION_ID` from `sys_user_dept_position` `s` where ((`s`.`USER_ID` = `task7`.`ASSIGNEE_`) and (`s`.`DEPT_ID` = `task7`.`ASSIGNEE_DEPT_`))) AS `ASSIGNEE_POSITION_` from `bpm_hist_task_ext7` `task7` where (not(exists(select 1 from `bpm_hist_procinst` `procinst` where ((`procinst`.`STATE_` = 'suspended') and (`task7`.`PROCINST_` = `procinst`.`DBID_`))))) union all select `task8`.`DBID_` AS `DBID_`,`task8`.`DBVERSION_` AS `DBVERSION_`,`task8`.`EXECUTION_` AS `EXECUTION_`,`task8`.`OUTCOME_` AS `OUTCOME_`,`task8`.`ASSIGNEE_` AS `ASSIGNEE_`,`task8`.`PRIORITY_` AS `PRIORITY_`,`task8`.`STATE_` AS `STATE_`,`task8`.`CREATE_` AS `CREATE_`,`task8`.`END_` AS `END_`,`task8`.`DURATION_` AS `DURATION_`,`task8`.`NEXTIDX_` AS `NEXTIDX_`,`task8`.`SUPERTASK_` AS `SUPERTASK_`,`task8`.`TASK_ORDER_` AS `TASK_ORDER_`,`task8`.`OPEN_` AS `OPEN_`,`task8`.`TAKE_STATE_` AS `TAKE_STATE_`,`task8`.`PROCINST_` AS `PROCINST_`,`task8`.`DESCR_` AS `DESCR_`,`task8`.`SUSPHISTSTATE_` AS `SUSPHISTSTATE_`,`task8`.`TASK_TYPE_` AS `TASK_TYPE_`,`task8`.`TASK_B_ID_` AS `TASK_B_ID_`,`task8`.`TASK_TITLE_` AS `TASK_TITLE_`,`task8`.`TASK_SENDUSER_` AS `TASK_SENDUSER_`,`task8`.`TASK_SENDDEPT_` AS `TASK_SENDDEPT_`,`task8`.`FORM_` AS `FORM_`,`task8`.`PROCESS_DEF_NAME_` AS `PROCESS_DEF_NAME_`,`task8`.`TASK_FINISHED_` AS `TASK_FINISHED_`,`task8`.`TASK_STATE_` AS `TASK_STATE_`,`task8`.`TASK_NAME_` AS `TASK_NAME_`,`task8`.`HISACTINST_` AS `HISACTINST_`,`task8`.`WORKHAND_TYPE_` AS `WORKHAND_TYPE_`,`task8`.`WORKHAND_USER_` AS `WORKHAND_USER_`,`task8`.`APP_ID_` AS `APP_ID_`,`task8`.`ASSIGNEE_DEPT_` AS `ASSIGNEE_DEPT_`,(select `n`.`STATUS_` from `bpm_cross_net_instance` `n` where (`n`.`ID_` = `task8`.`PROCINST_`)) AS `LOCKED_STATUS_`,(select `s`.`POSITION_ID` from `sys_user_dept_position` `s` where ((`s`.`USER_ID` = `task8`.`ASSIGNEE_`) and (`s`.`DEPT_ID` = `task8`.`ASSIGNEE_DEPT_`))) AS `ASSIGNEE_POSITION_` from `bpm_hist_task_ext8` `task8` where (not(exists(select 1 from `bpm_hist_procinst` `procinst` where ((`procinst`.`STATE_` = 'suspended') and (`task8`.`PROCINST_` = `procinst`.`DBID_`))))) union all select `task2`.`DBID_` AS `DBID_`,`task2`.`DBVERSION_` AS `DBVERSION_`,`task2`.`EXECUTION_` AS `EXECUTION_`,`task2`.`OUTCOME_` AS `OUTCOME_`,`task2`.`ASSIGNEE_` AS `ASSIGNEE_`,`task2`.`PRIORITY_` AS `PRIORITY_`,`task2`.`STATE_` AS `STATE_`,`task2`.`CREATE_` AS `CREATE_`,`task2`.`END_` AS `END_`,`task2`.`DURATION_` AS `DURATION_`,`task2`.`NEXTIDX_` AS `NEXTIDX_`,`task2`.`SUPERTASK_` AS `SUPERTASK_`,`task2`.`TASK_ORDER_` AS `TASK_ORDER_`,`task2`.`OPEN_` AS `OPEN_`,`task2`.`TAKE_STATE_` AS `TAKE_STATE_`,`task2`.`PROCINST_` AS `PROCINST_`,`task2`.`DESCR_` AS `DESCR_`,`task2`.`SUSPHISTSTATE_` AS `SUSPHISTSTATE_`,`task2`.`TASK_TYPE_` AS `TASK_TYPE_`,`task2`.`TASK_B_ID_` AS `TASK_B_ID_`,`task2`.`TASK_TITLE_` AS `TASK_TITLE_`,`task2`.`TASK_SENDUSER_` AS `TASK_SENDUSER_`,`task2`.`TASK_SENDDEPT_` AS `TASK_SENDDEPT_`,`task2`.`FORM_` AS `FORM_`,`task2`.`PROCESS_DEF_NAME_` AS `PROCESS_DEF_NAME_`,`task2`.`TASK_FINISHED_` AS `TASK_FINISHED_`,`task2`.`TASK_STATE_` AS `TASK_STATE_`,`task2`.`TASK_NAME_` AS `TASK_NAME_`,`task2`.`HISACTINST_` AS `HISACTINST_`,`task2`.`WORKHAND_TYPE_` AS `WORKHAND_TYPE_`,`task2`.`WORKHAND_USER_` AS `WORKHAND_USER_`,`task2`.`APP_ID_` AS `APP_ID_`,`task2`.`ASSIGNEE_DEPT_` AS `ASSIGNEE_DEPT_`,(select `n`.`STATUS_` from `bpm_cross_net_instance` `n` where (`n`.`ID_` = `task2`.`PROCINST_`)) AS `LOCKED_STATUS_`,(select `s`.`POSITION_ID` from `sys_user_dept_position` `s` where ((`s`.`USER_ID` = `task2`.`ASSIGNEE_`) and (`s`.`DEPT_ID` = `task2`.`ASSIGNEE_DEPT_`))) AS `ASSIGNEE_POSITION_` from `bpm_hist_task_ext2` `task2` where (not(exists(select 1 from `bpm_hist_procinst` `procinst` where ((`procinst`.`STATE_` = 'suspended') and (`task2`.`PROCINST_` = `procinst`.`DBID_`))))) */;

/*View structure for view bpm_process_deploy_v */

/*!50001 DROP TABLE IF EXISTS `bpm_process_deploy_v` */;
/*!50001 DROP VIEW IF EXISTS `bpm_process_deploy_v` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bpm_process_deploy_v` AS select `a`.`DBID_` AS `DBID_`,`a`.`KEY_` AS `KEY_`,`a`.`NAME_` AS `NAME_`,`a`.`DESC_` AS `DESC_`,`a`.`APP_` AS `APP_`,`c`.`DBID_` AS `DEF_ID_`,'2' AS `DEF_TYPE_`,`c`.`BLOB_VALUE_` AS `XML_`,`d`.`LONGVAL_` AS `VERSION_` from ((`bpm_process_def` `a` join `bpm_lob` `c`) join `bpm_deployprop` `d`) where ((`c`.`NAME_` like `a`.`KEY_`) and (`c`.`DEPLOYMENT_` = `d`.`DEPLOYMENT_`) and (`d`.`KEY_` = 'pdversion')) order by `a`.`KEY_` */;

/*View structure for view sys_dept_org_position_v */

/*!50001 DROP TABLE IF EXISTS `sys_dept_org_position_v` */;
/*!50001 DROP VIEW IF EXISTS `sys_dept_org_position_v` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sys_dept_org_position_v` AS select `t`.`ID` AS `id`,`t`.`USER_ID` AS `user_id`,`su`.`NAME` AS `user_name`,`t`.`DEPT_ID` AS `dept_id`,`sd`.`dept_name` AS `dept_name`,`sd`.`org_id` AS `org_id`,`t`.`POSITION_ID` AS `position_id`,`sp`.`position_name` AS `position_name`,`t`.`IS_CHIEF_DEPT` AS `is_chief_dept` from (((`sys_user_dept_position` `t` join `sys_user` `su` on((`t`.`USER_ID` = `su`.`ID`))) join `sys_dept_v` `sd` on((`t`.`DEPT_ID` = `sd`.`id`))) join `sys_position_v` `sp` on((`t`.`POSITION_ID` = `sp`.`ID`))) */;

/*View structure for view sys_dept_v */

/*!50001 DROP TABLE IF EXISTS `sys_dept_v` */;
/*!50001 DROP VIEW IF EXISTS `sys_dept_v` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sys_dept_v` AS select `t`.`ID` AS `id`,`t`.`DEPT_CODE` AS `dept_code`,`t`.`PARENT_DEPT_ID` AS `parent_dept_id`,`t`.`ORG_ID` AS `org_id`,`t`.`ORDER_BY` AS `order_by`,`t`.`POST` AS `post`,`t`.`TEL` AS `tel`,`t`.`FAX` AS `fax`,`t`.`EMAIL` AS `email`,`t`.`DEPT_ALIAS` AS `dept_alias`,`t`.`VALID_FLAG` AS `valid_flag`,`t`.`WORK_CALENDAR_ID` AS `work_calendar_id`,`tl`.`DEPT_NAME` AS `dept_name`,`tl`.`DEPT_DESC` AS `dept_desc`,`tl`.`DEPT_PLACE` AS `dept_place` from (`sys_dept` `t` left join `sys_dept_tl` `tl` on((`t`.`ID` = `tl`.`SYS_DEPT_ID`))) where ((`t`.`VALID_FLAG` = '1') and (`tl`.`SYS_LANGUAGE_CODE` = 'zh_CN')) */;

/*View structure for view sys_lookup_v */

/*!50001 DROP TABLE IF EXISTS `sys_lookup_v` */;
/*!50001 DROP VIEW IF EXISTS `sys_lookup_v` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sys_lookup_v` AS select `t`.`ID` AS `id`,`t`.`LOOKUP_TYPE` AS `lookup_type`,`t`.`SYS_APPLICATION_ID` AS `sys_application_id`,`sl`.`LOOKUP_TYPE_NAME` AS `lookup_type_name`,`slu`.`LOOKUP_CODE` AS `lookup_code`,`slu`.`ID` AS `lookup_id`,`slut`.`LOOKUP_NAME` AS `lookup_name` from (((`sys_lookup_type` `t` left join `sys_lookup_type_tl` `sl` on((`t`.`ID` = `sl`.`SYS_LOOKUP_TYPE_ID`))) left join `sys_lookup` `slu` on((`t`.`ID` = `slu`.`SYS_LOOKUP_TYPE_ID`))) left join `sys_lookup_tl` `slut` on((`slut`.`SYS_LOOKUP_ID` = `slu`.`ID`))) where ((`sl`.`SYS_LANGUAGE_CODE` = 'zh_CN') and (`slut`.`SYS_LANGUAGE_CODE` = 'zh_CN') and (`t`.`VALID_FLAG` = '1') and (`slu`.`VALID_FLAG` = '1')) */;

/*View structure for view sys_org_v */

/*!50001 DROP TABLE IF EXISTS `sys_org_v` */;
/*!50001 DROP VIEW IF EXISTS `sys_org_v` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sys_org_v` AS select `t`.`ID` AS `ID`,`t`.`ORG_CODE` AS `ORG_CODE`,`t`.`PARENT_ORG_ID` AS `PARENT_ORG_ID`,`t`.`ORDER_BY` AS `ORDER_BY`,`t`.`POST` AS `POST`,`t`.`TEL` AS `TEL`,`t`.`FAX` AS `FAX`,`t`.`EMAIL` AS `EMAIL`,`t`.`WORK_CALENDAR_ID` AS `WORK_CALENDAR_ID`,`t`.`VALID_FLAG` AS `VALID_FLAG`,`t`.`RESPONSIBLE_DEPT_ID` AS `responsible_dept_id`,`tl`.`ORG_NAME` AS `org_name`,`tl`.`ORG_DESC` AS `org_desc`,`tl`.`ORG_PLACE` AS `org_place` from (`sys_org` `t` left join `sys_org_tl` `tl` on((`t`.`ID` = `tl`.`SYS_ORG_ID`))) where ((`t`.`VALID_FLAG` = '1') and (`tl`.`SYS_LANGUAGE_CODE` = 'zh_CN')) */;

/*View structure for view sys_position_v */

/*!50001 DROP TABLE IF EXISTS `sys_position_v` */;
/*!50001 DROP VIEW IF EXISTS `sys_position_v` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sys_position_v` AS select `t`.`ID` AS `ID`,`t`.`ORG_ID` AS `ORG_ID`,`t`.`POSITION_CODE` AS `POSITION_CODE`,`t`.`ORDER_BY` AS `ORDER_BY`,`t`.`LAST_UPDATE_DATE` AS `LAST_UPDATE_DATE`,`t`.`LAST_UPDATED_BY` AS `LAST_UPDATED_BY`,`t`.`CREATION_DATE` AS `CREATION_DATE`,`t`.`CREATED_BY` AS `CREATED_BY`,`t`.`LAST_UPDATE_IP` AS `LAST_UPDATE_IP`,`t`.`VERSION` AS `VERSION`,`t`.`ATTRIBUTE_01` AS `ATTRIBUTE_01`,`t`.`ATTRIBUTE_02` AS `ATTRIBUTE_02`,`t`.`ATTRIBUTE_03` AS `ATTRIBUTE_03`,`t`.`ATTRIBUTE_04` AS `ATTRIBUTE_04`,`t`.`ATTRIBUTE_05` AS `ATTRIBUTE_05`,`t`.`ATTRIBUTE_06` AS `ATTRIBUTE_06`,`t`.`ATTRIBUTE_07` AS `ATTRIBUTE_07`,`t`.`ATTRIBUTE_08` AS `ATTRIBUTE_08`,`t`.`ATTRIBUTE_09` AS `ATTRIBUTE_09`,`t`.`ATTRIBUTE_10` AS `ATTRIBUTE_10`,`tl`.`POSITION_NAME` AS `position_name`,`tl`.`POSITION_DESC` AS `position_desc` from (`sys_position` `t` left join `sys_position_tl` `tl` on((`t`.`ID` = `tl`.`SYS_POSITION_ID`))) where (`tl`.`SYS_LANGUAGE_CODE` = 'zh_CN') */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
